//go:build cgo

package main

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/types"
	"github.com/steveyegge/beads/issueops"
)

func bdProxiedClose(t *testing.T, bd, dir string, args ...string) string {
	t.Helper()
	fullArgs := append([]string{"close"}, args...)
	stdout, stderr, err := bdProxiedRunBuffers(t, bd, dir, fullArgs...)
	if err != nil {
		t.Fatalf("bd close %s failed: %v\nstdout:\n%s\nstderr:\n%s",
			strings.Join(args, " "), err, stdout, stderr)
	}
	return stdout
}

func bdProxiedCloseFail(t *testing.T, bd, dir string, args ...string) string {
	t.Helper()
	fullArgs := append([]string{"close"}, args...)
	stdout, stderr, err := bdProxiedRunBuffers(t, bd, dir, fullArgs...)
	if err == nil {
		t.Fatalf("expected bd close %s to fail, got:\nstdout:\n%s\nstderr:\n%s",
			strings.Join(args, " "), stdout, stderr)
	}
	return stdout + stderr
}

// lastJSONObjectLine returns the last line of s that looks like a compact JSON
// object, or "". Partial-failure stderr is the per-id refusal prose followed by
// the machine-readable summary, so the report is the last such line.
func lastJSONObjectLine(s string) string {
	lines := strings.Split(strings.TrimSpace(s), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		if line := strings.TrimSpace(lines[i]); strings.HasPrefix(line, "{") {
			return line
		}
	}
	return ""
}

func bdProxiedCloseJSON(t *testing.T, bd, dir string, args ...string) []*types.Issue {
	t.Helper()
	fullArgs := append([]string{"close", "--json"}, args...)
	stdout, stderr, err := bdProxiedRunBuffers(t, bd, dir, fullArgs...)
	if err != nil {
		t.Fatalf("bd close --json %s failed: %v\nstdout:\n%s\nstderr:\n%s",
			strings.Join(args, " "), err, stdout, stderr)
	}
	start := strings.Index(stdout, "[")
	if start < 0 {
		t.Fatalf("no JSON array in close output:\n%s", stdout)
	}
	var issues []*types.Issue
	if err := json.Unmarshal([]byte(stdout[start:]), &issues); err != nil {
		t.Fatalf("parse close JSON: %v\nraw: %s", err, stdout[start:])
	}
	return issues
}

func bdProxiedCloseJSONEnvelope(t *testing.T, bd, dir string, args ...string) map[string]json.RawMessage {
	t.Helper()
	fullArgs := append([]string{"close", "--json"}, args...)
	stdout, stderr, err := bdProxiedRunBuffers(t, bd, dir, fullArgs...)
	if err != nil {
		t.Fatalf("bd close --json %s failed: %v\nstdout:\n%s\nstderr:\n%s",
			strings.Join(args, " "), err, stdout, stderr)
	}
	start := strings.Index(stdout, "{")
	if start < 0 {
		t.Fatalf("no JSON object in close output:\n%s", stdout)
	}
	var env map[string]json.RawMessage
	if err := json.Unmarshal([]byte(stdout[start:]), &env); err != nil {
		t.Fatalf("parse close JSON envelope: %v\nraw: %s", err, stdout[start:])
	}
	return env
}

func readClosedBySession(t *testing.T, db *sql.DB, id string) string {
	t.Helper()
	var got sql.NullString
	err := db.QueryRowContext(context.Background(),
		"SELECT closed_by_session FROM issues WHERE id = ?", id).Scan(&got)
	if err == sql.ErrNoRows {
		if err := db.QueryRowContext(context.Background(),
			"SELECT closed_by_session FROM wisps WHERE id = ?", id).Scan(&got); err != nil {
			t.Fatalf("read closed_by_session for %s: %v", id, err)
		}
	} else if err != nil {
		t.Fatalf("read closed_by_session for %s: %v", id, err)
	}
	if !got.Valid {
		return ""
	}
	return got.String
}

func readCloseReason(t *testing.T, db *sql.DB, id string) string {
	t.Helper()
	var got sql.NullString
	err := db.QueryRowContext(context.Background(),
		"SELECT close_reason FROM issues WHERE id = ?", id).Scan(&got)
	if err == sql.ErrNoRows {
		if err := db.QueryRowContext(context.Background(),
			"SELECT close_reason FROM wisps WHERE id = ?", id).Scan(&got); err != nil {
			t.Fatalf("read close_reason for %s: %v", id, err)
		}
	} else if err != nil {
		t.Fatalf("read close_reason for %s: %v", id, err)
	}
	if !got.Valid {
		return ""
	}
	return got.String
}

func readStatus(t *testing.T, db *sql.DB, id string) types.Status {
	t.Helper()
	var got string
	err := db.QueryRowContext(context.Background(),
		"SELECT status FROM issues WHERE id = ?", id).Scan(&got)
	if err == sql.ErrNoRows {
		if err := db.QueryRowContext(context.Background(),
			"SELECT status FROM wisps WHERE id = ?", id).Scan(&got); err != nil {
			t.Fatalf("read status for %s: %v", id, err)
		}
	} else if err != nil {
		t.Fatalf("read status for %s: %v", id, err)
	}
	return types.Status(got)
}

func readAssignee(t *testing.T, db *sql.DB, id string) string {
	t.Helper()
	var got sql.NullString
	err := db.QueryRowContext(context.Background(),
		"SELECT assignee FROM issues WHERE id = ?", id).Scan(&got)
	if err == sql.ErrNoRows {
		if err := db.QueryRowContext(context.Background(),
			"SELECT assignee FROM wisps WHERE id = ?", id).Scan(&got); err != nil {
			t.Fatalf("read assignee for %s: %v", id, err)
		}
	} else if err != nil {
		t.Fatalf("read assignee for %s: %v", id, err)
	}
	if !got.Valid {
		return ""
	}
	return got.String
}

func readDoltHead(t *testing.T, db *sql.DB) string {
	t.Helper()
	var h string
	if err := db.QueryRowContext(context.Background(), "SELECT HASHOF('HEAD')").Scan(&h); err != nil {
		t.Fatalf("read HEAD: %v", err)
	}
	return h
}

func readDoltLogTopMessage(t *testing.T, db *sql.DB) string {
	t.Helper()
	var msg string
	if err := db.QueryRowContext(context.Background(),
		"SELECT message FROM dolt_log ORDER BY date DESC LIMIT 1").Scan(&msg); err != nil {
		t.Fatalf("read latest dolt_log message: %v", err)
	}
	return msg
}

func readDoltLogCountSince(t *testing.T, db *sql.DB, sinceHash string) int {
	t.Helper()
	rows, err := db.QueryContext(context.Background(),
		"SELECT commit_hash FROM dolt_log ORDER BY date DESC")
	if err != nil {
		t.Fatalf("read dolt_log: %v", err)
	}
	defer rows.Close()
	n := 0
	for rows.Next() {
		var h string
		if err := rows.Scan(&h); err != nil {
			t.Fatalf("scan dolt_log: %v", err)
		}
		if h == sinceHash {
			return n
		}
		n++
	}
	if err := rows.Err(); err != nil {
		t.Fatalf("iter dolt_log: %v", err)
	}
	return n
}

func TestProxiedServerClose(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	t.Run("basic_close", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cb")
		issue := bdProxiedCreate(t, bd, p.dir, "Close me")
		bdProxiedClose(t, bd, p.dir, issue.ID)
		got := bdProxiedShow(t, bd, p.dir, issue.ID)
		if got.Status != types.StatusClosed {
			t.Errorf("status: got %q, want closed", got.Status)
		}
		if got.ClosedAt == nil {
			t.Error("closed_at should be set")
		}
	})

	t.Run("close_default_reason", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cdr")
		issue := bdProxiedCreate(t, bd, p.dir, "Default reason")
		bdProxiedClose(t, bd, p.dir, issue.ID)
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "Closed" {
			t.Errorf("close_reason: got %q, want %q", got, "Closed")
		}
	})

	t.Run("close_with_reason", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwr")
		issue := bdProxiedCreate(t, bd, p.dir, "Reason test")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--reason", "done")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "done" {
			t.Errorf("close_reason: got %q, want %q", got, "done")
		}
	})

	t.Run("close_with_reason_short", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwrs")
		issue := bdProxiedCreate(t, bd, p.dir, "Short reason")
		bdProxiedClose(t, bd, p.dir, issue.ID, "-r", "fixed")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "fixed" {
			t.Errorf("close_reason: got %q, want %q", got, "fixed")
		}
	})

	t.Run("close_with_message_alias", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwma")
		issue := bdProxiedCreate(t, bd, p.dir, "Message alias")
		bdProxiedClose(t, bd, p.dir, issue.ID, "-m", "via message")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "via message" {
			t.Errorf("close_reason: got %q, want %q", got, "via message")
		}
	})

	t.Run("close_with_resolution_alias", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwra")
		issue := bdProxiedCreate(t, bd, p.dir, "Resolution alias")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--resolution", "wontfix")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "wontfix" {
			t.Errorf("close_reason: got %q, want %q", got, "wontfix")
		}
	})
}

// TestProxiedServerCloseB holds more of TestProxiedServerClose's cases, split
// off so the bd_proxied_test shard manifest can place them on another shard.
func TestProxiedServerCloseB(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	t.Run("close_with_comment_alias", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwca")
		issue := bdProxiedCreate(t, bd, p.dir, "Comment alias")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--comment", "duplicate")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "duplicate" {
			t.Errorf("close_reason: got %q, want %q", got, "duplicate")
		}
	})

	t.Run("close_multiple_ids", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cmi")
		a := bdProxiedCreate(t, bd, p.dir, "Multi A")
		b := bdProxiedCreate(t, bd, p.dir, "Multi B")
		bdProxiedClose(t, bd, p.dir, a.ID, b.ID)
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, a.ID); got != types.StatusClosed {
			t.Errorf("a status: got %q, want closed", got)
		}
		if got := readStatus(t, db, b.ID); got != types.StatusClosed {
			t.Errorf("b status: got %q, want closed", got)
		}
	})

	t.Run("close_multiple_ids_with_per_id_reasons", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cmpr")
		a := bdProxiedCreate(t, bd, p.dir, "Multi reason A")
		b := bdProxiedCreate(t, bd, p.dir, "Multi reason B")
		bdProxiedClose(t, bd, p.dir, a.ID, "--reason", "fixed A", b.ID, "--reason", "fixed B")
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, a.ID); got != "fixed A" {
			t.Errorf("a reason: got %q, want %q", got, "fixed A")
		}
		if got := readCloseReason(t, db, b.ID); got != "fixed B" {
			t.Errorf("b reason: got %q, want %q", got, "fixed B")
		}
	})

	t.Run("close_already_closed", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cac")
		issue := bdProxiedCreate(t, bd, p.dir, "Double close")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--reason", "first")
		stdout, stderr, err := bdProxiedRunBuffers(t, bd, p.dir, "close", issue.ID, "--reason", "second")
		_ = stdout
		_ = stderr
		_ = err
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "first" {
			t.Errorf("re-close must not overwrite reason: got %q, want %q", got, "first")
		}
	})

	t.Run("close_nonexistent_id", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cni")
		out := bdProxiedCloseFail(t, bd, p.dir, "cni-does-not-exist")
		if !strings.Contains(out, "not found") {
			t.Errorf("expected 'not found' error, got: %s", out)
		}
	})
}

// TestProxiedServerClose3 was split off TestProxiedServerClose in
// gastownhall/beads#7173 (as TestProxiedServerClose2 was before it) so that
// no single top-level suite carries 23 bd-init subtests: that one parent
// alone cost ~2060 slot-seconds under -test.parallel=4 and pushed its shard
// of the since-retired 15-shard legacy jobs past go test's 15m timeout on
// every run. Those 23 now sit in TestProxiedServerClose,
// TestProxiedServerCloseB, TestProxiedServerClose3 and
// TestProxiedServerClose4. Its own second half is TestProxiedServerClose4.
func TestProxiedServerClose3(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	t.Run("close_blocked_refuses_without_force", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbr")
		blocker := bdProxiedCreate(t, bd, p.dir, "Blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "Blocked", "--deps", "depends-on:"+blocker.ID)
		out := bdProxiedCloseFail(t, bd, p.dir, blocked.ID)
		if !strings.Contains(out, "blocked by") {
			t.Errorf("expected blocker error, got: %s", out)
		}
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, blocked.ID); got == types.StatusClosed {
			t.Error("blocked issue should remain open without --force")
		}
	})

	t.Run("close_blocked_with_force", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbf")
		blocker := bdProxiedCreate(t, bd, p.dir, "Blocker force")
		blocked := bdProxiedCreate(t, bd, p.dir, "Blocked force", "--deps", "depends-on:"+blocker.ID)
		bdProxiedClose(t, bd, p.dir, blocked.ID, "--force")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, blocked.ID); got != types.StatusClosed {
			t.Errorf("status with --force: got %q, want closed", got)
		}
	})

	t.Run("close_partial_failure_exits_nonzero", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cpf")
		closable := bdProxiedCreate(t, bd, p.dir, "Closable")
		blocker := bdProxiedCreate(t, bd, p.dir, "Blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "Blocked", "--deps", "depends-on:"+blocker.ID)
		out := bdProxiedCloseFail(t, bd, p.dir, closable.ID, blocked.ID)
		if !strings.Contains(out, "1 of 2 issues failed to close") {
			t.Errorf("expected partial-failure summary, got: %s", out)
		}
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, closable.ID); got != types.StatusClosed {
			t.Errorf("closable issue status = %q, want closed despite the refused sibling", got)
		}
		if got := readStatus(t, db, blocked.ID); got == types.StatusClosed {
			t.Error("blocked issue should remain open without --force")
		}
	})

	// The machine-readable half of the #6648 contract. A JSON consumer is
	// exactly the caller the issue was filed for, so exit 1 must come with a
	// payload naming the failed ids instead of prose it would have to scrape —
	// while stdout keeps the success-shaped closed-issues array, the way
	// bd update's reportUpdateFailures already splits them.
	t.Run("close_partial_failure_json_names_the_failed_ids", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cpj")
		closable := bdProxiedCreate(t, bd, p.dir, "JSON closable")
		blocker := bdProxiedCreate(t, bd, p.dir, "JSON blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "JSON blocked", "--deps", "depends-on:"+blocker.ID)

		stdout, stderr, err := bdProxiedRunBuffers(t, bd, p.dir, "close", "--json", closable.ID, blocked.ID)
		if err == nil {
			t.Fatalf("expected a partial batch close to exit nonzero\nstdout:\n%s\nstderr:\n%s", stdout, stderr)
		}

		// stdout keeps the success shape: just the survivor.
		start := strings.Index(stdout, "[")
		if start < 0 {
			t.Fatalf("expected the closed-issues array on stdout, got:\n%s", stdout)
		}
		var closed []*types.Issue
		if jsonErr := json.Unmarshal([]byte(stdout[start:]), &closed); jsonErr != nil {
			t.Fatalf("parse closed array: %v\nraw: %s", jsonErr, stdout[start:])
		}
		if len(closed) != 1 || closed[0].ID != closable.ID {
			t.Fatalf("stdout closed array = %d issue(s) %v, want only the survivor %s", len(closed), closed, closable.ID)
		}

		// stderr's last line is the failure report.
		line := lastJSONObjectLine(stderr)
		if line == "" {
			t.Fatalf("expected a compact JSON failure line on stderr, got:\n%s", stderr)
		}
		var report struct {
			Error  string `json:"error"`
			Failed []struct {
				ID    string `json:"id"`
				Error string `json:"error"`
			} `json:"failed"`
		}
		if jsonErr := json.Unmarshal([]byte(line), &report); jsonErr != nil {
			t.Fatalf("parse failure report: %v\nraw: %s", jsonErr, line)
		}
		if report.Error != "1 of 2 issues failed to close" {
			t.Errorf("failure report error = %q, want the N of M summary", report.Error)
		}
		if len(report.Failed) != 1 || report.Failed[0].ID != blocked.ID {
			t.Fatalf("failure report named %+v, want exactly the refused id %s", report.Failed, blocked.ID)
		}
		if report.Failed[0].Error == "" {
			t.Errorf("failure report for %s carried no reason", blocked.ID)
		}

		// failed[].error is the TYPED error, the same on this route as on the
		// direct one — see the twin assertions in TestEmbeddedCloseBasic/
		// close_partial_failure_json_names_the_failed_ids. The --force hint is
		// advice for a human reader, so it belongs on the stderr line above and
		// not in the field a --json consumer keys off; recording the decorated
		// display line here gave the identical refusal two spellings depending
		// on which route the caller was on.
		assertCloseFailedErrorIsTyped(t, report.Failed[0].Error, stderr)
	})

	t.Run("close_pinned_refuses_without_force", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cpr")
		issue := bdProxiedCreate(t, bd, p.dir, "Pinned")
		bdProxiedUpdateOne(t, bd, p.dir, issue.ID, "-s", "pinned")
		bdProxiedCloseFail(t, bd, p.dir, issue.ID)
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, issue.ID); got == types.StatusClosed {
			t.Error("pinned issue should remain pinned without --force")
		}
	})

	t.Run("close_pinned_with_force", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cpf")
		issue := bdProxiedCreate(t, bd, p.dir, "Pinned force")
		bdProxiedUpdateOne(t, bd, p.dir, issue.ID, "-s", "pinned")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--force")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, issue.ID); got != types.StatusClosed {
			t.Errorf("status: got %q, want closed", got)
		}
	})
}

// TestProxiedServerClose4 is the second half of TestProxiedServerClose3. With
// all 12 of its bd-init subtests in one parent, whichever 15-shard legacy
// shard hosted Close3 timed out in turn (6, then 1) while shard 5 dropped to
// 5m, so the remaining weight is carried as two parents of six on two shards
// (gastownhall/beads#7173).
func TestProxiedServerClose4(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	// ga-ktn9pe.4.8: this used to have an embedded twin
	// (TestEmbeddedClose/close_boolean_pinned_reclose_is_idempotent), but
	// bd-1rh.1 (#5287) trimmed it along with the embedded suite's other
	// pinned-close subtests as redundant with this proxied coverage, so this
	// is now the sole owner of the boolean-pinned-reclose contract. Both
	// close paths had to agree before the trim — a fix on one only was the
	// divergence class #5217 just closed — so treat any future embedded
	// pinned-close test as needing to stay consistent with this one.
	t.Run("close_boolean_pinned_reclose_is_idempotent", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbpr")
		plan := `{"nodes": [{"key": "p", "title": "Boolean pinned", "type": "task", "pinned": true}]}`
		planFile := filepath.Join(p.dir, "boolean-pinned-plan.json")
		if err := os.WriteFile(planFile, []byte(plan), 0644); err != nil {
			t.Fatal(err)
		}
		out, err := bdProxiedRun(t, bd, p.dir, "create", "--graph", planFile, "--json")
		if err != nil {
			t.Fatalf("bd create --graph failed: %v\n%s", err, out)
		}
		var created GraphApplyResult
		if err := json.Unmarshal(out, &created); err != nil {
			t.Fatalf("parse graph result: %v\nstdout:\n%s", err, out)
		}
		id := created.IDs["p"]
		if id == "" {
			t.Fatalf("expected an ID for key p, got %#v", created.IDs)
		}
		if seeded := bdProxiedShow(t, bd, p.dir, id); !seeded.Pinned {
			t.Fatalf("precondition: expected pinned=true on the seeded bead, got %+v", seeded)
		}

		bdProxiedClose(t, bd, p.dir, id, "--force")
		// No --force on the retry. Pre-fix this exited nonzero with the pinned
		// refusal, so bdProxiedClose's t.Fatalf is the red assertion.
		bdProxiedClose(t, bd, p.dir, id)

		got := bdProxiedShow(t, bd, p.dir, id)
		if got.Status != types.StatusClosed {
			t.Errorf("status: got %q, want closed", got.Status)
		}
		if !got.Pinned {
			t.Error("expected the pin to survive the close: it is what protects the row from bd gc/purge/cleanup")
		}
	})

	t.Run("close_epic_open_children_refuses", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ceor")
		epic := bdProxiedCreate(t, bd, p.dir, "Epic", "-t", "epic")
		_ = bdProxiedCreate(t, bd, p.dir, "Child", "--parent", epic.ID)
		out := bdProxiedCloseFail(t, bd, p.dir, epic.ID)
		if !strings.Contains(out, "open child") {
			t.Errorf("expected 'open child' error, got: %s", out)
		}
	})

	t.Run("close_epic_open_children_force", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ceof")
		epic := bdProxiedCreate(t, bd, p.dir, "Epic force", "-t", "epic")
		_ = bdProxiedCreate(t, bd, p.dir, "Child force", "--parent", epic.ID)
		bdProxiedClose(t, bd, p.dir, epic.ID, "--force")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, epic.ID); got != types.StatusClosed {
			t.Errorf("status: got %q, want closed", got)
		}
	})

	t.Run("close_last_child_keeps_regular_epic_open", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "clce")
		epic := bdProxiedCreate(t, bd, p.dir, "Regular epic", "-t", "epic")
		child := bdProxiedCreate(t, bd, p.dir, "Last child", "--parent", epic.ID)
		bdProxiedClose(t, bd, p.dir, child.ID)
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, epic.ID); got != types.StatusOpen {
			t.Errorf("regular epic should stay open after last child closes, got %q", got)
		}
	})

	t.Run("close_unblocks_dependent", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cud")
		blocker := bdProxiedCreate(t, bd, p.dir, "Unblock blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "Unblock blocked", "--deps", "depends-on:"+blocker.ID)
		db := openProxiedDB(t, p)
		if !readIsBlocked(t, db, blocked.ID) {
			t.Fatal("dependent should be blocked before blocker closes")
		}
		bdProxiedClose(t, bd, p.dir, blocker.ID)
		if readIsBlocked(t, db, blocked.ID) {
			t.Error("dependent should be unblocked after blocker closes")
		}
	})

	t.Run("close_suggest_next", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "csn")
		blocker := bdProxiedCreate(t, bd, p.dir, "Suggest blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "Suggest blocked", "--deps", "depends-on:"+blocker.ID)
		out := bdProxiedClose(t, bd, p.dir, blocker.ID, "--suggest-next")
		if !strings.Contains(out, blocked.ID) {
			t.Errorf("suggest-next output missing unblocked id %s:\n%s", blocked.ID, out)
		}
	})

}

func TestProxiedServerClose2(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	t.Run("close_suggest_next_json", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "csnj")
		blocker := bdProxiedCreate(t, bd, p.dir, "Suggest JSON blocker")
		blocked := bdProxiedCreate(t, bd, p.dir, "Suggest JSON blocked", "--deps", "depends-on:"+blocker.ID)
		env := bdProxiedCloseJSONEnvelope(t, bd, p.dir, blocker.ID, "--suggest-next")
		raw, ok := env["unblocked"]
		if !ok {
			t.Fatalf("envelope missing 'unblocked' key: %v", env)
		}
		var unblocked []*types.Issue
		if err := json.Unmarshal(raw, &unblocked); err != nil {
			t.Fatalf("parse unblocked: %v\n%s", err, string(raw))
		}
		if len(unblocked) != 1 || unblocked[0].ID != blocked.ID {
			t.Errorf("unblocked: got %+v, want [%s]", unblocked, blocked.ID)
		}
	})

	t.Run("close_claim_next", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ccn")
		toClose := bdProxiedCreate(t, bd, p.dir, "Claim next close")
		nextIssue := bdProxiedCreate(t, bd, p.dir, "Claim next target")
		bdProxiedClose(t, bd, p.dir, toClose.ID, "--claim-next")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, nextIssue.ID); got != types.StatusInProgress {
			t.Errorf("next issue status: got %q, want in_progress", got)
		}
		if got := readAssignee(t, db, nextIssue.ID); got == "" {
			t.Error("next issue assignee should be set after --claim-next")
		}
	})

	t.Run("close_claim_next_no_ready", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ccnr")
		issue := bdProxiedCreate(t, bd, p.dir, "Only issue")
		out := bdProxiedClose(t, bd, p.dir, issue.ID, "--claim-next")
		if !strings.Contains(out, "No ready issues") {
			t.Errorf("expected 'No ready issues', got: %s", out)
		}
	})

	t.Run("close_claim_next_json", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ccnj")
		toClose := bdProxiedCreate(t, bd, p.dir, "Claim JSON close")
		_ = bdProxiedCreate(t, bd, p.dir, "Claim JSON target")
		env := bdProxiedCloseJSONEnvelope(t, bd, p.dir, toClose.ID, "--claim-next")
		if _, ok := env["closed"]; !ok {
			t.Errorf("envelope missing 'closed' key: %v", env)
		}
		if _, ok := env["claimed"]; !ok {
			t.Errorf("envelope missing 'claimed' key: %v", env)
		}
	})

	t.Run("close_with_session", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cws")
		issue := bdProxiedCreate(t, bd, p.dir, "Session flag")
		bdProxiedClose(t, bd, p.dir, issue.ID, "--session", "sess-456")
		db := openProxiedDB(t, p)
		if got := readClosedBySession(t, db, issue.ID); got != "sess-456" {
			t.Errorf("closed_by_session: got %q, want %q", got, "sess-456")
		}
	})

	t.Run("close_session_from_env", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cse")
		issue := bdProxiedCreate(t, bd, p.dir, "Session env")
		if _, stderr, err := bdProxiedRunEnv(t, bd, p.dir, []string{"CLAUDE_SESSION_ID=sess-env"}, "close", issue.ID); err != nil {
			t.Fatalf("close failed: %v\n%s", err, stderr)
		}
		db := openProxiedDB(t, p)
		if got := readClosedBySession(t, db, issue.ID); got != "sess-env" {
			t.Errorf("closed_by_session: got %q, want %q", got, "sess-env")
		}
	})

	t.Run("close_json_output", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cjo")
		issue := bdProxiedCreate(t, bd, p.dir, "JSON close")
		issues := bdProxiedCloseJSON(t, bd, p.dir, issue.ID)
		if len(issues) != 1 || issues[0].ID != issue.ID {
			t.Errorf("close JSON: got %+v, want [%s]", issues, issue.ID)
		}
		if issues[0].Status != types.StatusClosed {
			t.Errorf("returned issue status: got %q, want closed", issues[0].Status)
		}
	})

	t.Run("done_alias", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "da")
		issue := bdProxiedCreate(t, bd, p.dir, "Done alias")
		stdout, stderr, err := bdProxiedRunBuffers(t, bd, p.dir, "done", issue.ID)
		if err != nil {
			t.Fatalf("bd done failed: %v\nstdout:\n%s\nstderr:\n%s", err, stdout, stderr)
		}
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, issue.ID); got != types.StatusClosed {
			t.Errorf("status via done alias: got %q, want closed", got)
		}
	})

	t.Run("done_positional_reason", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "dpr")
		issue := bdProxiedCreate(t, bd, p.dir, "Done reason")
		stdout, stderr, err := bdProxiedRunBuffers(t, bd, p.dir, "done", issue.ID, "the reason")
		if err != nil {
			t.Fatalf("bd done with reason failed: %v\nstdout:\n%s\nstderr:\n%s", err, stdout, stderr)
		}
		db := openProxiedDB(t, p)
		if got := readCloseReason(t, db, issue.ID); got != "the reason" {
			t.Errorf("close_reason: got %q, want %q", got, "the reason")
		}
	})

	t.Run("close_continue_multiple_ids_fails", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ccmi")
		a := bdProxiedCreate(t, bd, p.dir, "Continue multi A")
		b := bdProxiedCreate(t, bd, p.dir, "Continue multi B")
		out := bdProxiedCloseFail(t, bd, p.dir, a.ID, b.ID, "--continue")
		if !strings.Contains(out, "single issue") {
			t.Errorf("expected single-issue error, got: %s", out)
		}
	})
}

// TestProxiedServerClose2B holds more of TestProxiedServerClose2's cases, split
// off so the bd_proxied_test shard manifest can place them on another shard.
func TestProxiedServerClose2B(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	t.Run("close_suggest_next_multiple_ids_fails", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "csmi")
		a := bdProxiedCreate(t, bd, p.dir, "Suggest multi A")
		b := bdProxiedCreate(t, bd, p.dir, "Suggest multi B")
		out := bdProxiedCloseFail(t, bd, p.dir, a.ID, b.ID, "--suggest-next")
		if !strings.Contains(out, "single issue") {
			t.Errorf("expected single-issue error, got: %s", out)
		}
	})

	t.Run("single_transaction_dolt_commit", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "stdc")
		a := bdProxiedCreate(t, bd, p.dir, "Tx A")
		b := bdProxiedCreate(t, bd, p.dir, "Tx B")
		c := bdProxiedCreate(t, bd, p.dir, "Tx C")
		db := openProxiedDB(t, p)
		before := readDoltHead(t, db)
		bdProxiedClose(t, bd, p.dir, a.ID, b.ID, c.ID)
		count := readDoltLogCountSince(t, db, before)
		if count != 1 {
			t.Errorf("expected exactly 1 new dolt commit for batch close, got %d", count)
		}
		msg := readDoltLogTopMessage(t, db)
		for _, id := range []string{a.ID, b.ID, c.ID} {
			if !strings.Contains(msg, id) {
				t.Errorf("dolt commit message %q should contain id %s", msg, id)
			}
		}
		if !strings.HasPrefix(msg, "bd: close ") {
			t.Errorf("dolt commit message should begin with 'bd: close ', got: %q", msg)
		}
	})

	t.Run("no_ids_errors", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "nie")
		out := bdProxiedCloseFail(t, bd, p.dir)
		if !strings.Contains(out, "no issue ID provided") {
			t.Errorf("expected 'no issue ID provided', got: %s", out)
		}
	})

	t.Run("last_touched_not_supported", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "ltns")
		_ = bdProxiedCreate(t, bd, p.dir, "Recent create")
		out := bdProxiedCloseFail(t, bd, p.dir)
		if !strings.Contains(out, "no issue ID provided") {
			t.Errorf("proxied mode must not fall back to last-touched; got: %s", out)
		}
	})

	t.Run("close_wisp_issue", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwi")
		wisp := bdProxiedCreate(t, bd, p.dir, "Wisp close", "--ephemeral")
		bdProxiedClose(t, bd, p.dir, wisp.ID)
		db := openProxiedDB(t, p)
		var status string
		if err := db.QueryRowContext(context.Background(),
			"SELECT status FROM wisps WHERE id = ?", wisp.ID).Scan(&status); err != nil {
			t.Fatalf("read wisp status: %v", err)
		}
		if types.Status(status) != types.StatusClosed {
			t.Errorf("wisp status: got %q, want closed", status)
		}
	})

	t.Run("close_wisp_epic_open_children", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cweoc")
		wispEpic := bdProxiedCreate(t, bd, p.dir, "Wisp epic", "-t", "epic", "--ephemeral")
		_ = bdProxiedCreate(t, bd, p.dir, "Wisp child", "--ephemeral", "--parent", wispEpic.ID)
		out := bdProxiedCloseFail(t, bd, p.dir, wispEpic.ID)
		if !strings.Contains(out, "open child") {
			t.Errorf("expected 'open child' error for wisp epic, got: %s", out)
		}
	})

	t.Run("close_wisp_blocked_refuses", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cwbr")
		blocker := bdProxiedCreate(t, bd, p.dir, "Blocker for wisp")
		wisp := bdProxiedCreate(t, bd, p.dir, "Blocked wisp", "--ephemeral", "--deps", "depends-on:"+blocker.ID)
		out := bdProxiedCloseFail(t, bd, p.dir, wisp.ID)
		if !strings.Contains(out, "blocked by") {
			t.Errorf("expected wisp blocker error, got: %s", out)
		}
	})

	t.Run("continue_advances_to_next_ready_step", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cantrs")
		root := bdProxiedCreate(t, bd, p.dir, "Molecule root", "-t", "epic", "--labels", "template")
		step1 := bdProxiedCreate(t, bd, p.dir, "Step 1", "--parent", root.ID)
		step2 := bdProxiedCreate(t, bd, p.dir, "Step 2", "--parent", root.ID, "--deps", "depends-on:"+step1.ID)
		_ = bdProxiedCreate(t, bd, p.dir, "Step 3", "--parent", root.ID, "--deps", "depends-on:"+step2.ID)
		bdProxiedClose(t, bd, p.dir, step1.ID, "--continue")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, step2.ID); got != types.StatusInProgress {
			t.Errorf("step2 status after --continue: got %q, want in_progress", got)
		}
		if readAssignee(t, db, step2.ID) == "" {
			t.Error("step2 assignee should be set after --continue auto-claim")
		}
	})

	t.Run("continue_no_auto_does_not_claim", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cnac")
		root := bdProxiedCreate(t, bd, p.dir, "Molecule root", "-t", "epic", "--labels", "template")
		step1 := bdProxiedCreate(t, bd, p.dir, "Step 1", "--parent", root.ID)
		step2 := bdProxiedCreate(t, bd, p.dir, "Step 2", "--parent", root.ID, "--deps", "depends-on:"+step1.ID)
		bdProxiedClose(t, bd, p.dir, step1.ID, "--continue", "--no-auto")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, step2.ID); got != types.StatusOpen {
			t.Errorf("step2 status with --no-auto: got %q, want open", got)
		}
		if readAssignee(t, db, step2.ID) != "" {
			t.Error("step2 assignee should NOT be set with --no-auto")
		}
	})

	t.Run("auto_close_completed_molecule", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "accm")
		root := bdProxiedCreate(t, bd, p.dir, "Molecule root", "-t", "epic", "--labels", "template")
		s1 := bdProxiedCreate(t, bd, p.dir, "Step 1", "--parent", root.ID)
		s2 := bdProxiedCreate(t, bd, p.dir, "Step 2", "--parent", root.ID)
		bdProxiedClose(t, bd, p.dir, s1.ID, s2.ID)
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, root.ID); got != types.StatusClosed {
			t.Errorf("template-labeled molecule root should auto-close after all steps complete, got %q", got)
		}
		if got := readCloseReason(t, db, root.ID); got != "all steps complete" {
			t.Errorf("auto-close reason: got %q, want %q", got, "all steps complete")
		}
	})

	t.Run("json_reports_auto_closed_molecule", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "jacm")
		root := bdProxiedCreate(t, bd, p.dir, "Molecule root", "-t", "epic", "--labels", "template")
		s1 := bdProxiedCreate(t, bd, p.dir, "Step 1", "--parent", root.ID)
		s2 := bdProxiedCreate(t, bd, p.dir, "Step 2", "--parent", root.ID)
		s3 := bdProxiedCreate(t, bd, p.dir, "Step 3", "--parent", root.ID)
		bdProxiedClose(t, bd, p.dir, s1.ID)
		out := bdProxiedClose(t, bd, p.dir, "--json", s2.ID, s3.ID)
		requireCloseJSONReportsAutoClosedMolecule(t, out, []string{s2.ID, s3.ID}, root.ID)
	})

	t.Run("json_reports_molecule_auto_close_refusal", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "jmar")
		root := bdProxiedCreate(t, bd, p.dir, "Molecule root", "-t", "epic", "--labels", "template", "--assignee", "someone-else")
		s1 := bdProxiedCreate(t, bd, p.dir, "Step 1", "--parent", root.ID)
		out := bdProxiedClose(t, bd, p.dir, "--actor", "json-closer", "--json", s1.ID)
		requireCloseJSONReportsMoleculeRefusal(t, out, s1.ID, root.ID,
			&issueops.CloseNotAssigneeError{IssueID: root.ID, Assignee: "someone-else", Actor: "json-closer"})
		if got := readStatus(t, openProxiedDB(t, p), root.ID); got != types.StatusOpen {
			t.Errorf("a root assigned to another actor must stay open, got %q", got)
		}
	})

	t.Run("hooks_fire_on_close", func(t *testing.T) {
		t.Parallel()
		marker := filepath.Join(t.TempDir(), "on_close_marker")
		script := "#!/bin/sh\nprintf '%s\\n' \"$1\" > " + shellQuote(marker) + "\n"
		if runtime.GOOS == "windows" {
			t.Skip("hook script form is POSIX shell")
		}
		p := newSharedProxiedProjectWithHooks(t, bd, "hfc", map[string]string{"on_close": script})
		issue := bdProxiedCreate(t, bd, p.dir, "Hook fire")
		bdProxiedClose(t, bd, p.dir, issue.ID)
		// Polled, not read once: hooks fire fire-and-forget off the write
		// plumbing now, so the marker appears shortly AFTER the command exits
		// rather than during it.
		data, err := waitForMarker(marker, 5*time.Second)
		if err != nil {
			t.Fatalf("on_close hook did not fire within timeout: %v", err)
		}
		if !strings.Contains(data, issue.ID) {
			t.Errorf("hook marker missing issue ID; got: %q", data)
		}
	})
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func TestProxiedServerCloseConcurrent(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	p := newSharedProxiedProject(t, bd, "cxc")

	const (
		numWorkers      = 10
		issuesPerWorker = 5
	)

	type ws struct {
		closed int
		errs   []string
	}
	results := make([]ws, numWorkers)
	var wg sync.WaitGroup
	wg.Add(numWorkers)

	for w := 0; w < numWorkers; w++ {
		w := w
		go func() {
			defer wg.Done()
			r := &results[w]
			for i := 0; i < issuesPerWorker; i++ {
				title := fmt.Sprintf("worker-%d-issue-%d", w, i)
				cmd := exec.Command(bd, "create", "--json", title)
				cmd.Dir = p.dir
				cmd.Env = bdProxiedEnv(p.dir)
				var stdout, stderr bytes.Buffer
				cmd.Stdout = &stdout
				cmd.Stderr = &stderr
				if err := cmd.Run(); err != nil {
					r.errs = append(r.errs, fmt.Sprintf("create %s: %v\n%s", title, err, stderr.String()))
					continue
				}
				out := stdout.Bytes()
				start := bytes.Index(out, []byte("{"))
				if start < 0 {
					r.errs = append(r.errs, "no JSON in create output")
					continue
				}
				var issue types.Issue
				if err := json.Unmarshal(out[start:], &issue); err != nil {
					r.errs = append(r.errs, fmt.Sprintf("parse create JSON: %v", err))
					continue
				}

				closeCmd := exec.Command(bd, "close", issue.ID)
				closeCmd.Dir = p.dir
				closeCmd.Env = bdProxiedEnv(p.dir)
				var cstdout, cstderr bytes.Buffer
				closeCmd.Stdout = &cstdout
				closeCmd.Stderr = &cstderr
				if err := closeCmd.Run(); err != nil {
					r.errs = append(r.errs, fmt.Sprintf("close %s: %v\n%s", issue.ID, err, cstderr.String()))
					continue
				}
				r.closed++
			}
		}()
	}
	wg.Wait()

	totalClosed := 0
	for w, r := range results {
		totalClosed += r.closed
		for _, e := range r.errs {
			t.Errorf("worker %d: %s", w, e)
		}
	}
	want := numWorkers * issuesPerWorker
	if totalClosed != want {
		t.Errorf("closed count: got %d, want %d", totalClosed, want)
	}

	db := openProxiedDB(t, p)
	var openCount int
	if err := db.QueryRowContext(context.Background(),
		"SELECT COUNT(*) FROM issues WHERE status != 'closed'").Scan(&openCount); err != nil {
		t.Fatalf("query open count: %v", err)
	}
	if openCount != 0 {
		t.Errorf("open issues remain after concurrent close: %d", openCount)
	}
}

// bd close on a bead gate evaluates the awaited bead through the proxied read
// path. Before #5861 item 1 was fixed this route refused every bead gate with
// "no local store available", closed target or not, while bd gate check
// resolved the same gate.
func TestProxiedServerCloseBeadGate(t *testing.T) {
	requireSharedProxiedServer(t)
	t.Parallel()
	bd := buildEmbeddedBD(t)

	createBeadGate := func(t *testing.T, p proxiedProject) (gateID string, awaited *types.Issue) {
		t.Helper()
		parked := bdProxiedCreate(t, bd, p.dir, "Parked bead")
		awaited = bdProxiedCreate(t, bd, p.dir, "Awaited bead")
		out, stderr, err := bdProxiedRunBuffers(t, bd, p.dir,
			"gate", "create", "--type=bead", "--blocks", parked.ID, "--await-id", awaited.ID, "--reason", "waiting on "+awaited.ID)
		if err != nil {
			t.Fatalf("bead gate create failed: %v\nstderr:\n%s", err, stderr)
		}
		return parseCreatedGateID(t, out), awaited
	}

	t.Run("awaited_open_refuses_with_its_status", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbgo")
		gateID, awaited := createBeadGate(t, p)

		out := bdProxiedCloseFail(t, bd, p.dir, gateID)
		if strings.Contains(out, "no local store available") {
			t.Errorf("close read the gate through a store-less getter:\n%s", out)
		}
		if !strings.Contains(out, "gate condition not satisfied") || !strings.Contains(out, "bead "+awaited.ID+" is open") {
			t.Errorf("expected the awaited bead's status in the refusal, got:\n%s", out)
		}
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, gateID); got != types.StatusOpen {
			t.Errorf("refused gate should stay open, got %q", got)
		}
	})

	t.Run("awaited_closed_closes", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbgc")
		gateID, awaited := createBeadGate(t, p)

		bdProxiedClose(t, bd, p.dir, awaited.ID)
		bdProxiedClose(t, bd, p.dir, gateID, "-r", "awaited bead closed")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, gateID); got != types.StatusClosed {
			t.Errorf("gate should close once its awaited bead is closed, got %q", got)
		}
		if got := readCloseReason(t, db, gateID); got != "awaited bead closed" {
			t.Errorf("close_reason: got %q, want %q", got, "awaited bead closed")
		}
	})

	t.Run("force_skips_the_check", func(t *testing.T) {
		t.Parallel()
		p := newSharedProxiedProject(t, bd, "cbgf")
		gateID, _ := createBeadGate(t, p)

		bdProxiedClose(t, bd, p.dir, gateID, "--force")
		db := openProxiedDB(t, p)
		if got := readStatus(t, db, gateID); got != types.StatusClosed {
			t.Errorf("--force should close the gate regardless, got %q", got)
		}
	})
}
