package doctor

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/steveyegge/beads/cmd/bd/doctor/fix"
	"github.com/steveyegge/beads/internal/configfile"
)

func TestCheckClassicArtifacts_NoArtifacts(t *testing.T) {
	dir := t.TempDir()

	// Create a basic .beads directory with no artifacts
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	check := CheckClassicArtifacts(dir)
	if check.Status != StatusOK {
		t.Errorf("expected StatusOK, got %s: %s", check.Status, check.Message)
	}
}

// TestScanForArtifacts_JSONLInDoltDir — JSONL artifact scanning removed (bd-9ni.2)
func TestScanForArtifacts_JSONLInDoltDir(t *testing.T) {
	t.Skip("JSONL artifact scanning removed as part of JSONL removal (bd-9ni.2)")
}

func TestScanForArtifacts_SQLiteFiles(t *testing.T) {
	dir := t.TempDir()

	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create dolt/ directory so isDoltNative returns true (SQLite files
	// are only flagged as artifacts when Dolt is the active backend)
	if err := os.MkdirAll(filepath.Join(beadsDir, "dolt"), 0755); err != nil {
		t.Fatal(err)
	}

	// Create SQLite artifacts
	for _, name := range []string{"beads.db", "beads.db-shm", "beads.db-wal", "beads.backup-20260204.db"} {
		if err := os.WriteFile(filepath.Join(beadsDir, name), []byte("data"), 0644); err != nil {
			t.Fatal(err)
		}
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.SQLiteArtifacts) != 4 {
		t.Errorf("expected 4 SQLite artifacts, got %d", len(report.SQLiteArtifacts))
	}

	// beads.db should NOT be safe to delete
	for _, f := range report.SQLiteArtifacts {
		if filepath.Base(f.Path) == "beads.db" && f.SafeDelete {
			t.Error("beads.db should NOT be safe to delete")
		}
	}

	// WAL/SHM should be safe
	for _, f := range report.SQLiteArtifacts {
		name := filepath.Base(f.Path)
		if (name == "beads.db-shm" || name == "beads.db-wal") && !f.SafeDelete {
			t.Errorf("%s should be safe to delete", name)
		}
	}

	// Backup should be safe
	for _, f := range report.SQLiteArtifacts {
		name := filepath.Base(f.Path)
		if name == "beads.backup-20260204.db" && !f.SafeDelete {
			t.Error("backup should be safe to delete")
		}
	}
}

func TestScanForArtifacts_CruftBeadsDir(t *testing.T) {
	// Create a structure like: beads/polecats/testpolecat/.beads/ with extra files
	dir := t.TempDir()
	polecatsDir := filepath.Join(dir, "polecats", "testpolecat")
	beadsDir := filepath.Join(polecatsDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Add redirect file (expected)
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("../../mayor/rig/.beads"), 0644); err != nil {
		t.Fatal(err)
	}

	// Add cruft files
	if err := os.WriteFile(filepath.Join(beadsDir, "beads.db"), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "issues.jsonl"), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.CruftBeadsDirs) != 1 {
		t.Errorf("expected 1 cruft beads dir, got %d", len(report.CruftBeadsDirs))
	}

	if len(report.CruftBeadsDirs) > 0 && !report.CruftBeadsDirs[0].SafeDelete {
		t.Error("cruft beads dir with redirect should be safe to delete")
	}
}

func TestScanForArtifacts_CruftBeadsDirNoRedirect(t *testing.T) {
	// Cruft dir without redirect should be detected AND safe to delete.
	// The location being redirect-expected is sufficient — stale cruft files
	// are what prevent the redirect from being created in the first place.
	dir := t.TempDir()
	polecatsDir := filepath.Join(dir, "polecats", "testpolecat")
	beadsDir := filepath.Join(polecatsDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// No redirect file, just extra files
	if err := os.WriteFile(filepath.Join(beadsDir, "beads.db"), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	// Should be detected as cruft (it's in a polecat location) and safe to delete
	if len(report.CruftBeadsDirs) != 1 {
		t.Errorf("expected 1 cruft beads dir, got %d", len(report.CruftBeadsDirs))
	}
	if len(report.CruftBeadsDirs) > 0 && !report.CruftBeadsDirs[0].SafeDelete {
		t.Error("cruft beads dir in redirect-expected location should be safe to delete")
	}
}

func TestScanForArtifacts_CrewDir(t *testing.T) {
	dir := t.TempDir()
	crewDir := filepath.Join(dir, "crew", "testcrew")
	beadsDir := filepath.Join(crewDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Add redirect and cruft
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("../../mayor/rig/.beads"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "extra.txt"), []byte("cruft"), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.CruftBeadsDirs) != 1 {
		t.Errorf("expected 1 cruft beads dir for crew, got %d", len(report.CruftBeadsDirs))
	}
}

func TestScanForArtifacts_RedirectValidation(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create redirect pointing to nonexistent target
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("/nonexistent/path"), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.RedirectIssues) != 1 {
		t.Errorf("expected 1 redirect issue, got %d", len(report.RedirectIssues))
	}
}

func TestScanForArtifacts_EmptyRedirect(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create empty redirect
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte(""), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.RedirectIssues) != 1 {
		t.Errorf("expected 1 redirect issue (empty), got %d", len(report.RedirectIssues))
	}
}

func TestScanForArtifacts_ValidRedirect(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	targetDir := filepath.Join(dir, "target-beads")

	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		t.Fatal(err)
	}
	// A valid redirect target must have a metadata.json or database
	// (gastownhall/beads#4692 guard).
	if err := os.WriteFile(filepath.Join(targetDir, "metadata.json"), []byte(`{"database":"beads.db"}`), 0644); err != nil {
		t.Fatal(err)
	}

	// Create redirect pointing to valid target
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte(targetDir), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.RedirectIssues) != 0 {
		t.Errorf("expected 0 redirect issues for valid target, got %d", len(report.RedirectIssues))
	}
}

// TestScanForArtifacts_RedirectTargetHasNoDatabase is a regression test for
// gastownhall/beads#4692: a redirect target directory that exists but has no
// metadata.json and no recognizable database is flagged as an actionable
// warning (not SafeDelete cruft), matching FollowRedirect's own target-
// validity guard (internal/beads).
func TestScanForArtifacts_RedirectTargetHasNoDatabase(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	targetDir := filepath.Join(dir, "target-beads")

	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		t.Fatal(err)
	}
	// targetDir exists but is empty: no metadata.json, no database.

	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte(targetDir), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.RedirectIssues) != 1 {
		t.Fatalf("expected 1 redirect issue (target has no database), got %d", len(report.RedirectIssues))
	}
	if report.RedirectIssues[0].SafeDelete {
		t.Errorf("expected SafeDelete=false: an invalid-target redirect is an actionable warning, not cruft")
	}
}

func TestIsRedirectExpectedDir(t *testing.T) {
	tests := []struct {
		name     string
		path     string
		expected bool
	}{
		{"polecat worktree", "/foo/polecats/obsidian/.beads", true},
		{"crew workspace", "/foo/crew/mel/.beads", true},
		{"refinery rig", "/foo/refinery/rig/.beads", true},
		{"beads-worktrees", "/foo/.git/beads-worktrees/abc/.beads", true},
		{"regular beads dir", "/foo/.beads", false},
		{"nested project", "/foo/bar/.beads", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := isRedirectExpectedDir(tt.path)
			if got != tt.expected {
				t.Errorf("isRedirectExpectedDir(%q) = %v, want %v", tt.path, got, tt.expected)
			}
		})
	}
}

func TestScanForArtifacts_SkipsGitkeep(t *testing.T) {
	dir := t.TempDir()
	polecatsDir := filepath.Join(dir, "polecats", "test")
	beadsDir := filepath.Join(polecatsDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// redirect + .gitkeep only = no cruft
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("../../mayor/rig/.beads"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, ".gitkeep"), []byte{}, 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.CruftBeadsDirs) != 0 {
		t.Errorf("expected 0 cruft dirs (redirect + .gitkeep only), got %d", len(report.CruftBeadsDirs))
	}
}

func TestScanForArtifacts_SkipsGitInternalsButScansBeadsWorktrees(t *testing.T) {
	dir := t.TempDir()

	// A bogus .beads under .git internals should be ignored entirely.
	ignoredBeads := filepath.Join(dir, ".git", "objects", "pack", ".beads")
	if err := os.MkdirAll(ignoredBeads, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(ignoredBeads, "beads.db"), []byte("stale"), 0644); err != nil {
		t.Fatal(err)
	}

	// A worktree .beads under .git/beads-worktrees must still be scanned.
	worktreeBeads := filepath.Join(dir, ".git", "beads-worktrees", "test", ".beads")
	if err := os.MkdirAll(worktreeBeads, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(worktreeBeads, "extra.txt"), []byte("cruft"), 0644); err != nil {
		t.Fatal(err)
	}

	report, err := ScanForArtifacts(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(report.SQLiteArtifacts) != 0 {
		t.Fatalf("expected .git internals to be skipped, got %d sqlite findings", len(report.SQLiteArtifacts))
	}
	if len(report.CruftBeadsDirs) != 1 {
		t.Fatalf("expected 1 worktree cruft finding, got %d", len(report.CruftBeadsDirs))
	}
	if got := report.CruftBeadsDirs[0].Path; got != worktreeBeads {
		t.Fatalf("cruft finding path = %q, want %q", got, worktreeBeads)
	}
}

// TestScanForArtifacts_NonEmptyInteractionsJSONL — JSONL artifact scanning removed (bd-9ni.2)
func TestScanForArtifacts_NonEmptyInteractionsJSONL(t *testing.T) {
	t.Skip("JSONL artifact scanning removed as part of JSONL removal (bd-9ni.2)")
}

func TestCheckClassicArtifacts_WithArtifacts(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create dolt/ directory so isDoltNative returns true
	if err := os.MkdirAll(filepath.Join(beadsDir, "dolt"), 0755); err != nil {
		t.Fatal(err)
	}

	// Create a SQLite artifact
	if err := os.WriteFile(filepath.Join(beadsDir, "beads.db-wal"), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}

	check := CheckClassicArtifacts(dir)
	if check.Status != StatusWarning {
		t.Errorf("expected StatusWarning, got %s: %s", check.Status, check.Message)
	}
	if check.Name != "Classic Artifacts" {
		t.Errorf("expected name 'Classic Artifacts', got %q", check.Name)
	}
}

// writeArtifactTree creates each entry under dir: a name ending in "/" is an
// empty directory, anything else a file holding its value.
func writeArtifactTree(t *testing.T, dir string, entries map[string]string) {
	t.Helper()
	for name, content := range entries {
		path := filepath.Join(dir, filepath.FromSlash(name))
		if strings.HasSuffix(name, "/") {
			if err := os.MkdirAll(path, 0o755); err != nil {
				t.Fatal(err)
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
			t.Fatal(err)
		}
	}
}

// TestScanForArtifacts_SkipsUnsupportedWorkspaceFormat pins that the Classic
// Artifacts scan, which plain bd doctor and bd doctor --check=artifacts run,
// leaves a .beads directory in a format this build cannot open byte-identical
// and reports nothing in it. The scan walks every .beads under the path,
// including those of nested repositories and worktrees, which command
// admission never checks, and IsDoltBackend classified each one with the
// migrating configfile.Load: a graph workspace's legacy config.json became a
// metadata.json without the graph_* keys this build does not know. Each
// layout also holds artifacts, and the redirect-expected ones cruft, that the
// scan would otherwise report; the admitted workspace at the root is still
// scanned.
func TestScanForArtifacts_SkipsUnsupportedWorkspaceFormat(t *testing.T) {
	const graphMetadata = `{"database":"beads.db","backend":"dolt","graph_mode":"%s","graph_future_binding":"keep-me"}`
	const strippedMetadata = `{"database":"beads.db","backend":"dolt"}`
	layouts := []struct {
		name  string
		dir   string // the workspace's .beads, relative to the scanned root
		files map[string]string
	}{
		{name: "graph_mode in legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, configfile.GraphModeLink)}},
		{name: "future graph_mode in legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, "future-format")}},
		{name: "marker beside legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": strippedMetadata, configfile.GraphFormatMarkerFile: "link-preview-v9\n"}},
		{name: "graph_mode in metadata.json", dir: "sub/.beads", files: map[string]string{configfile.ConfigFileName: fmt.Sprintf(graphMetadata, configfile.GraphModeLink)}},
		{name: "marker in a polecat worktree", dir: "polecats/p1/.beads", files: map[string]string{"redirect": "../../mayor/rig/.beads\n", configfile.GraphFormatMarkerFile: "link-preview-v9\n", "extra.txt": "cruft"}},
		{name: "graph_mode in a beads worktree", dir: ".git/beads-worktrees/wt/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, configfile.GraphModeLink), "extra.txt": "cruft"}},
	}
	for _, layout := range layouts {
		for _, entry := range []string{"ScanForArtifacts", "CheckClassicArtifacts"} {
			t.Run(layout.name+"/"+entry, func(t *testing.T) {
				root := t.TempDir()
				rootWAL := filepath.Join(root, ".beads", "beads.db-wal")
				writeArtifactTree(t, filepath.Dir(rootWAL), map[string]string{"beads.db-wal": "wal"})
				beadsDir := filepath.Join(root, filepath.FromSlash(layout.dir))
				entries := map[string]string{
					"dolt/":                    "",
					"beads.db-wal":             "wal",
					"beads.backup-20260204.db": "backup",
				}
				for name, content := range layout.files {
					entries[name] = content
				}
				writeArtifactTree(t, beadsDir, entries)
				want := snapshotBeadsDir(t, beadsDir)

				if entry == "ScanForArtifacts" {
					report, err := ScanForArtifacts(root)
					if err != nil {
						t.Fatalf("ScanForArtifacts: %v", err)
					}
					var paths []string
					for _, findings := range [][]ArtifactFinding{report.SQLiteArtifacts, report.CruftBeadsDirs, report.RedirectIssues} {
						for _, f := range findings {
							paths = append(paths, f.Path)
						}
					}
					if !reflect.DeepEqual(paths, []string{rootWAL}) {
						t.Fatalf("ScanForArtifacts findings = %q, want only the root workspace's %s", paths, rootWAL)
					}
				} else {
					check := CheckClassicArtifacts(root)
					if check.Status != StatusWarning || check.Message != "1 SQLite artifact(s)" {
						t.Fatalf("CheckClassicArtifacts = %s %q, want warning %q for the root workspace only", check.Status, check.Message, "1 SQLite artifact(s)")
					}
				}
				if got := snapshotBeadsDir(t, beadsDir); !reflect.DeepEqual(got, want) {
					t.Fatalf("%s changed %s:\n got %q\nwant %q", entry, layout.dir, got, want)
				}
			})
		}
	}
}

// TestScanForArtifacts_DoesNotMigrateLegacyConfig pins that the scan reads a
// nested workspace's legacy config.json without migrating it into
// metadata.json, and still classifies that workspace by what it says: SQLite
// files are artifacts only when its backend is Dolt.
func TestScanForArtifacts_DoesNotMigrateLegacyConfig(t *testing.T) {
	cases := []struct {
		name   string
		legacy string
		want   []string // reported artifacts, relative to the nested .beads
	}{
		{name: "dolt backend", legacy: `{"database":"beads.db","backend":"dolt","future_key":"keep-me"}`, want: []string{"beads.db-wal"}},
		{name: "sqlite backend", legacy: `{"database":"beads.db","backend":"sqlite","future_key":"keep-me"}`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			root := t.TempDir()
			beadsDir := filepath.Join(root, "sub", ".beads")
			writeArtifactTree(t, beadsDir, map[string]string{
				"config.json":  tc.legacy,
				"beads.db-wal": "wal",
			})

			report, err := ScanForArtifacts(root)
			if err != nil {
				t.Fatalf("ScanForArtifacts: %v", err)
			}
			var got []string
			for _, f := range report.SQLiteArtifacts {
				rel, err := filepath.Rel(beadsDir, f.Path)
				if err != nil {
					t.Fatal(err)
				}
				got = append(got, filepath.ToSlash(rel))
			}
			if !reflect.DeepEqual(got, tc.want) {
				t.Fatalf("SQLite artifacts = %q, want %q", got, tc.want)
			}
			if data, err := os.ReadFile(filepath.Join(beadsDir, "config.json")); err != nil || string(data) != tc.legacy {
				t.Fatalf("config.json = %q (read err %v), want it unchanged: %q", data, err, tc.legacy)
			}
			if _, err := os.Stat(filepath.Join(beadsDir, configfile.ConfigFileName)); !os.IsNotExist(err) {
				t.Fatalf("ScanForArtifacts wrote %s (stat err %v)", configfile.ConfigFileName, err)
			}
		})
	}
}

// TestScanForArtifacts_MetadataAlongsideRedirectIsNotCruft pins that the scan
// reports in a redirect-only .beads exactly what the cleanup removes there.
// Beside a redirect the cleanup keeps the directory's own metadata, a
// metadata.json or a legacy config.json not yet migrated into one
// (gastownhall/beads#4692), so the scan lists only the unrelated file, the
// cleanup leaves the metadata byte-identical, and a second scan has nothing
// left to report. Without a redirect the metadata is cruft like the rest.
func TestScanForArtifacts_MetadataAlongsideRedirectIsNotCruft(t *testing.T) {
	const metadata = `{"dolt_mode":"server","dolt_database":"lola","future_key":"keep-me"}`
	const redirect = "../../mayor/rig/.beads\n"
	cases := []struct {
		name  string
		files map[string]string // the polecat's .beads
		cruft string            // what the scan reports it contains
		after map[string]string // the .beads after the cleanup
	}{
		{
			name:  "metadata.json with redirect",
			files: map[string]string{"redirect": redirect, configfile.ConfigFileName: metadata, "extra.txt": "cruft"},
			cruft: "extra.txt",
			after: map[string]string{".": "/", "redirect": redirect, configfile.ConfigFileName: metadata},
		},
		{
			name:  "legacy config.json with redirect",
			files: map[string]string{"redirect": redirect, "config.json": metadata, "extra.txt": "cruft"},
			cruft: "extra.txt",
			after: map[string]string{".": "/", "redirect": redirect, "config.json": metadata},
		},
		{
			name:  "metadata.json without redirect",
			files: map[string]string{configfile.ConfigFileName: metadata, "extra.txt": "cruft"},
			cruft: "extra.txt, metadata.json",
			after: map[string]string{".": "/"},
		},
		{
			name:  "legacy config.json without redirect",
			files: map[string]string{"config.json": metadata, "extra.txt": "cruft"},
			cruft: "config.json, extra.txt",
			after: map[string]string{".": "/"},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			root := t.TempDir()
			writeArtifactTree(t, filepath.Join(root, "mayor", "rig", ".beads"), map[string]string{configfile.ConfigFileName: `{"backend":"dolt"}`})
			beadsDir := filepath.Join(root, "polecats", "p1", ".beads")
			writeArtifactTree(t, beadsDir, tc.files)

			report, err := ScanForArtifacts(root)
			if err != nil {
				t.Fatalf("ScanForArtifacts: %v", err)
			}
			want := []ArtifactFinding{{Path: beadsDir, Type: "cruft-beads", Description: "should be redirect-only but contains: " + tc.cruft, SafeDelete: true}}
			if report.TotalCount != 1 || !reflect.DeepEqual(report.CruftBeadsDirs, want) {
				t.Fatalf("ScanForArtifacts = %+v, want only the cruft finding %+v", report, want)
			}

			if err := fix.ClassicArtifacts(root); err != nil {
				t.Fatalf("fix.ClassicArtifacts: %v", err)
			}
			if got := snapshotBeadsDir(t, beadsDir); !reflect.DeepEqual(got, tc.after) {
				t.Fatalf("fix.ClassicArtifacts left %s as\n %q\nwant %q", beadsDir, got, tc.after)
			}
			if report, err = ScanForArtifacts(root); err != nil || report.TotalCount != 0 {
				t.Fatalf("ScanForArtifacts after the cleanup = %+v (err %v), want nothing to report", report, err)
			}
		})
	}
}

// TestScanForArtifacts_ScansWorkspaceWithUnloadableMetadata pins that the
// scan skips only a .beads in a format this build cannot open, not one whose
// metadata does not load: that directory is scanned as before, with the
// default Dolt backend, so the scan still reports what the cleanup removes
// there (fix's TestClassicArtifacts_CleansCruftWithoutRedirectFile).
func TestScanForArtifacts_ScansWorkspaceWithUnloadableMetadata(t *testing.T) {
	root := t.TempDir()
	beadsDir := filepath.Join(root, "polecats", "p1", ".beads")
	writeArtifactTree(t, beadsDir, map[string]string{
		configfile.ConfigFileName: "stale",
		"beads.db-wal":            "wal",
		"extra.txt":               "cruft",
	})

	report, err := ScanForArtifacts(root)
	if err != nil {
		t.Fatalf("ScanForArtifacts: %v", err)
	}
	wantSQLite := []ArtifactFinding{{Path: filepath.Join(beadsDir, "beads.db-wal"), Type: "sqlite", Description: "SQLite database file (Dolt is active backend)", SafeDelete: true}}
	if !reflect.DeepEqual(report.SQLiteArtifacts, wantSQLite) {
		t.Errorf("SQLite artifacts = %+v, want %+v", report.SQLiteArtifacts, wantSQLite)
	}
	wantCruft := []ArtifactFinding{{Path: beadsDir, Type: "cruft-beads", Description: "should be redirect-only but contains: beads.db-wal, extra.txt, metadata.json", SafeDelete: true}}
	if !reflect.DeepEqual(report.CruftBeadsDirs, wantCruft) {
		t.Errorf("cruft .beads dirs = %+v, want %+v", report.CruftBeadsDirs, wantCruft)
	}
}
