package fix

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/configfile"
)

func TestClassicArtifacts_NoArtifacts(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}
}

func TestClassicArtifacts_RemovesSQLiteWAL(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create WAL/SHM files
	for _, name := range []string{"beads.db-shm", "beads.db-wal"} {
		if err := os.WriteFile(filepath.Join(beadsDir, name), []byte("data"), 0644); err != nil {
			t.Fatal(err)
		}
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	// Verify WAL/SHM files were removed
	for _, name := range []string{"beads.db-shm", "beads.db-wal"} {
		if _, err := os.Stat(filepath.Join(beadsDir, name)); !os.IsNotExist(err) {
			t.Errorf("%s should have been removed", name)
		}
	}
}

func TestClassicArtifacts_SkipsBeadsDB(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create beads.db (should be skipped)
	if err := os.WriteFile(filepath.Join(beadsDir, "beads.db"), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	// beads.db should still exist (not safe to delete automatically)
	if _, err := os.Stat(filepath.Join(beadsDir, "beads.db")); os.IsNotExist(err) {
		t.Error("beads.db should NOT have been removed")
	}
}

func TestClassicArtifacts_RemovesBackupDBs(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	backupName := "beads.backup-20260204.db"
	if err := os.WriteFile(filepath.Join(beadsDir, backupName), []byte("data"), 0644); err != nil {
		t.Fatal(err)
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	if _, err := os.Stat(filepath.Join(beadsDir, backupName)); !os.IsNotExist(err) {
		t.Error("backup db should have been removed")
	}
}

func TestClassicArtifacts_CleansJSONLInDoltDir(t *testing.T) {
	dir := t.TempDir()
	beadsDir := filepath.Join(dir, ".beads")
	doltDir := filepath.Join(beadsDir, "dolt")
	if err := os.MkdirAll(doltDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Create safe-to-delete JSONL artifacts
	for _, name := range []string{"issues.jsonl.new"} {
		if err := os.WriteFile(filepath.Join(beadsDir, name), []byte(`{"id":"test"}`), 0644); err != nil {
			t.Fatal(err)
		}
	}

	// Create empty interactions.jsonl
	if err := os.WriteFile(filepath.Join(beadsDir, "interactions.jsonl"), []byte{}, 0644); err != nil {
		t.Fatal(err)
	}

	// Create issues.jsonl (should be skipped)
	if err := os.WriteFile(filepath.Join(beadsDir, "issues.jsonl"), []byte(`{"id":"real"}`), 0644); err != nil {
		t.Fatal(err)
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	// Safe files should be removed
	for _, name := range []string{"issues.jsonl.new", "interactions.jsonl"} {
		if _, err := os.Stat(filepath.Join(beadsDir, name)); !os.IsNotExist(err) {
			t.Errorf("%s should have been removed", name)
		}
	}

	// issues.jsonl should be kept
	if _, err := os.Stat(filepath.Join(beadsDir, "issues.jsonl")); os.IsNotExist(err) {
		t.Error("issues.jsonl should NOT have been removed")
	}
}

func TestClassicArtifacts_CleansCruftBeadsDir(t *testing.T) {
	dir := t.TempDir()
	polecatsDir := filepath.Join(dir, "polecats", "test")
	beadsDir := filepath.Join(polecatsDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Add redirect (expected)
	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("../../mayor/rig/.beads"), 0644); err != nil {
		t.Fatal(err)
	}

	// Add .gitkeep (should be preserved)
	if err := os.WriteFile(filepath.Join(beadsDir, ".gitkeep"), []byte{}, 0644); err != nil {
		t.Fatal(err)
	}

	// Add cruft
	if err := os.WriteFile(filepath.Join(beadsDir, "extra.txt"), []byte("cruft"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(beadsDir, "cruft-subdir"), 0755); err != nil {
		t.Fatal(err)
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	// redirect should still exist
	if _, err := os.Stat(filepath.Join(beadsDir, "redirect")); os.IsNotExist(err) {
		t.Error("redirect should NOT have been removed")
	}

	// .gitkeep should still exist
	if _, err := os.Stat(filepath.Join(beadsDir, ".gitkeep")); os.IsNotExist(err) {
		t.Error(".gitkeep should NOT have been removed")
	}

	// cruft should be removed
	if _, err := os.Stat(filepath.Join(beadsDir, "extra.txt")); !os.IsNotExist(err) {
		t.Error("extra.txt should have been removed")
	}
	if _, err := os.Stat(filepath.Join(beadsDir, "cruft-subdir")); !os.IsNotExist(err) {
		t.Error("cruft-subdir should have been removed")
	}
}

// TestClassicArtifacts_PreservesMetadataJSONAlongsideRedirect is a
// regression test for gastownhall/beads#4692: a metadata.json co-located
// with a redirect file (the fb51196f7 / docs "Database Redirects" topology,
// where a server-mode source rig's own metadata.json supplies its
// dolt_database while a redirect points at the shared Gas Town root) must
// never be deleted as cruft while the redirect is preserved.
func TestClassicArtifacts_PreservesMetadataJSONAlongsideRedirect(t *testing.T) {
	dir := t.TempDir()
	polecatsDir := filepath.Join(dir, "polecats", "test")
	beadsDir := filepath.Join(polecatsDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0755); err != nil {
		t.Fatal(err)
	}

	if err := os.WriteFile(filepath.Join(beadsDir, "redirect"), []byte("../../mayor/rig/.beads"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "metadata.json"), []byte(`{"dolt_mode":"server","dolt_database":"lola"}`), 0644); err != nil {
		t.Fatal(err)
	}
	// Still remove unrelated cruft in the same pass.
	if err := os.WriteFile(filepath.Join(beadsDir, "extra.txt"), []byte("cruft"), 0644); err != nil {
		t.Fatal(err)
	}

	if err := ClassicArtifacts(dir); err != nil {
		t.Fatalf("expected no error, got: %v", err)
	}

	if _, err := os.Stat(filepath.Join(beadsDir, "redirect")); os.IsNotExist(err) {
		t.Error("redirect should NOT have been removed")
	}
	if _, err := os.Stat(filepath.Join(beadsDir, "metadata.json")); os.IsNotExist(err) {
		t.Error("metadata.json should NOT have been removed while a redirect is present")
	}
	if _, err := os.Stat(filepath.Join(beadsDir, "extra.txt")); !os.IsNotExist(err) {
		t.Error("extra.txt should have been removed")
	}
}

func TestClassicArtifacts_CleansCruftWithoutRedirectFile(t *testing.T) {
	// Regression test: when a redirect-expected location has cruft files but
	// NO redirect file, the fix should still clean up the cruft.
	// Previously, the fix required both isRedirectExpected AND hasRedirect,
	// leaving stale files (config.yaml, metadata.json, README.md, issues.jsonl)
	// in .git/beads-worktrees/*/.beads/ directories.
	dir := t.TempDir()

	// Simulate .git/beads-worktrees/master/.beads/ (redirect-expected location)
	worktreeBeads := filepath.Join(dir, ".git", "beads-worktrees", "master", ".beads")
	if err := os.MkdirAll(worktreeBeads, 0755); err != nil {
		t.Fatal(err)
	}

	// Add typical stale files (NO redirect file present)
	cruftFiles := []string{"config.yaml", "metadata.json", "README.md", "issues.jsonl", ".gitignore", ".local_version"}
	for _, name := range cruftFiles {
		if err := os.WriteFile(filepath.Join(worktreeBeads, name), []byte("stale"), 0644); err != nil {
			t.Fatal(err)
		}
	}

	err := ClassicArtifacts(dir)
	if err != nil {
		t.Errorf("expected no error, got: %v", err)
	}

	// All cruft files should be removed
	for _, name := range cruftFiles {
		if _, err := os.Stat(filepath.Join(worktreeBeads, name)); !os.IsNotExist(err) {
			t.Errorf("%s should have been removed (cruft in redirect-expected dir without redirect file)", name)
		}
	}
}

func TestIsRedirectExpectedLocation(t *testing.T) {
	tests := []struct {
		name     string
		path     string
		expected bool
	}{
		{"polecat worktree", "/foo/polecats/obsidian/.beads", true},
		{"crew workspace", "/foo/crew/mel/.beads", true},
		{"refinery rig", "/foo/refinery/rig/.beads", true},
		{"beads-worktrees", "/foo/.git/beads-worktrees/abc/.beads", true},
		{"regular beads dir", "/foo/.beads", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := isRedirectExpectedLocation(tt.path)
			if got != tt.expected {
				t.Errorf("isRedirectExpectedLocation(%q) = %v, want %v", tt.path, got, tt.expected)
			}
		})
	}
}

// writeBeadsTree creates each entry under dir: a name ending in "/" is an empty
// directory, anything else a file holding its value.
func writeBeadsTree(t *testing.T, dir string, entries map[string]string) {
	t.Helper()
	for name, content := range entries {
		path := filepath.Join(dir, filepath.FromSlash(name))
		if strings.HasSuffix(name, "/") {
			if err := os.MkdirAll(path, 0o755); err != nil {
				t.Fatal(err)
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
			t.Fatal(err)
		}
	}
}

// snapshotBeadsTree returns every entry under dir, keyed by its slash-separated
// relative path: a file maps to its bytes, a directory to "/".
func snapshotBeadsTree(t *testing.T, dir string) map[string]string {
	t.Helper()
	snapshot := map[string]string{}
	err := filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(dir, path)
		if err != nil {
			return err
		}
		if d.IsDir() {
			snapshot[filepath.ToSlash(rel)] = "/"
			return nil
		}
		data, err := os.ReadFile(path) // #nosec G304 -- test-owned temp tree
		if err != nil {
			return err
		}
		snapshot[filepath.ToSlash(rel)] = string(data)
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	return snapshot
}

// TestClassicArtifacts_SkipsUnsupportedWorkspaceFormat pins that the Classic
// Artifacts fix leaves a .beads directory in a format this build cannot open
// byte-identical. The fix walks every .beads under the path, including those
// of nested repositories and worktrees, which command admission never checks,
// and it classified each one with the migrating configfile.Load: a graph
// workspace's legacy config.json became a metadata.json without the graph_*
// keys this build does not know. Each layout also holds artifacts the fix
// would otherwise remove, and the redirect-expected ones cruft, so nothing
// else in the workspace may change either; the admitted workspace at the root
// is still cleaned.
func TestClassicArtifacts_SkipsUnsupportedWorkspaceFormat(t *testing.T) {
	const graphMetadata = `{"database":"beads.db","backend":"dolt","graph_mode":"%s","graph_future_binding":"keep-me"}`
	const strippedMetadata = `{"database":"beads.db","backend":"dolt"}`
	layouts := []struct {
		name  string
		dir   string // the workspace's .beads, relative to the walked root
		files map[string]string
	}{
		{name: "graph_mode in legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, configfile.GraphModeLink)}},
		{name: "future graph_mode in legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, "future-format")}},
		{name: "marker beside legacy config.json", dir: "sub/.beads", files: map[string]string{"config.json": strippedMetadata, configfile.GraphFormatMarkerFile: "link-preview-v9\n"}},
		{name: "graph_mode in metadata.json", dir: "sub/.beads", files: map[string]string{configfile.ConfigFileName: fmt.Sprintf(graphMetadata, configfile.GraphModeLink)}},
		{name: "marker in a polecat worktree", dir: "polecats/p1/.beads", files: map[string]string{"redirect": "../../mayor/rig/.beads\n", configfile.GraphFormatMarkerFile: "link-preview-v9\n", "extra.txt": "cruft"}},
		{name: "graph_mode in a beads worktree", dir: ".git/beads-worktrees/wt/.beads", files: map[string]string{"config.json": fmt.Sprintf(graphMetadata, configfile.GraphModeLink), "extra.txt": "cruft"}},
	}
	for _, layout := range layouts {
		t.Run(layout.name, func(t *testing.T) {
			root := t.TempDir()
			rootWAL := filepath.Join(root, ".beads", "beads.db-wal")
			writeBeadsTree(t, filepath.Dir(rootWAL), map[string]string{"beads.db-wal": "wal"})
			beadsDir := filepath.Join(root, filepath.FromSlash(layout.dir))
			entries := map[string]string{
				"dolt/":                    "",
				"beads.db-wal":             "wal",
				"beads.backup-20260204.db": "backup",
				"issues.jsonl.new":         `{"id":"x"}`,
			}
			for name, content := range layout.files {
				entries[name] = content
			}
			writeBeadsTree(t, beadsDir, entries)
			want := snapshotBeadsTree(t, beadsDir)

			if err := ClassicArtifacts(root); err != nil {
				t.Fatalf("ClassicArtifacts: %v", err)
			}
			if got := snapshotBeadsTree(t, beadsDir); !reflect.DeepEqual(got, want) {
				t.Fatalf("ClassicArtifacts changed %s:\n got %q\nwant %q", layout.dir, got, want)
			}
			if _, err := os.Stat(rootWAL); !os.IsNotExist(err) {
				t.Fatalf("ClassicArtifacts left the root workspace's %s (stat err %v)", rootWAL, err)
			}
		})
	}
}

// TestClassicArtifacts_DoesNotMigrateLegacyConfig pins that the fix reads a
// nested workspace's legacy config.json without migrating it into
// metadata.json, and still cleans that workspace by what it says: the
// dolt_data_dir it names is where the fix finds the Dolt directory that makes
// a JSONL artifact removable.
func TestClassicArtifacts_DoesNotMigrateLegacyConfig(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	root := t.TempDir()
	beadsDir := filepath.Join(root, "sub", ".beads")
	const legacy = `{"database":"beads.db","backend":"dolt","dolt_data_dir":"custom-dolt","future_key":"keep-me"}`
	writeBeadsTree(t, beadsDir, map[string]string{
		"config.json":      legacy,
		"custom-dolt/":     "",
		"beads.db-wal":     "wal",
		"issues.jsonl.new": `{"id":"x"}`,
	})

	if err := ClassicArtifacts(root); err != nil {
		t.Fatalf("ClassicArtifacts: %v", err)
	}
	if got, err := os.ReadFile(filepath.Join(beadsDir, "config.json")); err != nil || string(got) != legacy {
		t.Fatalf("config.json = %q (read err %v), want it unchanged: %q", got, err, legacy)
	}
	if _, err := os.Stat(filepath.Join(beadsDir, configfile.ConfigFileName)); !os.IsNotExist(err) {
		t.Fatalf("ClassicArtifacts wrote %s (stat err %v)", configfile.ConfigFileName, err)
	}
	for _, name := range []string{"beads.db-wal", "issues.jsonl.new"} {
		if _, err := os.Stat(filepath.Join(beadsDir, name)); !os.IsNotExist(err) {
			t.Errorf("%s should have been removed (stat err %v)", name, err)
		}
	}
}

// TestClassicArtifacts_PreservesLegacyConfigJSONAlongsideRedirect extends
// TestClassicArtifacts_PreservesMetadataJSONAlongsideRedirect to a legacy
// config.json, the form the source rig's metadata takes before its migration.
// The walk no longer migrates it into a metadata.json the cleanup keeps, so
// the cleanup keeps the config.json itself, byte-identical with its
// dolt_database and keys bd does not know, while unrelated cruft beside it is
// still removed. Without a redirect it is cruft like the rest.
func TestClassicArtifacts_PreservesLegacyConfigJSONAlongsideRedirect(t *testing.T) {
	const legacy = `{"dolt_mode":"server","dolt_database":"lola","future_key":"keep-me"}`
	cases := []struct {
		name  string
		files map[string]string
		want  map[string]string // the .beads after the cleanup
	}{
		{
			name:  "with redirect",
			files: map[string]string{"redirect": "../../mayor/rig/.beads", "config.json": legacy, "extra.txt": "cruft"},
			want:  map[string]string{".": "/", "redirect": "../../mayor/rig/.beads", "config.json": legacy},
		},
		{
			name:  "without redirect",
			files: map[string]string{"config.json": legacy, "extra.txt": "cruft"},
			want:  map[string]string{".": "/"},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			root := t.TempDir()
			beadsDir := filepath.Join(root, "polecats", "p1", ".beads")
			writeBeadsTree(t, beadsDir, tc.files)

			if err := ClassicArtifacts(root); err != nil {
				t.Fatalf("ClassicArtifacts: %v", err)
			}
			if got := snapshotBeadsTree(t, beadsDir); !reflect.DeepEqual(got, tc.want) {
				t.Fatalf("ClassicArtifacts left %s as\n %q\nwant %q", beadsDir, got, tc.want)
			}
		})
	}
}
