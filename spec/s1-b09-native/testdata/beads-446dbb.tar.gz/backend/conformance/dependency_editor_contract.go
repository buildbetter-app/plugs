package conformance

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"

	storeops "github.com/steveyegge/beads/internal/storage/issueops"
	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
)

// This file holds the contract every implementation of
// publicops.DependencyEditor must satisfy. There are three of them — the
// direct store, the embedded store, and the unit-of-work backend — and the
// first two share a transaction body the third does not, so a rule asserted
// against one has repeatedly drifted on the others. A run on the third
// backend therefore catches WRAPPER AND ENGINE divergence between the two that
// share a body; only the unit-of-work run is an independent vote on the body.
//
// The first four cases pin the one thing the three had actually diverged on:
// which PLANE an edge lands in. `bd dep add <wisp-id> <target>` writes the
// ephemeral graph, and it has to, because a wisp has no row in the issues
// plane for an edge to hang off.
//
// The rest pin the role's older semantics — request-order echo, idempotency,
// refusal atomicity, the typed refusals, application order, external targets,
// request hygiene and the one-history-entry-per-landed-request rule. Each is
// written to what issueops/dependencyeditor.go PROMISES; where an
// implementation disagrees, the case still asserts the doc and the losing
// backend's wiring parks it with skipKnownDivergence.

// DependencyEditorFixture supplies adapter-specific storage access for the
// dependency-editor assertions.
type DependencyEditorFixture struct {
	// IssuePrefix namespaces the ids each assertion seeds, so several of them
	// can share one database.
	IssuePrefix string
	Editor      publicops.DependencyEditor
	// CreateIssue seeds a durable issue in the issues plane.
	CreateIssue func(context.Context, *types.Issue, string) error
	// CreateWisp seeds an ephemeral issue in the wisps plane. It is a separate
	// field rather than an Ephemeral flag on CreateIssue because the three
	// adapters reach the two planes through different verbs.
	CreateWisp func(context.Context, *types.Issue, string) error
	// AddDependency seeds ONE edge out of band of the role, and is needed for
	// exactly one thing the role's own request type cannot express: a
	// DependencyEdge carries no metadata, so a waits-for edge with an
	// any-children GATE on it can only be seeded through the kit's hook. The
	// blocked-state case that needs one seeds only the precondition through it;
	// the verb under test is still AddDependencies.
	AddDependency func(context.Context, *types.Dependency, string) error
	QueryScalar   func(context.Context, string, []any, ...any) error
	// CountHistory reports how many history entries the fixture's branch has.
	// The cases that need it take it before and after the operation under test,
	// because two commits made inside one second tie on date and their relative
	// order is not something to rely on.
	//
	// A nil CountHistory means "this backend cannot observe history here", and
	// the cases that need it then skip with that reason rather than pass
	// quietly. It is non-nil on all three backends today.
	CountHistory func(context.Context) (int, error)
	// SetJournalEnabled turns on durable journaling for the workspace under
	// test (storage.EventsJournalConfigurer) — the same operator switch
	// JournalFixture.SetJournalEnabled wires, and off by default for the same
	// reason: a workspace that never opted in records nothing in
	// bd_events_journal while every other write still succeeds normally.
	//
	// The idempotency cases need it on because bd_events_journal has no
	// deduplication of its own (issueops.RecordDepEventInTx always inserts):
	// a same-type re-add or an absent removal is a no-op only if nothing
	// downstream of the role recorded a change, and the journal is the one
	// place that is not otherwise observable through this fixture. It is
	// non-nil on all three backends.
	SetJournalEnabled func(enabled bool)
	// SetVersionedHistoryEnabled turns on dual-write issue-version history
	// (storage.VersionedHistoryConfigurer) — off by default for the same
	// reason SetJournalEnabled is.
	//
	// It exists for one case: the metadata-changed re-add, which can only be
	// driven through AddDependency (the role's own request type carries no
	// metadata). That hook writes through the backend's raw store path rather
	// than the role's transaction wrapper, and on at least one backend only
	// the latter issues the underlying VCS commit CountHistory observes — so
	// a case reached through AddDependency cannot tell a mint happened by
	// watching CountHistory the way the role-driven history cases do. It has
	// to read issue_versions directly instead, which only advances when this
	// switch is on. It is non-nil on all three backends.
	SetVersionedHistoryEnabled func(enabled bool)
}

// RunDependencyEditorRoutesWispSourcedEdgeToTheWispPlane is the regression pin
// for a wisp-sourced edge. Both the edge and its event follow the SOURCE:
// wisp_dependencies and wisp_events, never the durable pair. Pinning the
// durable pair at zero is the half that catches a regression writing an edge
// whose issue_id names a row the issues plane does not have.
func RunDependencyEditorRoutesWispSourcedEdgeToTheWispPlane(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	wisp := fixture.IssuePrefix + "-wdep-src"
	target := fixture.IssuePrefix + "-wdep-tgt"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: wisp, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("AddDependencies from a wisp source: %v", err)
	}

	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, target, 1)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", wisp, target, 0)
	assertDependencyEditorEventCount(t, ctx, fixture, "wisp_events", wisp, types.EventDependencyAdded, 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", wisp, types.EventDependencyAdded, 0)
}

// RunDependencyEditorMixedBatchWritesBothPlanes proves one request can span
// the two planes. The batch is one transaction with two write paths in it, so
// this is the case that catches a routing decision taken once for the whole
// request instead of once per edge.
func RunDependencyEditorMixedBatchWritesBothPlanes(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	wisp := fixture.IssuePrefix + "-mixed-wisp"
	issue := fixture.IssuePrefix + "-mixed-issue"
	target := fixture.IssuePrefix + "-mixed-target"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorIssue(t, ctx, fixture, issue)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: wisp, DependsOnID: target, Type: publicops.DepBlocks},
			{IssueID: issue, DependsOnID: target, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("AddDependencies on a mixed-plane batch: %v", err)
	}

	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, target, 1)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", wisp, target, 0)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", issue, target, 1)
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", issue, target, 0)
}

// RunDependencyEditorMixedBatchRefusalRollsBackBothPlanes proves the
// all-or-nothing promise survives the plane split: a refusal on the durable
// edge must take the ephemeral edge written before it back out too.
//
// The refusal is a type conflict rather than a cycle so that it fires at the
// edge, after the earlier edge is already written, rather than at the
// whole-graph gate.
func RunDependencyEditorMixedBatchRefusalRollsBackBothPlanes(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	wisp := fixture.IssuePrefix + "-rb-wisp"
	issue := fixture.IssuePrefix + "-rb-issue"
	target := fixture.IssuePrefix + "-rb-target"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorIssue(t, ctx, fixture, issue)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: issue, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("seed the durable edge that the retype will collide with: %v", err)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: wisp, DependsOnID: target, Type: publicops.DepBlocks},
			{IssueID: issue, DependsOnID: target, Type: publicops.DepRelated},
		},
	})
	var conflict *publicops.DependencyTypeConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("mixed-batch retype error = %v, want *DependencyTypeConflictError", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, target, 0)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", wisp, target, 0)
	assertDependencyEditorEventCount(t, ctx, fixture, "wisp_events", wisp, types.EventDependencyAdded, 0)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", issue, target, string(publicops.DepBlocks), 1)
}

// RunDependencyEditorRefusesCrossPlaneCycle pins bd-xe27: the scheduling graph
// is one graph across the two tables, so an edge closing a loop that leaves
// the issues plane and comes back through the wisp plane is refused.
func RunDependencyEditorRefusesCrossPlaneCycle(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	issue := fixture.IssuePrefix + "-xcycle-issue"
	wisp := fixture.IssuePrefix + "-xcycle-wisp"
	seedDependencyEditorIssue(t, ctx, fixture, issue)
	seedDependencyEditorWisp(t, ctx, fixture, wisp)

	// issue -> wisp lands in the durable table with a wisp target.
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: issue, DependsOnID: wisp, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("AddDependencies issue -> wisp: %v", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", issue, wisp, 1)

	// wisp -> issue would close the loop through the other table.
	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: wisp, DependsOnID: issue, Type: publicops.DepBlocks}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("cross-plane cycle error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, issue, 0)

	// The same loop, hidden from the per-edge probe, must still be refused by
	// the whole-graph gate.
	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor:                 "writer",
		SkipPerEdgeCycleCheck: true,
		Edges:                 []publicops.DependencyEdge{{IssueID: wisp, DependsOnID: issue, Type: publicops.DepBlocks}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("cross-plane cycle error with the probe skipped = %v, want ErrDependencyCycle from the final gate", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, issue, 0)
}

// RunDependencyEditorAddedEchoesTheRequestOrder pins AddDependenciesResult.Added
// (issueops/dependencyeditor.go:76-81): all-or-nothing means Added is either
// every requested edge or the call failed, so it echoes the REQUEST — a caller
// reporting what landed reads the result and never has to know which.
//
// The request deliberately leads with a blocking edge and ends with a
// parent-child one, which is the reverse of the order the edges are APPLIED in
// (dependencyeditor.go:61-64). The application order must not leak into the
// result.
func RunDependencyEditorAddedEchoesTheRequestOrder(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-echo-source"
	target := fixture.IssuePrefix + "-echo-target"
	child := fixture.IssuePrefix + "-echo-child"
	for _, id := range []string{source, target, child} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	edges := []publicops.DependencyEdge{
		{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks},
		{IssueID: child, DependsOnID: source, Type: publicops.DepParentChild},
	}
	result, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{Actor: "writer", Edges: edges})
	if err != nil {
		t.Fatalf("AddDependencies: %v", err)
	}
	if len(result.Added) != len(edges) {
		t.Fatalf("Added = %#v, want %d edges", result.Added, len(edges))
	}
	for i, want := range edges {
		if result.Added[i] != want {
			t.Errorf("Added[%d] = %#v, want %#v: the result echoes the REQUEST order, not the order the edges were applied in", i, result.Added[i], want)
		}
	}

	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", child, source, string(publicops.DepParentChild), 1)
}

// RunDependencyEditorSameTypeReAddIsIdempotent pins the same-type re-add
// clause: an edge that already exists with the SAME type is idempotent and
// refuses nothing. The row count is what makes it idempotent rather than
// merely tolerated.
//
// It also pins the clause's second half, that a request which wrote no durable
// edge records NO history entry. The doc reaches that by the same argument the
// removal side already made — nothing was written, so there is nothing to
// version — and the two halves belong in one case because the history delta is
// only meaningful next to the row count that explains it.
//
// The event stream is the third observable and the sharpest one: the leaf
// promises a dependency_added entry for a GENUINELY NEW edge, so a backend
// that re-emitted on the no-op would leave a history of work that did not
// happen even where the row count could not tell.
//
// bd_events_journal is the fourth, and the one none of the others catch:
// unlike the events table it has no deduplication of its own
// (issueops.RecordDepEventInTx always inserts), so a same-type re-add that
// gates on TYPE alone — never the stored metadata VALUE — journals a change
// that never happened even while the row count, the events table and the
// history delta all read as a clean no-op. This is #5898's R3 case: a
// change-free write must create no version and must not journal one either.
func RunDependencyEditorSameTypeReAddIsIdempotent(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	fixture.SetJournalEnabled(true)
	t.Cleanup(func() { fixture.SetJournalEnabled(false) })
	source := fixture.IssuePrefix + "-idem-source"
	target := fixture.IssuePrefix + "-idem-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	request := publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}
	if _, err := fixture.Editor.AddDependencies(ctx, request); err != nil {
		t.Fatalf("AddDependencies first: %v", err)
	}
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))

	assertHistoryDelta := dependencyEditorHistoryProbe(t, ctx, fixture)
	result, err := fixture.Editor.AddDependencies(ctx, request)
	if err != nil {
		t.Fatalf("re-adding the same edge with the same type refused: %v", err)
	}
	if len(result.Added) != 1 || result.Added[0] != request.Edges[0] {
		t.Errorf("Added on the idempotent re-add = %#v, want the requested edge: the result echoes the request either way", result.Added)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))
	assertHistoryDelta(0, "every edge of the request already existed with the requested type, so nothing was written and nothing is versioned")
}

// RunDependencyEditorSameTypeReAddWithChangedMetadataMintsOneVersion pins the
// other half of the same-type re-add clause from
// RunDependencyEditorSameTypeReAddIsIdempotent: same TYPE is not the whole
// idempotency test, because the row also carries metadata, and a re-add that
// changes it is a real mutation of the source issue rather than a no-op that
// happens to share a type. The leaf updates the stored metadata and mints
// EXACTLY ONE version carrying the new state — the same terms as a genuinely
// new edge — because from the source issue's point of view a metadata change
// is as real as the edge appearing in the first place (#5898 leg 2).
//
// It drives the re-add through fixture.AddDependency rather than
// fixture.Editor.AddDependencies because publicops.DependencyEdge carries no
// metadata for the role API to change — the same reason
// RunDependencyEditorClosedChildAddSatisfiesAnAnyChildrenGate reaches past
// the role for a waits-for gate.
//
// bd_events_journal is asserted at TWO, not one: unlike the change-free
// re-add, this path still calls issueops.RecordDepEventInTx — dependencies.go
// calls it "an observable graph mutation" and journals the complete
// replacement edge for replay — so the second write adds its own journal
// entry even though it adds no second row to "dependencies" and no second
// dependency_added row to "events", because those two describe the STORED
// ROW and the AUDIT TRAIL, neither of which duplicates on a metadata-only
// change.
func RunDependencyEditorSameTypeReAddWithChangedMetadataMintsOneVersion(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.AddDependency == nil {
		t.Skip("fixture has no AddDependency hook: metadata is not settable through publicops.DependencyEdge")
	}
	fixture.SetJournalEnabled(true)
	t.Cleanup(func() { fixture.SetJournalEnabled(false) })
	fixture.SetVersionedHistoryEnabled(true)
	t.Cleanup(func() { fixture.SetVersionedHistoryEnabled(false) })
	source := fixture.IssuePrefix + "-idemmeta-source"
	target := fixture.IssuePrefix + "-idemmeta-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	first := &types.Dependency{IssueID: source, DependsOnID: target, Type: types.DepBlocks, Metadata: `{"note":"v1"}`}
	if err := fixture.AddDependency(ctx, first, "writer"); err != nil {
		t.Fatalf("AddDependency first: %v", err)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(types.DepBlocks), 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))

	versionsBefore := countDependencyEditorIssueVersions(t, ctx, fixture, source)
	second := &types.Dependency{IssueID: source, DependsOnID: target, Type: types.DepBlocks, Metadata: `{"note":"v2"}`}
	if err := fixture.AddDependency(ctx, second, "writer"); err != nil {
		t.Fatalf("re-adding the same edge with changed metadata refused: %v", err)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(types.DepBlocks), 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)

	var journalCount int
	if err := fixture.QueryScalar(ctx,
		"SELECT COUNT(*) FROM bd_events_journal WHERE issue_id = ? AND op = ?",
		[]any{source, string(storeops.EventDepAdd)}, &journalCount); err != nil {
		t.Fatalf("count bd_events_journal dep_add rows for %s: %v", source, err)
	}
	if journalCount != 2 {
		t.Errorf("bd_events_journal dep_add rows for %s = %d, want 2: the metadata-changed re-add must journal its own replacement-edge entry", source, journalCount)
	}

	var storedMetadata string
	if err := fixture.QueryScalar(ctx,
		"SELECT metadata FROM dependencies WHERE issue_id = ? AND COALESCE(depends_on_issue_id, depends_on_wisp_id, depends_on_external) = ?",
		[]any{source, target}, &storedMetadata); err != nil {
		t.Fatalf("read stored metadata for %s -> %s: %v", source, target, err)
	}
	// Compared after re-encoding rather than byte-for-byte: a native JSON
	// column is free to re-canonicalize what it stores (e.g. inserting the
	// space after ':' Dolt's does), and that is not the thing this case is
	// about. canonicalizeForContract has no numeric blind spot here because
	// this fixture's metadata values never carry a bare JSON number.
	storedCanon, err := canonicalizeForContract(json.RawMessage(storedMetadata))
	if err != nil {
		t.Fatalf("canonicalize stored metadata for %s -> %s: %v", source, target, err)
	}
	wantCanon, err := canonicalizeForContract(json.RawMessage(second.Metadata))
	if err != nil {
		t.Fatalf("canonicalize want metadata for %s -> %s: %v", source, target, err)
	}
	if storedCanon != wantCanon {
		t.Errorf("stored metadata = %s, want %s: the re-add must persist the NEW metadata, not keep the old", storedCanon, wantCanon)
	}

	// Not dependencyEditorHistoryProbe/CountHistory: AddDependency seeds this
	// edge out of band of the role, through the backend's raw store path, and
	// on at least one backend that path never issues the version-control
	// commit CountHistory counts — only the role's own transaction wrapper
	// does. issue_versions is the seam both paths mint through, so it is the
	// one signal that is meaningful for a write reached this way.
	if delta := countDependencyEditorIssueVersions(t, ctx, fixture, source) - versionsBefore; delta != 1 {
		t.Errorf("issue_versions rows for %s went %d -> %d (delta %d), want a delta of 1: the metadata genuinely changed, so the re-add is a real mutation of the source issue and must mint exactly one version (#5898 leg 2)", source, versionsBefore, versionsBefore+delta, delta)
	}
}

// countDependencyEditorIssueVersions reports how many issue_versions rows
// exist for the given issue. Shared by every case here that asserts a
// version DELTA rather than an absolute count: the fixture's issues accrue
// versions from more than this one seam, so the relative change across an
// operation is the only thing a case can rely on.
func countDependencyEditorIssueVersions(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string) int {
	t.Helper()
	var count int
	if err := fixture.QueryScalar(ctx, "SELECT COUNT(*) FROM issue_versions WHERE issue_id = ?", []any{id}, &count); err != nil {
		t.Fatalf("count issue_versions rows for %s: %v", id, err)
	}
	return count
}

// RunDependencyEditorSameTypeReAddWithIdenticalMetadataIsANoOp pins the leg of
// the same-type re-add clause that
// RunDependencyEditorSameTypeReAddWithChangedMetadataMintsOneVersion
// deliberately does not cover: metadata that is byte-different but
// SEMANTICALLY IDENTICAL to what is already stored. A native JSON column is
// free to re-canonicalize what it persists — Dolt's inserts a space after
// ':', sorts object keys, and narrows a bare integral float to an int — so a
// comparison written against the raw bytes the caller last sent, rather than
// a canonical form of what is actually stored, reports a change that never
// happened and mints a version for a write that changed nothing (#6650).
//
// Two sub-cases pin the two distinct ways "byte-different" can still mean
// "the same value", using the same real-world shape
// (internal/types.WaitsForMeta, which is what a waits-for edge's metadata
// actually is):
//   - CompactSpelling re-adds the exact compact spelling
//     json.Marshal(types.WaitsForMeta{Gate: "any-children"}) already
//     produced. The caller sends identical bytes both times; only Dolt's own
//     storage-side renormalization of the FIRST write can make the stored
//     form disagree with them.
//   - ReorderedKeys re-adds the same fields with their keys spelled in a
//     different order — a caller-side difference no byte comparison
//     survives, but the same JSON value all the same.
//
// Both must be a no-op by the same signals
// RunDependencyEditorSameTypeReAddWithChangedMetadataMintsOneVersion checks
// for a real change: the stored row, the events table, the journal, and the
// issue_versions delta all have to read as "nothing happened."
func RunDependencyEditorSameTypeReAddWithIdenticalMetadataIsANoOp(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.AddDependency == nil {
		t.Skip("fixture has no AddDependency hook: metadata is not settable through publicops.DependencyEdge")
	}

	compact, err := json.Marshal(types.WaitsForMeta{Gate: "any-children"})
	if err != nil {
		t.Fatalf("marshal compact WaitsForMeta: %v", err)
	}

	for _, sub := range []struct {
		name  string
		tag   string
		first string
		readd string
	}{
		{
			name:  "CompactSpelling",
			tag:   "idemmetasame-compact",
			first: string(compact),
			readd: string(compact),
		},
		{
			name:  "ReorderedKeys",
			tag:   "idemmetasame-reorder",
			first: `{"gate":"any-children","spawner_id":"src-1"}`,
			readd: `{"spawner_id":"src-1","gate":"any-children"}`,
		},
	} {
		t.Run(sub.name, func(t *testing.T) {
			fixture.SetJournalEnabled(true)
			t.Cleanup(func() { fixture.SetJournalEnabled(false) })
			fixture.SetVersionedHistoryEnabled(true)
			t.Cleanup(func() { fixture.SetVersionedHistoryEnabled(false) })
			source := fixture.IssuePrefix + "-" + sub.tag + "-source"
			target := fixture.IssuePrefix + "-" + sub.tag + "-target"
			seedDependencyEditorIssue(t, ctx, fixture, source)
			seedDependencyEditorIssue(t, ctx, fixture, target)

			first := &types.Dependency{IssueID: source, DependsOnID: target, Type: types.DepBlocks, Metadata: sub.first}
			if err := fixture.AddDependency(ctx, first, "writer"); err != nil {
				t.Fatalf("AddDependency first: %v", err)
			}
			assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
			assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(types.DepBlocks), 1)
			assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
			assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))

			versionsBefore := countDependencyEditorIssueVersions(t, ctx, fixture, source)
			second := &types.Dependency{IssueID: source, DependsOnID: target, Type: types.DepBlocks, Metadata: sub.readd}
			if err := fixture.AddDependency(ctx, second, "writer"); err != nil {
				t.Fatalf("re-adding the same edge with semantically identical metadata refused: %v", err)
			}
			assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
			assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(types.DepBlocks), 1)
			assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
			assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))

			if delta := countDependencyEditorIssueVersions(t, ctx, fixture, source) - versionsBefore; delta != 0 {
				t.Errorf("issue_versions rows for %s went %d -> %d (delta %d), want a delta of 0: the re-add's metadata is semantically identical to what is already stored (byte differences aside), so nothing changed and nothing should be versioned (#6650)", source, versionsBefore, versionsBefore+delta, delta)
			}
		})
	}
}

// RunDependencyEditorSameTypeReAddWithChangedThreadMintsOneVersion is the
// thread_id twin of
// RunDependencyEditorSameTypeReAddWithChangedMetadataMintsOneVersion. The row
// carries a thread as well as metadata, and the source issue's version snapshot
// carries each edge's thread_id, so a same-type re-add naming a thread the row
// does not carry is a real mutation on the same terms as a metadata change:
// the leaf updates the row in place, journals the replacement edge, and mints
// EXACTLY ONE version (#5898 leg 2). The re-add arm once compared metadata
// alone, which read that re-add as change-free and dropped the thread.
//
// The metadata is identical across every write, so the thread is the only
// thing that moves. A last re-add names no thread, and is the change-free
// no-op: an empty thread names none rather than asking for none, which is
// what keeps the callers that never carry a thread from erasing one.
//
// It drives the writes through fixture.AddDependency for the reason the
// metadata case gives: publicops.DependencyEdge carries no thread either.
func RunDependencyEditorSameTypeReAddWithChangedThreadMintsOneVersion(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.AddDependency == nil {
		t.Skip("fixture has no AddDependency hook: a thread is not settable through publicops.DependencyEdge")
	}
	fixture.SetJournalEnabled(true)
	t.Cleanup(func() { fixture.SetJournalEnabled(false) })
	fixture.SetVersionedHistoryEnabled(true)
	t.Cleanup(func() { fixture.SetVersionedHistoryEnabled(false) })
	source := fixture.IssuePrefix + "-idemthread-source"
	target := fixture.IssuePrefix + "-idemthread-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	const metadata = `{"note":"v1"}`
	add := func(thread, refusal string) {
		t.Helper()
		dep := &types.Dependency{IssueID: source, DependsOnID: target, Type: types.DepBlocks, Metadata: metadata, ThreadID: thread}
		if err := fixture.AddDependency(ctx, dep, "writer"); err != nil {
			t.Fatalf("%s: %v", refusal, err)
		}
		assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(types.DepBlocks), 1)
		assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
	}
	storedThread := func() string {
		t.Helper()
		var thread string
		if err := fixture.QueryScalar(ctx,
			"SELECT COALESCE(thread_id, '') FROM dependencies WHERE issue_id = ? AND COALESCE(depends_on_issue_id, depends_on_wisp_id, depends_on_external) = ?",
			[]any{source, target}, &thread); err != nil {
			t.Fatalf("read stored thread_id for %s -> %s: %v", source, target, err)
		}
		return thread
	}
	journalCount := func() int {
		t.Helper()
		var count int
		if err := fixture.QueryScalar(ctx,
			"SELECT COUNT(*) FROM bd_events_journal WHERE issue_id = ? AND op = ?",
			[]any{source, string(storeops.EventDepAdd)}, &count); err != nil {
			t.Fatalf("count bd_events_journal dep_add rows for %s: %v", source, err)
		}
		return count
	}

	add("", "AddDependency first")
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepAdd))

	versionsBefore := countDependencyEditorIssueVersions(t, ctx, fixture, source)
	add("thread-conv-1", "re-adding the same edge with a new thread refused")
	if got := storedThread(); got != "thread-conv-1" {
		t.Errorf("stored thread_id = %q, want %q: the re-add must persist the new thread, not keep the old", got, "thread-conv-1")
	}
	if got := journalCount(); got != 2 {
		t.Errorf("bd_events_journal dep_add rows for %s = %d, want 2: the thread-changed re-add must journal its own replacement-edge entry", source, got)
	}
	if delta := countDependencyEditorIssueVersions(t, ctx, fixture, source) - versionsBefore; delta != 1 {
		t.Errorf("issue_versions rows for %s went %d -> %d (delta %d), want a delta of 1: the thread genuinely changed, so the re-add is a real mutation of the source issue and must mint exactly one version (#5898 leg 2)", source, versionsBefore, versionsBefore+delta, delta)
	}

	versionsBefore = countDependencyEditorIssueVersions(t, ctx, fixture, source)
	add("", "re-adding the same edge naming no thread refused")
	if got := storedThread(); got != "thread-conv-1" {
		t.Errorf("stored thread_id after a re-add naming no thread = %q, want %q kept", got, "thread-conv-1")
	}
	if got := journalCount(); got != 2 {
		t.Errorf("bd_events_journal dep_add rows for %s = %d after a change-free re-add, want 2 still", source, got)
	}
	if delta := countDependencyEditorIssueVersions(t, ctx, fixture, source) - versionsBefore; delta != 0 {
		t.Errorf("issue_versions rows for %s went %d -> %d (delta %d) on a re-add naming no thread, want a delta of 0: it keeps the stored thread, so nothing changed (#5898 R3)", source, versionsBefore, versionsBefore+delta, delta)
	}
}

// RunDependencyEditorRepeatsWithinOneRequestCollapse pins the clause that
// answers a request naming ONE PAIR TWICE. The same-type re-add rule is stated
// for the pair rather than for the call, so the second occurrence inside a
// request finds the first already written and the pair is applied once — while
// the result still echoes every edge the caller asked for, because
// AddDependenciesResult.Added is all-or-nothing and echoes the REQUEST.
//
// The second half is the conflict: two DIFFERENT types for one pair in one
// request raise the same *DependencyTypeConflictError a pre-existing edge of
// the other type raises, and the all-or-nothing rule takes the first
// occurrence back out with it. That the refusal is the TYPED one is the part
// worth pinning — a backend that treated a within-request repeat as a distinct
// insert would surface a primary-key violation instead, which is the same
// refusal with none of the information.
func RunDependencyEditorRepeatsWithinOneRequestCollapse(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-repeat-source"
	target := fixture.IssuePrefix + "-repeat-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	edge := publicops.DependencyEdge{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}
	assertHistoryDelta := dependencyEditorHistoryProbe(t, ctx, fixture)
	result, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{edge, edge},
	})
	if err != nil {
		t.Fatalf("AddDependencies naming one pair twice: %v — a repeat is the same-type re-add rule applied inside the request", err)
	}
	if len(result.Added) != 2 || result.Added[0] != edge || result.Added[1] != edge {
		t.Errorf("Added = %#v, want both requested edges: the result echoes the REQUEST, not the rows written", result.Added)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyAdded, 1)
	assertHistoryDelta(1, "one pair named twice is one edge written, so it is still ONE history entry")

	conflictSource := fixture.IssuePrefix + "-repeat-conflict-source"
	conflictTarget := fixture.IssuePrefix + "-repeat-conflict-target"
	seedDependencyEditorIssue(t, ctx, fixture, conflictSource)
	seedDependencyEditorIssue(t, ctx, fixture, conflictTarget)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: conflictSource, DependsOnID: conflictTarget, Type: publicops.DepBlocks},
			{IssueID: conflictSource, DependsOnID: conflictTarget, Type: publicops.DepRelated},
		},
	})
	var conflict *publicops.DependencyTypeConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("one pair given two types in one request: error = %v, want *DependencyTypeConflictError", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, conflictSource)
}

// RunDependencyEditorAttributesItsEventsToTheActor pins what
// AddDependenciesRequest.Actor and RemoveDependencyRequest.Actor are FOR: the
// leaf says each is what the entry the operation records in the source's event
// stream is attributed to, and the result carries it nowhere else.
//
// Every other case in this file reads those rows as a plane-routing probe and
// counts them. This is the one that reads the attribution, and it uses a
// different actor for the add and the removal so a backend that stamped the
// row from anything but the request under way — a session identity, the
// creator, the previous actor — fails it.
func RunDependencyEditorAttributesItsEventsToTheActor(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-actor-source"
	target := fixture.IssuePrefix + "-actor-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "edge-author",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("AddDependencies: %v", err)
	}
	assertDependencyEditorEventActor(t, ctx, fixture, source, types.EventDependencyAdded, "edge-author")

	removed, err := fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		Actor: "edge-remover", IssueID: source, DependsOnID: target,
	})
	if err != nil || !removed.Removed {
		t.Fatalf("RemoveDependency = %#v, %v; want Removed true", removed, err)
	}
	assertDependencyEditorEventActor(t, ctx, fixture, source, types.EventDependencyRemoved, "edge-remover")
}

// RunDependencyEditorRetypeRefusalLeavesTheOriginalEdge pins the other half of
// the same clause (dependencyeditor.go:145-146): a conflicting type on a pair
// that already has an edge is *DependencyTypeConflictError, and because the
// request is all-or-nothing the edge that was already there is untouched.
func RunDependencyEditorRetypeRefusalLeavesTheOriginalEdge(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-retype-source"
	target := fixture.IssuePrefix + "-retype-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("seed the edge the retype will collide with: %v", err)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepRelated}},
	})
	var conflict *publicops.DependencyTypeConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("retype error = %v, want *DependencyTypeConflictError", err)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepRelated), 0)
}

// RunDependencyEditorRefusalWritesNothing pins dependencyeditor.go:143-144 —
// any refused edge refuses the whole request and writes nothing — on BOTH
// refusal paths: the per-edge cycle probe, which fires with an earlier edge of
// the same request already written, and the whole-graph gate that runs when
// SkipPerEdgeCycleCheck turned the probe off (dependencyeditor.go:66-70).
//
// The skip-probe half needs three edges because the cycle it closes only
// exists once all three of the request's own edges are in place, which is
// exactly what a per-edge probe cannot see.
func RunDependencyEditorRefusalWritesNothing(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	a := fixture.IssuePrefix + "-refuse-a"
	b := fixture.IssuePrefix + "-refuse-b"
	c := fixture.IssuePrefix + "-refuse-c"
	for _, id := range []string{a, b, c} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: a, DependsOnID: b, Type: publicops.DepBlocks},
			{IssueID: b, DependsOnID: a, Type: publicops.DepBlocks},
		},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("per-edge cycle error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, a, b)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor:                 "writer",
		SkipPerEdgeCycleCheck: true,
		Edges: []publicops.DependencyEdge{
			{IssueID: a, DependsOnID: b, Type: publicops.DepBlocks},
			{IssueID: b, DependsOnID: c, Type: publicops.DepBlocks},
			{IssueID: c, DependsOnID: a, Type: publicops.DepBlocks},
		},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("skip-probe cycle error = %v, want ErrDependencyCycle from the final gate", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, a, b, c)
}

// RunDependencyEditorRemoveIsIdempotent pins
// RemoveDependencyResult.Removed (dependencyeditor.go:97-101, :180-181): a
// missing edge is Removed false with a NIL error, not ErrNotFound, because an
// agent replaying its own teardown should not have to classify an error to
// discover it already ran.
// bd_events_journal is checked alongside the events table for the same
// reason RunDependencyEditorSameTypeReAddIsIdempotent checks it: the journal
// has no deduplication of its own, so a removal that finds nothing must not
// journal a dep_remove either. This side of #5898's R3 case is expected to
// already hold — RemoveDependencyInTx only records when it actually deleted a
// row — but it is pinned here so a future regression on this leg is caught
// alongside the add-side one rather than only on the leg that is broken today.
func RunDependencyEditorRemoveIsIdempotent(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	fixture.SetJournalEnabled(true)
	t.Cleanup(func() { fixture.SetJournalEnabled(false) })
	source := fixture.IssuePrefix + "-rm-source"
	target := fixture.IssuePrefix + "-rm-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("seed the edge to remove: %v", err)
	}

	request := publicops.RemoveDependencyRequest{Actor: "writer", IssueID: source, DependsOnID: target}
	removed, err := fixture.Editor.RemoveDependency(ctx, request)
	if err != nil {
		t.Fatalf("RemoveDependency: %v", err)
	}
	if !removed.Removed {
		t.Fatal("Removed = false, want true for an edge that existed")
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 0)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyRemoved, 1)
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepRemove))

	removed, err = fixture.Editor.RemoveDependency(ctx, request)
	if err != nil {
		t.Fatalf("replayed RemoveDependency error = %v, want nil: a missing edge is a success", err)
	}
	if removed.Removed {
		t.Error("Removed = true, want false for an edge that was already gone")
	}
	assertDependencyEditorEventCount(t, ctx, fixture, "events", source, types.EventDependencyRemoved, 1)
	assertDependencyEditorJournalCountIsOne(t, ctx, fixture, source, string(storeops.EventDepRemove))
}

// RunDependencyEditorAppliesParentChildBeforeBlockingEdges pins
// dependencyeditor.go:61-64: edges are applied parent-child first REGARDLESS of
// request order, so the complete planned hierarchy is visible before any
// blocking edge is validated against it.
//
// The ordering is what decides the ANSWER. Applied hierarchy-first, the
// grandparent is an ancestor of the child by the time `child blocks grand` is
// checked, so the request is refused with the hierarchy sentinel and nothing is
// written. Applied in request order, that blocking edge is validated against a
// hierarchy that does not exist yet — a backend doing that answers something
// else, or nothing at all.
func RunDependencyEditorAppliesParentChildBeforeBlockingEdges(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	grand := fixture.IssuePrefix + "-pcfirst-grand"
	parent := fixture.IssuePrefix + "-pcfirst-parent"
	child := fixture.IssuePrefix + "-pcfirst-child"
	for _, id := range []string{grand, parent, child} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: child, DependsOnID: grand, Type: publicops.DepBlocks},
			{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild},
			{IssueID: parent, DependsOnID: grand, Type: publicops.DepParentChild},
		},
	})
	var conflict *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("error = %v, want *DependencyHierarchyConflictError: the hierarchy this request creates is applied first", err)
	}
	if !conflict.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want the blocker reported as the child's ancestor", conflict)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, child, parent)
}

// RunDependencyEditorAcceptsAnExternalTarget pins the first half of
// dependencyeditor.go:150-156: a target's existence is checked only where the
// backend can see it, and an "external:" reference is not something this
// database holds, so there is no unknown-target refusal to make.
func RunDependencyEditorAcceptsAnExternalTarget(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-ext-source"
	const target = "external:https://example.invalid/tracker/17"
	seedDependencyEditorIssue(t, ctx, fixture, source)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("AddDependencies onto an external: target: %v", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
}

// RunDependencyEditorAcceptsAForeignRepoTarget pins the second half of
// dependencyeditor.go:150-156: an issue in ANOTHER REPOSITORY is equally not
// something this database holds.
//
// It is its own case rather than a second assertion in the external one
// because the two reach the target column by different routes — an "external:"
// prefix is a string test, a foreign repository is an id-prefix comparison
// against the source — so a backend can hold one promise and break the other.
// This is the promise the fk_dep_issue_target foreign key on
// depends_on_issue_id (internal/storage/schema/cli_migrations.go:141,155,168)
// turns into a write failure whenever a backend classifies the target as a
// local issue.
func RunDependencyEditorAcceptsAForeignRepoTarget(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-foreign-source"
	const target = "otherrig-9001"
	seedDependencyEditorIssue(t, ctx, fixture, source)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("AddDependencies onto a target in another repository: %v", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(publicops.DepBlocks), 1)
}

// RunDependencyEditorRefusesBlockingEdgeAcrossItsOwnHierarchy pins
// dependencyeditor.go:146-148: a blocking edge that would gate an issue on its
// own ancestor or descendant is *DependencyHierarchyConflictError.
//
// Both directions are asserted because they are two construction sites of the
// same typed sentinel, and the flag that distinguishes them is part of the
// value a caller reads.
func RunDependencyEditorRefusesBlockingEdgeAcrossItsOwnHierarchy(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	grand := fixture.IssuePrefix + "-hier-grand"
	parent := fixture.IssuePrefix + "-hier-parent"
	child := fixture.IssuePrefix + "-hier-child"
	for _, id := range []string{grand, parent, child} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: parent, DependsOnID: grand, Type: publicops.DepParentChild},
			{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild},
		},
	}); err != nil {
		t.Fatalf("seed the hierarchy: %v", err)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: child, DependsOnID: grand, Type: publicops.DepBlocks}},
	})
	var ancestor *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &ancestor) {
		t.Fatalf("gating a child on its ancestor: error = %v, want *DependencyHierarchyConflictError", err)
	}
	if !ancestor.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want BlockerIsAncestor true", ancestor)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", child, grand, string(publicops.DepBlocks), 0)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: grand, DependsOnID: child, Type: publicops.DepBlocks}},
	})
	var descendant *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &descendant) {
		t.Fatalf("gating an ancestor on its descendant: error = %v, want *DependencyHierarchyConflictError", err)
	}
	if descendant.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want BlockerIsAncestor false: the blocker is the DESCENDANT here", descendant)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", grand, child, string(publicops.DepBlocks), 0)
}

// RunDependencyEditorRefusesSelfDependencyWithTheProbeSkipped pins
// dependencyeditor.go:66-70: SkipPerEdgeCycleCheck never drops the
// self-dependency refusal. An edge that points an issue at itself is refused
// with ErrSelfDependency with or without the flag, and for every type — a
// non-scheduling self-edge is never seen by a cycle probe at all, so the flag
// is not what was refusing it.
func RunDependencyEditorRefusesSelfDependencyWithTheProbeSkipped(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-self-source"
	seedDependencyEditorIssue(t, ctx, fixture, source)

	for _, probe := range []struct {
		name    string
		skip    bool
		depType publicops.DependencyType
	}{
		{"blocking edge, probe on", false, publicops.DepBlocks},
		{"blocking edge, probe skipped", true, publicops.DepBlocks},
		{"non-scheduling edge, probe skipped", true, publicops.DepRelated},
	} {
		_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
			Actor:                 "writer",
			SkipPerEdgeCycleCheck: probe.skip,
			Edges:                 []publicops.DependencyEdge{{IssueID: source, DependsOnID: source, Type: probe.depType}},
		})
		if !errors.Is(err, publicops.ErrSelfDependency) {
			t.Errorf("%s: error = %v, want ErrSelfDependency", probe.name, err)
		}
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, source)
}

// RunDependencyEditorRecordsOneHistoryEntryPerLandedRequest pins
// dependencyeditor.go:142-143 and :100-101: an assertion is ONE durable act
// with one history entry however many edges it wrote, and a removal that found
// nothing writes nothing and records no entry.
//
// The counts are deltas taken around each call rather than absolutes, because
// seeding versions its own writes.
func RunDependencyEditorRecordsOneHistoryEntryPerLandedRequest(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.CountHistory == nil {
		t.Skip("fixture.CountHistory is nil: this backend cannot observe history, so the one-entry-per-request clause cannot be checked here")
	}
	a := fixture.IssuePrefix + "-hist-a"
	b := fixture.IssuePrefix + "-hist-b"
	c := fixture.IssuePrefix + "-hist-c"
	for _, id := range []string{a, b, c} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	before := dependencyEditorHistoryCount(t, ctx, fixture)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: a, DependsOnID: b, Type: publicops.DepBlocks},
			{IssueID: a, DependsOnID: c, Type: publicops.DepRelated},
		},
	}); err != nil {
		t.Fatalf("AddDependencies: %v", err)
	}
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 1, "two edges are ONE history entry")

	before = dependencyEditorHistoryCount(t, ctx, fixture)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: b, DependsOnID: a, Type: publicops.DepBlocks}},
	}); !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("cycle error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 0, "a refused request records no history")

	before = dependencyEditorHistoryCount(t, ctx, fixture)
	removed, err := fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		Actor: "writer", IssueID: a, DependsOnID: b,
	})
	if err != nil || !removed.Removed {
		t.Fatalf("RemoveDependency = %#v, %v; want Removed true", removed, err)
	}
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 1, "a removal that found its edge is one history entry")

	before = dependencyEditorHistoryCount(t, ctx, fixture)
	removed, err = fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		Actor: "writer", IssueID: a, DependsOnID: b,
	})
	if err != nil || removed.Removed {
		t.Fatalf("replayed RemoveDependency = %#v, %v; want Removed false and a nil error", removed, err)
	}
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 0, "a removal that found nothing records no history")
}

// RunDependencyEditorRecordsNoHistoryForAnAllEphemeralRequest pins
// dependencyeditor.go:122-123: only the durable half of the graph is versioned,
// so a request made entirely of ephemeral edges records no history entry. An
// edge is ephemeral when its SOURCE is, independently of the target's plane,
// which is why one of the two edges here points at a durable issue.
func RunDependencyEditorRecordsNoHistoryForAnAllEphemeralRequest(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.CountHistory == nil {
		t.Skip("fixture.CountHistory is nil: this backend cannot observe history, so the no-entry-for-ephemeral-edges clause cannot be checked here")
	}
	wisp := fixture.IssuePrefix + "-ephhist-wisp"
	otherWisp := fixture.IssuePrefix + "-ephhist-wisp2"
	issue := fixture.IssuePrefix + "-ephhist-issue"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorWisp(t, ctx, fixture, otherWisp)
	seedDependencyEditorIssue(t, ctx, fixture, issue)

	before := dependencyEditorHistoryCount(t, ctx, fixture)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: wisp, DependsOnID: issue, Type: publicops.DepBlocks},
			{IssueID: otherWisp, DependsOnID: wisp, Type: publicops.DepRelated},
		},
	}); err != nil {
		t.Fatalf("AddDependencies on an all-ephemeral request: %v", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "wisp_dependencies", wisp, issue, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "wisp_dependencies", otherWisp, wisp, string(publicops.DepRelated), 1)
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 0,
		"the wisp plane is not versioned, so a request made entirely of ephemeral edges records no history entry")
}

// RunDependencyEditorSnapshotsTheRequest pins dependencyeditor.go:137-138:
// implementations never mutate caller-owned request values and snapshot the
// request at method entry.
//
// The observable half of that is the result. Added is documented as echoing
// the request, and an implementation that echoed it by handing the caller's own
// slice back would satisfy every equality check in this file while quietly
// aliasing state the caller still owns — so the caller mutates its slice after
// the call and the result must not move.
func RunDependencyEditorSnapshotsTheRequest(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-snap-source"
	target := fixture.IssuePrefix + "-snap-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	edges := []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}}
	request := publicops.AddDependenciesRequest{Actor: "writer", Edges: edges}
	result, err := fixture.Editor.AddDependencies(ctx, request)
	if err != nil {
		t.Fatalf("AddDependencies: %v", err)
	}
	if edges[0] != (publicops.DependencyEdge{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}) {
		t.Fatalf("the caller's edge = %#v after the call, want it untouched", edges[0])
	}

	edges[0].DependsOnID = "rewritten-by-the-caller"
	if len(result.Added) != 1 || result.Added[0].DependsOnID != target {
		t.Fatalf("Added = %#v after the caller rewrote its own slice, want the edge it asked for: the result must not alias the request", result.Added)
	}
}

// RunDependencyEditorValidationRefusalsWriteNothing pins
// dependencyeditor.go:139-140: deterministic request-validation failures match
// ErrValidation and leave persistent state unchanged.
//
// The sentinel itself is pinned against the shared Validate* functions in a
// unit test; what only a live backend can show is the second half — that the
// refusal happened before anything was written, including for the edges of a
// batch that preceded the invalid one.
func RunDependencyEditorValidationRefusalsWriteNothing(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-valid-source"
	target := fixture.IssuePrefix + "-valid-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	valid := publicops.DependencyEdge{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks}
	for _, refusal := range []struct {
		name    string
		request publicops.AddDependenciesRequest
	}{
		{"no actor", publicops.AddDependenciesRequest{Edges: []publicops.DependencyEdge{valid}}},
		{"no edges", publicops.AddDependenciesRequest{Actor: "writer"}},
		{"an edge with no type", publicops.AddDependenciesRequest{Actor: "writer", Edges: []publicops.DependencyEdge{
			valid,
			{IssueID: source, DependsOnID: target + "-2"},
		}}},
	} {
		if _, err := fixture.Editor.AddDependencies(ctx, refusal.request); !errors.Is(err, publicops.ErrValidation) {
			t.Errorf("AddDependencies with %s: error = %v, want ErrValidation", refusal.name, err)
		}
	}
	if _, err := fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		IssueID: source, DependsOnID: target,
	}); !errors.Is(err, publicops.ErrValidation) {
		t.Errorf("RemoveDependency with no actor: error = %v, want ErrValidation", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, source)
}

// RunDependencyEditorRoutesWispSourcedRemovalToTheWispPlane pins the REMOVE
// half of dependencyeditor.go:117-123. An edge follows its source on BOTH
// methods, so removing a wisp-sourced edge deletes from wisp_dependencies,
// leaves the durable pair untouched, and records no history entry — only the
// durable half is versioned.
//
// The add side of that clause got four cases because routing is what the three
// implementations had actually diverged on. The remove side had none at this
// seam, and it is a genuinely separate decision in the code: the add pins
// routing from a source set read once for the whole request, a removal reads it
// per call.
//
// The wisp_events assertions are contractual now rather than a probe: the leaf
// promises the entry follows the source's plane, and says why that matters
// most for an ephemeral edge — the wisp plane is not versioned, so the entry is
// the only record the operation leaves.
func RunDependencyEditorRoutesWispSourcedRemovalToTheWispPlane(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	wisp := fixture.IssuePrefix + "-wrm-wisp"
	target := fixture.IssuePrefix + "-wrm-target"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: wisp, DependsOnID: target, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("seed the wisp-sourced edge to remove: %v", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, target, 1)

	request := publicops.RemoveDependencyRequest{Actor: "remover", IssueID: wisp, DependsOnID: target}
	assertHistoryDelta := dependencyEditorHistoryProbe(t, ctx, fixture)
	removed, err := fixture.Editor.RemoveDependency(ctx, request)
	if err != nil {
		t.Fatalf("RemoveDependency on a wisp-sourced edge: %v", err)
	}
	if !removed.Removed {
		t.Error("Removed = false, want true: the edge was there, in the plane its SOURCE lives in")
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "wisp_dependencies", wisp, 0)
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", wisp, 0)
	assertDependencyEditorEventCount(t, ctx, fixture, "wisp_events", wisp, types.EventDependencyRemoved, 1)
	assertDependencyEditorEventCount(t, ctx, fixture, "events", wisp, types.EventDependencyRemoved, 0)
	assertHistoryDelta(0, "the wisp plane is not versioned, so removing an ephemeral edge records no history entry")

	assertHistoryDelta = dependencyEditorHistoryProbe(t, ctx, fixture)
	removed, err = fixture.Editor.RemoveDependency(ctx, request)
	if err != nil {
		t.Fatalf("replayed RemoveDependency on a wisp-sourced edge = %v, want nil: a missing edge is a success in either plane", err)
	}
	if removed.Removed {
		t.Error("Removed = true, want false for a wisp-sourced edge that was already gone")
	}
	assertDependencyEditorEventCount(t, ctx, fixture, "wisp_events", wisp, types.EventDependencyRemoved, 1)
	assertHistoryDelta(0, "a removal that found nothing records no history in either plane")
}

// RunDependencyEditorRefusesAGhostSource pins the fifth refusal in
// dependencyeditor.go:143-148 — "a SOURCE that does not exist" — together with
// its all-or-nothing consequence: the edge of the same request that was already
// written comes back out.
//
// The ghost id is a strict PREFIX of a seeded id rather than a random unknown
// one, so the case doubles as the pin for dependencyeditor.go:34-37: both
// endpoints are exact canonical ids and there is no prefix resolution on this
// contract. A backend that resolved it would land the edge under the seeded id
// instead of refusing, and the ordinary unknown-id spelling could never tell.
//
// This refusal is checked ahead of the target's (dependencies.go:214-235), so
// the target here is deliberately a real seeded issue: the refusal under test
// is about the source alone.
//
// The refusal's IDENTITY is asserted in BOTH POSITIONS. Alone in a request it
// is the only thing that can have failed; mid-batch it competes with the
// rollback of the edge already written, which is where an implementation that
// re-raised the refusal as its own wrapper — or as the rollback's error — would
// lose the type. The mid-batch half therefore reads the graph back at zero
// edges as well, because a typed refusal that left half a graph behind would
// still be the wrong answer.
func RunDependencyEditorRefusesAGhostSource(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-ghostsrc-known"
	target := fixture.IssuePrefix + "-ghostsrc-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)
	ghost := source[:len(source)-1]

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: ghost, DependsOnID: target, Type: publicops.DepBlocks}},
	})
	assertDependencyEndpointNotFound(t, err, "the sole edge of a request", publicops.ErrDependencySourceNotFound, ghost, target, ghost)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: source, DependsOnID: target, Type: publicops.DepBlocks},
			{IssueID: ghost, DependsOnID: target, Type: publicops.DepBlocks},
		},
	})
	assertDependencyEndpointNotFound(t, err, "the second edge of a request", publicops.ErrDependencySourceNotFound, ghost, target, ghost)
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, source, ghost)
}

// RunDependencyEditorRefusesAMissingLocalTarget pins the refusal half of the
// target-existence clause. Existence is checked "only where the backend can
// see it", and the two acceptance cases above pin what that therefore does NOT
// refuse — an "external:" reference and an issue in another repository. The
// leaf states the half neither of them covers outright: a target whose absence
// the backend CAN see — same prefix, no "external:" marker, no row — is refused
// and nothing is written. Without it the clause reads as a blanket amnesty,
// which is the opposite of what it says.
//
// The refusal is ErrDependencyTargetNotFound and not the source's sentinel,
// asserted in both positions for the reason the ghost-source case gives. The
// two are separate answers, so a backend that raised one endpoint's refusal for
// the other's absence would send a caller to fix the wrong id.
func RunDependencyEditorRefusesAMissingLocalTarget(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-notgt-source"
	other := fixture.IssuePrefix + "-notgt-other"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, other)
	// Same prefix as the source, so it is neither an external reference nor
	// another repository's id: this database is exactly where it would be.
	missing := fixture.IssuePrefix + "-notgt-ghost"

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: missing, Type: publicops.DepBlocks}},
	})
	assertDependencyEndpointNotFound(t, err, "the sole edge of a request", publicops.ErrDependencyTargetNotFound, source, missing, missing)
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, source)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: source, DependsOnID: other, Type: publicops.DepBlocks},
			{IssueID: source, DependsOnID: missing, Type: publicops.DepBlocks},
		},
	})
	assertDependencyEndpointNotFound(t, err, "the second edge of a request", publicops.ErrDependencyTargetNotFound, source, missing, missing)
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, source)
}

// assertDependencyEndpointNotFound is the shared shape of the two
// endpoint-existence refusals: the sentinel a caller branches on, and the typed
// value carrying which edge was refused and which of its endpoints was absent.
// Reading the fields is the point — the message is prose and is not a promise,
// so a caller that needs the id must be able to take it from the value.
func assertDependencyEndpointNotFound(t *testing.T, err error, position string, sentinel error, issueID, dependsOnID, missingID string) {
	t.Helper()
	if !errors.Is(err, sentinel) {
		t.Fatalf("%s: error = %v, want errors.Is %v", position, err, sentinel)
	}
	var missing *publicops.DependencyEndpointNotFoundError
	if !errors.As(err, &missing) {
		t.Fatalf("%s: error = %v, want *DependencyEndpointNotFoundError", position, err)
	}
	if missing.IssueID != issueID || missing.DependsOnID != dependsOnID || missing.MissingID != missingID {
		t.Errorf("%s: refusal = %+v, want the edge %s -> %s with %s missing",
			position, missing, issueID, dependsOnID, missingID)
	}
}

// dependencyEditorUnlistedType is a DependencyType deliberately absent from the
// Dep* constants: a plausible workspace-configured value, short enough for the
// column, and outside the scheduling set, so nothing but the open-set rule
// decides whether it is accepted.
const dependencyEditorUnlistedType publicops.DependencyType = "caused-by"

// RunDependencyEditorAcceptsATypeOutsideTheConstants pins the open-set rule
// (dependencyeditor.go:13-19, :41-44) END TO END. An implementation that
// refused a type absent from the constants "would break every workspace that
// spelled one of its own", and the constants "never authorize" a value — so
// acceptance cannot be a property of the listed six.
//
// The validator half is owned by a unit test against
// ValidateAddDependenciesRequest. What only a live backend can show is the rest
// of the write path: the scheduling-edge switch that reads the type, the target
// classification, the type column itself, and the existing-edge lookup that has
// to recognize the unlisted value as the SAME type on a re-add rather than
// raising a conflict against something it does not know.
func RunDependencyEditorAcceptsATypeOutsideTheConstants(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-opentype-source"
	target := fixture.IssuePrefix + "-opentype-target"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	request := publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: source, DependsOnID: target, Type: dependencyEditorUnlistedType}},
	}
	result, err := fixture.Editor.AddDependencies(ctx, request)
	if err != nil {
		t.Fatalf("AddDependencies with the unlisted type %q: %v — the vocabulary is an open set", dependencyEditorUnlistedType, err)
	}
	if len(result.Added) != 1 || result.Added[0].Type != dependencyEditorUnlistedType {
		t.Errorf("Added = %#v, want the edge as spelled: the result must not normalize a type to a listed one", result.Added)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(dependencyEditorUnlistedType), 1)

	if _, err := fixture.Editor.AddDependencies(ctx, request); err != nil {
		t.Fatalf("re-adding the unlisted-type edge refused: %v — same type is idempotent whatever the type is", err)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, target, string(dependencyEditorUnlistedType), 1)
}

// RunDependencyEditorRemovesOnlyTheNamedEdge pins "removes exactly the named
// edge" (dependencyeditor.go:180) as a statement about the edges it does NOT
// touch: a sibling edge from the same source survives a removal aimed at its
// neighbor.
//
// The edge removed is the "external:" one, which makes this the REMOVAL half of
// :136-139 as well. A target the backend cannot resolve is still a target a
// caller may name, and it lives in a different column from an ordinary one —
// so an implementation that matched removals against depends_on_issue_id alone
// reports Removed false here and leaves the edge in place.
func RunDependencyEditorRemovesOnlyTheNamedEdge(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	source := fixture.IssuePrefix + "-rmnamed-source"
	sibling := fixture.IssuePrefix + "-rmnamed-sibling"
	const external = "external:https://example.invalid/tracker/44"
	seedDependencyEditorIssue(t, ctx, fixture, source)
	seedDependencyEditorIssue(t, ctx, fixture, sibling)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: source, DependsOnID: sibling, Type: publicops.DepBlocks},
			{IssueID: source, DependsOnID: external, Type: publicops.DepRelated},
		},
	}); err != nil {
		t.Fatalf("seed the two edges from one source: %v", err)
	}
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 2)

	removed, err := fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		Actor: "remover", IssueID: source, DependsOnID: external,
	})
	if err != nil {
		t.Fatalf("RemoveDependency naming the external target: %v", err)
	}
	if !removed.Removed {
		t.Error("Removed = false, want true: an external target is still an edge a caller can name")
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, external, string(publicops.DepRelated), 0)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", source, sibling, string(publicops.DepBlocks), 1)
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", source, 1)
}

// RunDependencyEditorSkipPerEdgeCycleCheckDropsOnlyTheProbe pins the rest of
// dependencyeditor.go:66-71. Two existing cases show what the flag does NOT
// drop — the whole-graph gate and the self-dependency refusal — but both are
// refusals, and so is every other skip=true request in this file. Nothing yet
// shows the flag doing the thing it exists for: a caller wiring a large acyclic
// graph gets the graph, and gets it persisted.
//
// The second half is that the other typed refusals still fire under it. A
// backend that read the flag as "skip validation" rather than "skip the
// per-edge cycle probe" passes every existing case in this file and fails this
// one.
func RunDependencyEditorSkipPerEdgeCycleCheckDropsOnlyTheProbe(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	a := fixture.IssuePrefix + "-skipok-a"
	b := fixture.IssuePrefix + "-skipok-b"
	c := fixture.IssuePrefix + "-skipok-c"
	for _, id := range []string{a, b, c} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	result, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor:                 "writer",
		SkipPerEdgeCycleCheck: true,
		Edges: []publicops.DependencyEdge{
			{IssueID: a, DependsOnID: b, Type: publicops.DepBlocks},
			{IssueID: b, DependsOnID: c, Type: publicops.DepBlocks},
		},
	})
	if err != nil {
		t.Fatalf("AddDependencies on an acyclic graph with the probe skipped: %v", err)
	}
	if len(result.Added) != 2 {
		t.Errorf("Added = %#v, want both edges", result.Added)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", a, b, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", b, c, string(publicops.DepBlocks), 1)

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor:                 "writer",
		SkipPerEdgeCycleCheck: true,
		Edges:                 []publicops.DependencyEdge{{IssueID: a, DependsOnID: b, Type: publicops.DepRelated}},
	})
	var conflict *publicops.DependencyTypeConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("retype with the probe skipped: error = %v, want *DependencyTypeConflictError: the flag drops the cycle probe, not the typed refusals", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", a, b, string(publicops.DepBlocks), 1)
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", a, 1)
}

// RunDependencyEditorRecordsOneHistoryEntryForAMixedPlaneRequest interpolates
// between the two endpoints the file already pins: an all-durable request is
// one entry (RunDependencyEditorRecordsOneHistoryEntryPerLandedRequest) and an
// all-ephemeral one is none
// (RunDependencyEditorRecordsNoHistoryForAnAllEphemeralRequest). A request that
// mixes the planes is still ONE transaction (dependencyeditor.go:121) of which
// only the durable half is versioned (:117-118) — so one entry. Not two, which
// is what a backend versioning per plane rather than per request would record,
// and not zero, which is what a backend deciding "this request touches the
// ephemeral plane" once for the whole request would record.
func RunDependencyEditorRecordsOneHistoryEntryForAMixedPlaneRequest(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.CountHistory == nil {
		t.Skip("fixture.CountHistory is nil: this backend cannot observe history, so the mixed-plane entry count cannot be checked here")
	}
	wisp := fixture.IssuePrefix + "-mixhist-wisp"
	issue := fixture.IssuePrefix + "-mixhist-issue"
	target := fixture.IssuePrefix + "-mixhist-target"
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorIssue(t, ctx, fixture, issue)
	seedDependencyEditorIssue(t, ctx, fixture, target)

	before := dependencyEditorHistoryCount(t, ctx, fixture)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: wisp, DependsOnID: target, Type: publicops.DepBlocks},
			{IssueID: issue, DependsOnID: target, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("AddDependencies on a mixed-plane request: %v", err)
	}
	assertDependencyEdgeCount(t, ctx, fixture, "wisp_dependencies", wisp, target, 1)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", issue, target, 1)
	assertDependencyEditorHistoryDelta(t, ctx, fixture, before, 1,
		"a request spanning both planes is one transaction with one versioned half, so it is ONE history entry")
}

// RunDependencyEditorWritesTheTargetIntoItsTypedColumn pins the target
// CLASSIFICATION (issueops.ClassifyDepTarget) that dependencyeditor.go:150-156
// only describes from the outside. A dependency row holds its target in one of
// three typed columns — depends_on_issue_id, depends_on_wisp_id,
// depends_on_external — and which one it is is not cosmetic: only
// depends_on_issue_id carries fk_dep_issue_target into issues(id)
// (internal/storage/schema/cli_migrations.go:141,155,168), so a wisp or a
// foreign id filed there is a write that fails, and a local issue filed
// anywhere else is an edge no foreign key protects from a later delete.
//
// EVERY OTHER CASE IN THIS FILE IS BLIND TO THIS. They read the target through
// COALESCE(depends_on_issue_id, depends_on_wisp_id, depends_on_external), which
// resolves to the same id whichever column holds it — so a body that filed a
// wisp target as external passes all of them and fails only here.
//
// Both source planes are exercised because routing the SOURCE (which table the
// row lands in) and classifying the TARGET (which column inside it) are
// independent decisions, and a wisp-sourced edge is where they are easiest to
// conflate.
func RunDependencyEditorWritesTheTargetIntoItsTypedColumn(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	issue := fixture.IssuePrefix + "-tcol-issue"
	wisp := fixture.IssuePrefix + "-tcol-wisp"
	issueTarget := fixture.IssuePrefix + "-tcol-issuetgt"
	wispTarget := fixture.IssuePrefix + "-tcol-wisptgt"
	const external = "external:https://example.invalid/tracker/61"
	const foreign = "othertcol-9001"
	seedDependencyEditorIssue(t, ctx, fixture, issue)
	seedDependencyEditorIssue(t, ctx, fixture, issueTarget)
	seedDependencyEditorWisp(t, ctx, fixture, wisp)
	seedDependencyEditorWisp(t, ctx, fixture, wispTarget)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: issue, DependsOnID: issueTarget, Type: publicops.DepBlocks},
			{IssueID: issue, DependsOnID: wispTarget, Type: publicops.DepRelated},
			{IssueID: issue, DependsOnID: external, Type: publicops.DepRelated},
			{IssueID: issue, DependsOnID: foreign, Type: publicops.DepRelated},
			{IssueID: wisp, DependsOnID: wispTarget, Type: publicops.DepBlocks},
			{IssueID: wisp, DependsOnID: issueTarget, Type: publicops.DepRelated},
		},
	}); err != nil {
		t.Fatalf("AddDependencies over the four target classes: %v", err)
	}

	for _, want := range []struct {
		table  string
		source string
		target string
		column string
		why    string
	}{
		{"dependencies", issue, issueTarget, "depends_on_issue_id",
			"a local issue is the one target class the foreign key can hold"},
		{"dependencies", issue, wispTarget, "depends_on_wisp_id",
			"a wisp has no row in issues, so the issue-keyed column would fail its foreign key"},
		{"dependencies", issue, external, "depends_on_external",
			"an external: reference names something outside this database entirely"},
		{"dependencies", issue, foreign, "depends_on_external",
			"another repository's id lives in that rig's database, not this one"},
		{"wisp_dependencies", wisp, wispTarget, "depends_on_wisp_id",
			"the ephemeral plane classifies its targets by the same rule"},
		{"wisp_dependencies", wisp, issueTarget, "depends_on_issue_id",
			"a wisp-sourced edge onto a durable issue still files the target as an issue"},
	} {
		assertDependencyEditorTargetColumn(t, ctx, fixture, want.table, want.source, want.target, want.column, want.why)
	}
}

// RunDependencyEditorRefusesBlockingEdgeAcrossAWispHierarchy is the EPHEMERAL
// half of dependencyeditor.go:146-148.
//
// RunDependencyEditorRefusesBlockingEdgeAcrossItsOwnHierarchy seeds durable
// issues, and the hierarchy walk it exercises reads a UNION of both dependency
// tables. A body that read only the durable one passes that case and fails this
// one, and the deadlock it lets through is real: a wisp gated on its own
// ancestor never becomes ready, because the ancestor inherits the descendant's
// blocked state.
//
// The last arm is the boundary the walk deliberately does not cross. It climbs
// child → parent only, so two children of one wisp parent share a hierarchy
// COMPONENT but not a hierarchy LINE, and an ordering edge between them stays
// legal.
func RunDependencyEditorRefusesBlockingEdgeAcrossAWispHierarchy(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	parent := fixture.IssuePrefix + "-whier-parent"
	child := fixture.IssuePrefix + "-whier-child"
	sibling := fixture.IssuePrefix + "-whier-sibling"
	for _, id := range []string{parent, child, sibling} {
		seedDependencyEditorWisp(t, ctx, fixture, id)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild},
			{IssueID: sibling, DependsOnID: parent, Type: publicops.DepParentChild},
		},
	}); err != nil {
		t.Fatalf("seed the wisp hierarchy: %v", err)
	}

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: parent, DependsOnID: child, Type: publicops.DepBlocks}},
	})
	var descendant *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &descendant) {
		t.Fatalf("gating a wisp parent on its own child: error = %v, want *DependencyHierarchyConflictError", err)
	}
	if descendant.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want BlockerIsAncestor false: the blocker is the DESCENDANT here", descendant)
	}

	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		// conditional-blocks rather than blocks: the guard covers the whole
		// scheduling set, and this type has no constant in the public sample.
		Edges: []publicops.DependencyEdge{{IssueID: child, DependsOnID: parent, Type: types.DepConditionalBlocks}},
	})
	var ancestor *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &ancestor) {
		t.Fatalf("gating a wisp child on its own parent: error = %v, want *DependencyHierarchyConflictError", err)
	}
	if !ancestor.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want BlockerIsAncestor true", ancestor)
	}
	// The hierarchy refusal beats the type conflict the pair already carries:
	// the pair has a parent-child row, and a body checking the existing edge
	// first would report the wrong reason for the right refusal.
	var conflict *publicops.DependencyTypeConflictError
	if errors.As(err, &conflict) {
		t.Errorf("error = %#v, want the hierarchy conflict: the deadlock is the reason, not the pre-existing row", conflict)
	}

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: sibling, DependsOnID: child, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("ordering two children of one wisp parent: %v — siblings share a component, not a line", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "wisp_dependencies", sibling, child, string(publicops.DepBlocks), 1)
}

// RunDependencyEditorRefusesACycleThroughAParentChildHop pins the edge set the
// ADD-TIME gate walks, which is NOT the set DetectCycles walks.
// cycle_detector_contract.go says so from the other side — `parent-child` is
// outside the report's walk, "which the ADD-time gate does walk" — and nothing
// pinned the half that sentence asserts.
//
// It matters because a blocked parent propagates its blocked state to its
// children, so a loop alternating `blocks` and `parent-child` hops is a
// livelock in which nothing ever becomes ready, even though no `blocks` cycle
// exists anywhere in it. Every other cycle case in this file closes a loop made
// of blocking edges only, so a body narrowed to those passes all of them.
//
// Both closing orientations are asserted because they enter the gate
// differently: a blocking closing edge is checked by the per-edge probe on its
// own type, and a parent-child closing edge is one whose OWN type the walk has
// to include to see the loop at all.
//
// The last arm is the false-positive guard, and it is the reason this is one
// case rather than two: a body that treated every parent-child hop as a cycle
// would pass both refusals and refuse the ordinary shape — a chain of tasks
// each gating an epic it does not belong to — that the refusals exist to
// distinguish from.
func RunDependencyEditorRefusesACycleThroughAParentChildHop(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	// A closing BLOCKS edge: parentA -> childA -> parentB -> childB -> parentA,
	// alternating parent-child and blocks hops.
	parentA := fixture.IssuePrefix + "-pchop-b-pa"
	parentB := fixture.IssuePrefix + "-pchop-b-pb"
	childA := fixture.IssuePrefix + "-pchop-b-ca"
	childB := fixture.IssuePrefix + "-pchop-b-cb"
	for _, id := range []string{parentA, parentB, childA, childB} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: childA, DependsOnID: parentA, Type: publicops.DepParentChild},
			{IssueID: childB, DependsOnID: parentB, Type: publicops.DepParentChild},
			{IssueID: parentB, DependsOnID: childA, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the combined graph: %v", err)
	}
	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: parentA, DependsOnID: childB, Type: publicops.DepBlocks}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("a blocking edge closing a loop through parent-child hops: error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, parentA)

	// The same loop, with the PARENT-CHILD edge as the one that closes it.
	pcParentA := fixture.IssuePrefix + "-pchop-p-pa"
	pcParentB := fixture.IssuePrefix + "-pchop-p-pb"
	pcChildA := fixture.IssuePrefix + "-pchop-p-ca"
	pcChildB := fixture.IssuePrefix + "-pchop-p-cb"
	for _, id := range []string{pcParentA, pcParentB, pcChildA, pcChildB} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: pcChildA, DependsOnID: pcParentA, Type: publicops.DepParentChild},
			{IssueID: pcParentB, DependsOnID: pcChildA, Type: publicops.DepBlocks},
			{IssueID: pcParentA, DependsOnID: pcChildB, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the combined graph for the parent-child closing edge: %v", err)
	}
	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: pcChildB, DependsOnID: pcParentB, Type: publicops.DepParentChild}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("a parent-child edge closing a loop through blocking hops: error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, pcChildB)

	// The acyclic shape the two refusals must not also refuse: each child gates
	// an epic it does not belong to, and belongs to the next one along.
	const levels = 4
	chain := make([]publicops.DependencyEdge, 0, 2*levels)
	for i := 0; i < levels; i++ {
		parent := fmt.Sprintf("%s-pchop-chain-p%d", fixture.IssuePrefix, i)
		child := fmt.Sprintf("%s-pchop-chain-c%d", fixture.IssuePrefix, i)
		seedDependencyEditorIssue(t, ctx, fixture, parent)
		seedDependencyEditorIssue(t, ctx, fixture, child)
		chain = append(chain, publicops.DependencyEdge{IssueID: parent, DependsOnID: child, Type: publicops.DepBlocks})
		if i > 0 {
			previous := fmt.Sprintf("%s-pchop-chain-c%d", fixture.IssuePrefix, i-1)
			chain = append(chain, publicops.DependencyEdge{IssueID: previous, DependsOnID: parent, Type: publicops.DepParentChild})
		}
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{Actor: "writer", Edges: chain}); err != nil {
		t.Fatalf("an acyclic chain alternating blocking and parent-child hops: %v — the walk must not read every hierarchy as a loop", err)
	}
}

// RunDependencyEditorRefusesASamePlaneEdgeClosingACrossPlaneCycle is the half
// of bd-xe27 that RunDependencyEditorRefusesCrossPlaneCycle cannot reach.
//
// There, the edge under test CROSSES the planes itself, so a gate that decided
// to merge the two tables from the edge in front of it still refuses. Here both
// endpoints of the new edge live in ONE plane and only the INTERIOR of the loop
// leaves it — so the gate has to merge the tables unconditionally, from the
// graph rather than from the edge. That distinction was a real defect: the
// merged two-session check ran only when the closing edge crossed tiers, and a
// same-tier closing edge saw one session and let the cycle commit.
//
// Both orientations are asserted, because "the plane the endpoints share" and
// "the plane the interior visits" swap between them and the two tables are not
// symmetric — only one of them is versioned.
func RunDependencyEditorRefusesASamePlaneEdgeClosingACrossPlaneCycle(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	// Durable endpoints, the interior hop through the ephemeral plane:
	// issueA -> issueB (new) with issueB -> wisp -> issueA already stored.
	issueA := fixture.IssuePrefix + "-splane-issue-a"
	issueB := fixture.IssuePrefix + "-splane-issue-b"
	throughWisp := fixture.IssuePrefix + "-splane-via-wisp"
	seedDependencyEditorIssue(t, ctx, fixture, issueA)
	seedDependencyEditorIssue(t, ctx, fixture, issueB)
	seedDependencyEditorWisp(t, ctx, fixture, throughWisp)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: issueB, DependsOnID: throughWisp, Type: publicops.DepBlocks},
			{IssueID: throughWisp, DependsOnID: issueA, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the path that leaves the durable plane and comes back: %v", err)
	}
	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: issueA, DependsOnID: issueB, Type: publicops.DepBlocks}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("a durable edge closing a loop whose interior runs through the wisp plane: error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, issueA)

	// Ephemeral endpoints, the interior hop through the durable plane.
	wispA := fixture.IssuePrefix + "-splane-wisp-a"
	wispB := fixture.IssuePrefix + "-splane-wisp-b"
	throughIssue := fixture.IssuePrefix + "-splane-via-issue"
	seedDependencyEditorWisp(t, ctx, fixture, wispA)
	seedDependencyEditorWisp(t, ctx, fixture, wispB)
	seedDependencyEditorIssue(t, ctx, fixture, throughIssue)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: wispB, DependsOnID: throughIssue, Type: publicops.DepBlocks},
			{IssueID: throughIssue, DependsOnID: wispA, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the path that leaves the ephemeral plane and comes back: %v", err)
	}
	_, err = fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: wispA, DependsOnID: wispB, Type: publicops.DepBlocks}},
	})
	if !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("an ephemeral edge closing a loop whose interior runs through the durable plane: error = %v, want ErrDependencyCycle", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, wispA)
}

// RunDependencyEditorAddMarksItsSourceInTheSameVerb pins the local-write
// clause of issueops.BlockedStateInvariant on the add half of this role: an
// edge onto a LIVE target leaves the source's stored is_blocked settled inside
// the transaction that wrote the edge, and an edge onto a closed one leaves it
// alone.
//
// The two edges land in ONE request, so the twin differs from the subject in
// exactly one fact — the target's status — and nothing else. That is what makes
// the zero meaningful: the twin's edge is asserted present, so its 0 is a value
// the predicate produced rather than the absence of a seed. The retired
// is_blocked case failed on precisely that distinction.
//
// The subject read is RAW. Asking the role whether the source is blocked would
// pass against a backend that answered from the live edge set and never
// denormalized, which is the whole point of a derived-AND-persisted column.
func RunDependencyEditorAddMarksItsSourceInTheSameVerb(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	blocker := fixture.IssuePrefix + "-bsadd-blocker"
	source := fixture.IssuePrefix + "-bsadd-source"
	doneBlocker := fixture.IssuePrefix + "-bsadd-doneblocker"
	twin := fixture.IssuePrefix + "-bsadd-twin"
	control := fixture.IssuePrefix + "-bsadd-control"
	for _, id := range []string{blocker, source, twin, control} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	seedDependencyEditorIssueAtStatus(t, ctx, fixture, doneBlocker, types.StatusClosed)

	probe := newBlockedStateProbe(ctx, fixture.QueryScalar)
	flip := probe.watchFlip(t,
		[]blockedStateRow{blockedIssue(source)},
		[]blockedStateRow{blockedIssue(twin), blockedIssue(control)})

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: source, DependsOnID: blocker, Type: publicops.DepBlocks},
			{IssueID: twin, DependsOnID: doneBlocker, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("AddDependencies for the blocked-state add case: %v", err)
	}

	flip.requireFlippedTo(t, 1, "a blocks edge onto a live target blocks its source, and BlockedStateInvariant settles it in the writing transaction")
	probe.requireBlockedByOpenBlocker(t, blockedIssue(source), blockedIssue(blocker),
		"the postcondition is the flag AND the reason behind it")

	// The twin's zero is only worth anything if its edge actually landed.
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", twin, doneBlocker, string(publicops.DepBlocks), 1)
	if status := probe.rawStatus(t, blockedIssue(doneBlocker)); status != string(types.StatusClosed) {
		t.Fatalf("twin's blocker %s has status %q, want %q: the twin differs from the subject in the target's status alone",
			doneBlocker, status, types.StatusClosed)
	}
}

// RunDependencyEditorRemoveUnmarksItsSourceAndDescendants pins the remove half,
// and the part of the local-write clause that says the affected rows are not
// only the row the request names: removing the source's last blocking edge
// unblocks the source AND the parent-child descendant that inherited the block
// from it.
//
// THE DESCENDANT IS THE POINT. bd-6dnrw.44 item 3 was a unit-of-work body that
// computed the affected set without expanding by parent-child descendants, so
// the named row settled and its children stayed stale. A case that watched only
// the source would have passed against it.
//
// The child's precondition pins the flag AND zero direct blocker edges of its
// own, so the case cannot be satisfied by a child that was blocked for its own
// reasons — the pair the retired fixture-defect case lacked.
func RunDependencyEditorRemoveUnmarksItsSourceAndDescendants(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	blocker := fixture.IssuePrefix + "-bsrm-blocker"
	parent := fixture.IssuePrefix + "-bsrm-parent"
	child := fixture.IssuePrefix + "-bsrm-child"
	controlBlocker := fixture.IssuePrefix + "-bsrm-ctlblocker"
	controlParent := fixture.IssuePrefix + "-bsrm-ctlparent"
	for _, id := range []string{blocker, parent, child, controlBlocker, controlParent} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: parent, DependsOnID: blocker, Type: publicops.DepBlocks},
			{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild},
			{IssueID: controlParent, DependsOnID: controlBlocker, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the blocked hierarchy through the role: %v", err)
	}

	probe := newBlockedStateProbe(ctx, fixture.QueryScalar)
	probe.requireBlockedByOpenBlocker(t, blockedIssue(parent), blockedIssue(blocker), "the parent holds the only cause in this hierarchy")
	probe.requireBlockedWithNoDirectBlockerEdges(t, blockedIssue(child), "the child's block is INHERITED, which is what the removal has to reach")
	probe.requireBlockedByOpenBlocker(t, blockedIssue(controlParent), blockedIssue(controlBlocker), "the control's cause is not the one being removed")

	flip := probe.watchFlip(t,
		[]blockedStateRow{blockedIssue(parent), blockedIssue(child)},
		[]blockedStateRow{blockedIssue(controlParent)})

	removed, err := fixture.Editor.RemoveDependency(ctx, publicops.RemoveDependencyRequest{
		Actor: "writer", IssueID: parent, DependsOnID: blocker,
	})
	if err != nil {
		t.Fatalf("RemoveDependency %s -> %s: %v", parent, blocker, err)
	}
	if !removed.Removed {
		t.Fatalf("RemoveDependency %s -> %s reported Removed = false, want the seeded edge", parent, blocker)
	}

	flip.requireFlippedTo(t, 0,
		"removing the last cause unblocks the source AND everything that inherited from it, per BlockedStateInvariant's local-write clause")
}

// RunDependencyEditorMaintainsBlockedStateAcrossPlanes pins the clause that
// blocking crosses the two planes in BOTH directions, and that inheritance
// crosses them too. All four subjects settle inside one request.
//
// PLANE RESIDENCY IS ASSERTED, not assumed. Cross-plane and cross-tier is where
// the earlier is_blocked defects lived, and a wisp that leaked a durable row
// would still read a correct flag from one of the two tables — so each row is
// checked present in its own plane's table and ABSENT from the other before the
// flags mean anything.
//
// The wisp child is the sharpest of the four: its parent is a durable issue and
// its own edge lives in wisp_dependencies, so it is reached only by an affected
// set that expands across planes as well as down the hierarchy.
func RunDependencyEditorMaintainsBlockedStateAcrossPlanes(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	issueTarget := fixture.IssuePrefix + "-bsxp-issuetarget"
	wispSource := fixture.IssuePrefix + "-bsxp-wispsource"
	wispTarget := fixture.IssuePrefix + "-bsxp-wisptarget"
	issueSource := fixture.IssuePrefix + "-bsxp-issuesource"
	blockedParent := fixture.IssuePrefix + "-bsxp-parent"
	wispChild := fixture.IssuePrefix + "-bsxp-wispchild"
	freeIssue := fixture.IssuePrefix + "-bsxp-freeissue"
	freeWisp := fixture.IssuePrefix + "-bsxp-freewisp"
	for _, id := range []string{issueTarget, issueSource, blockedParent, freeIssue} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	for _, id := range []string{wispSource, wispTarget, wispChild, freeWisp} {
		seedDependencyEditorWisp(t, ctx, fixture, id)
	}

	probe := newBlockedStateProbe(ctx, fixture.QueryScalar)
	for _, row := range []blockedStateRow{
		blockedIssue(issueTarget), blockedIssue(issueSource), blockedIssue(blockedParent), blockedIssue(freeIssue),
		blockedWisp(wispSource), blockedWisp(wispTarget), blockedWisp(wispChild), blockedWisp(freeWisp),
	} {
		probe.requirePlaneResidency(t, row)
	}

	flip := probe.watchFlip(t,
		[]blockedStateRow{blockedWisp(wispSource), blockedIssue(issueSource), blockedIssue(blockedParent), blockedWisp(wispChild)},
		[]blockedStateRow{blockedIssue(freeIssue), blockedWisp(freeWisp)})

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			// wisp blocked by issue, and issue blocked by wisp: the two
			// directions the invariant says are symmetric.
			{IssueID: wispSource, DependsOnID: issueTarget, Type: publicops.DepBlocks},
			{IssueID: issueSource, DependsOnID: wispTarget, Type: publicops.DepBlocks},
			// A wisp child inheriting from a durable blocked parent. The
			// parent-child edge is applied FIRST (the role applies hierarchy
			// before blocking edges), so the child is only reachable through the
			// affected set the later blocking edge expands.
			{IssueID: wispChild, DependsOnID: blockedParent, Type: publicops.DepParentChild},
			{IssueID: blockedParent, DependsOnID: issueTarget, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("AddDependencies across both planes: %v", err)
	}

	flip.requireFlippedTo(t, 1, "blocking and inheritance cross the two planes in both directions")
	probe.requireBlockedByOpenBlocker(t, blockedWisp(wispSource), blockedIssue(issueTarget), "a wisp is blocked by a live issue")
	probe.requireBlockedByOpenBlocker(t, blockedIssue(issueSource), blockedWisp(wispTarget), "an issue is blocked by a live wisp")
	probe.requireBlockedWithNoDirectBlockerEdges(t, blockedWisp(wispChild),
		"the wisp child's block is inherited across the plane boundary, not its own")
}

// RunDependencyEditorClosedChildAddSatisfiesAnAnyChildrenGate pins the ONE add
// that is not monotonic, and it is the case that tells MARK-ONLY wiring from
// RECOMPUTE wiring.
//
// Every other add can only ADD blockage, so both hand-mirrored bodies take a
// mark-only pass for it. A parent-child add cannot: an ALREADY-CLOSED child
// satisfies an any-children waits-for gate, so the waiter must come UNBLOCKED
// as a result of an add. Both bodies carve that case out to a full recompute
// and both say so in a comment; nothing pinned it at the role until now. Swap
// either carve-out back to the mark-only pass and this case is the one that
// goes red.
//
// The control is a second waiter on the SAME spawner under the default
// all-children gate. It is inside the affected set — the same recompute visits
// it — and it must stay blocked, so the case separates "the gate was
// re-evaluated" from "the flag was cleared".
func RunDependencyEditorClosedChildAddSatisfiesAnAnyChildrenGate(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	if fixture.AddDependency == nil {
		t.Skip("fixture has no AddDependency hook: a waits-for GATE lives in edge metadata, which AddDependenciesRequest cannot carry")
	}
	spawner := fixture.IssuePrefix + "-bsgate-spawner"
	openChild := fixture.IssuePrefix + "-bsgate-openchild"
	closedChild := fixture.IssuePrefix + "-bsgate-closedchild"
	waiterAny := fixture.IssuePrefix + "-bsgate-waiterany"
	waiterAll := fixture.IssuePrefix + "-bsgate-waiterall"
	for _, id := range []string{spawner, openChild, waiterAny, waiterAll} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}
	seedDependencyEditorIssueAtStatus(t, ctx, fixture, closedChild, types.StatusClosed)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: openChild, DependsOnID: spawner, Type: publicops.DepParentChild}},
	}); err != nil {
		t.Fatalf("seed the spawner's open child: %v", err)
	}
	for _, gate := range []struct {
		waiter string
		gate   string
	}{{waiterAny, types.WaitsForAnyChildren}, {waiterAll, types.WaitsForAllChildren}} {
		edge, err := types.NewWaitsForDependency(gate.waiter, spawner, gate.gate)
		if err != nil {
			t.Fatalf("build the %s waits-for edge: %v", gate.gate, err)
		}
		if err := fixture.AddDependency(ctx, edge, "seed"); err != nil {
			t.Fatalf("seed the %s waits-for edge %s -> %s: %v", gate.gate, gate.waiter, spawner, err)
		}
	}

	probe := newBlockedStateProbe(ctx, fixture.QueryScalar)
	probe.requireBlockedWithNoDirectBlockerEdges(t, blockedIssue(waiterAny), "the any-children waiter is gated, not edge-blocked")
	probe.requireBlockedWithNoDirectBlockerEdges(t, blockedIssue(waiterAll), "the all-children waiter is gated, not edge-blocked")

	flip := probe.watchFlip(t,
		[]blockedStateRow{blockedIssue(waiterAny)},
		[]blockedStateRow{blockedIssue(waiterAll)})

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: closedChild, DependsOnID: spawner, Type: publicops.DepParentChild}},
	}); err != nil {
		t.Fatalf("add the already-closed child: %v", err)
	}

	flip.requireFlippedTo(t, 0,
		"an already-closed child satisfies an any-children gate, so this ADD must UNBLOCK — the one add a mark-only pass cannot serve")

	// The all-children control is only a control if its own gate is still
	// genuinely unsatisfied, which is the open child nobody touched.
	if status := probe.rawStatus(t, blockedIssue(openChild)); status != string(types.StatusOpen) {
		t.Fatalf("the spawner's open child %s has status %q, want %q: the all-children control depends on it", openChild, status, types.StatusOpen)
	}
}

// RunDependencyEditorRelatesToAddLeavesItsSourceUnblocked pins the term of
// issueops.BlockedStateInvariant's first clause that names the EDGE TYPE: a row
// is blocked when it has a blocks or conditional-blocks edge onto a live
// target, so an edge of any other type onto the same live target leaves the
// stored flag exactly where it was.
//
// IT IS THE TWIN RunDependencyEditorAddMarksItsSourceInTheSameVerb DOES NOT
// HAVE. That case varies the TARGET'S STATUS and holds the type fixed, so
// every zero it observes is attributable to a closed target; nothing in this
// package has ever observed a zero attributable to the type. The add path is
// where the type decides — issueops/dependencies.go reaches
// markDirectBlockingDependencySourceInTx only for the two blocking types, and
// internal/storage/domain/db/dependency.go's Insert carries a hand-mirrored
// copy of that decision — so this is a genuine second vote, on the body whose
// mirror already dropped one clause once (bd-6dnrw.44 item 3).
//
// THE READ IS RAW. The audit-tier ancestor of this case asked GetReadyWork and
// IsBlocked whether the source was blocked; both compute the answer from the
// live edge set, so they answer correctly against a backend that never writes
// the column at all — and is_blocked is derived AND PERSISTED, read straight
// off the row by every ready query. A role answer is not a substitute for the
// column here.
//
// WHAT THE FIXTURE MAKES OBSERVABLE. The non-scheduling sources carry that edge
// AND NOTHING ELSE, asserted by counting their blocks/conditional-blocks edges
// at zero: a source that also had a blocking edge would read 1 for a reason
// this case is not about, and the term it is named for would be invisible —
// the same shape the conditional-blocks case in issue_operations_contract.go
// guards against from the other side. Their target is asserted OPEN, so the
// zero is not the closed-target answer wearing this case's name. And the
// blocking edge in the SAME request is the must-flip term: it proves the
// marking machinery ran in this very transaction, so a zero beside it is a
// decision rather than a body that marked nothing.
//
// Both non-scheduling spellings ride in, because the type lists in the mark
// templates are enumerations of what DOES block and a body that had heard of
// one and not the other is exactly the drift a single-type case misses.
func RunDependencyEditorRelatesToAddLeavesItsSourceUnblocked(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	target := fixture.IssuePrefix + "-bsrel-target"
	relatesTo := fixture.IssuePrefix + "-bsrel-relatesto"
	related := fixture.IssuePrefix + "-bsrel-related"
	mustFlip := fixture.IssuePrefix + "-bsrel-blocks"
	control := fixture.IssuePrefix + "-bsrel-control"
	for _, id := range []string{target, relatesTo, related, mustFlip, control} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	probe := newBlockedStateProbe(ctx, fixture.QueryScalar)
	flip := probe.watchFlip(t,
		[]blockedStateRow{blockedIssue(mustFlip)},
		[]blockedStateRow{blockedIssue(relatesTo), blockedIssue(related), blockedIssue(control)})

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: relatesTo, DependsOnID: target, Type: types.DepRelatesTo},
			{IssueID: related, DependsOnID: target, Type: publicops.DepRelated},
			{IssueID: mustFlip, DependsOnID: target, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("AddDependencies for the non-scheduling add case: %v", err)
	}

	flip.requireFlippedTo(t, 1,
		"the blocking edge in the same request is the must-flip term: without it a zero on the others could be a body that marks nothing")
	probe.requireBlockedByOpenBlocker(t, blockedIssue(mustFlip), blockedIssue(target),
		"the postcondition is the flag AND the live blocker behind it")

	// The zeros are only worth anything if the edges landed, the sources carry
	// no blocking edge of their own, and the shared target is live.
	for _, edge := range []struct {
		source  string
		depType publicops.DependencyType
	}{
		{relatesTo, types.DepRelatesTo},
		{related, publicops.DepRelated},
	} {
		assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", edge.source, target, string(edge.depType), 1)
		if got := probe.directBlockerEdges(t, blockedIssue(edge.source)); got != 0 {
			t.Fatalf("%s carries %d blocking edges of its own, want 0: a %s source that is also blocked cannot show that %s does not block",
				edge.source, got, edge.depType, edge.depType)
		}
	}
	if status := probe.rawStatus(t, blockedIssue(target)); status != string(types.StatusOpen) {
		t.Fatalf("the shared target %s has status %q, want %q: onto a closed target every type answers zero and this case would mean nothing",
			target, status, types.StatusOpen)
	}
}

// RunDependencyEditorAcceptsADiamond pins the half of the add-time cycle gate
// that says YES. Every other cycle case in this file asserts a refusal, so a
// gate that refused any target it could reach by more than one path — the
// difference between a reachability test and a visited-node count — passes all
// of them, and the shape it would refuse is the ordinary one: two pieces of
// work that both have to land before a third can start.
//
// THE TWO CONVERGING EDGES LAND IN ONE REQUEST, which is the arm that matters:
// the gate checks each edge against the graph INCLUDING the edges the same
// request has already applied, so the second edge is probed against a graph
// that already reaches the same node by another route. Adding them one at a
// time — what the audit-tier ancestor of this case did — never puts a second
// path in front of the probe at all.
//
// THE REFUSAL IS ON THE SAME GRAPH. A body that answered "no cycle" to
// everything would pass the acceptance half alone, so the case closes the
// diamond back onto its own root and requires ErrDependencyCycle with nothing
// written. Acceptance and refusal over one fixture is what makes either one
// mean anything.
//
// THE LAST ARM IS THE ONE THAT WALKS THE CONVERGENCE. Both gates search FROM
// the new edge's target, so while the target is the diamond's foot the walk
// finds a sink and never meets a node twice — the acceptance above would
// survive a gate that mistook a second visit for a loop. An edge pointing INTO
// the diamond's head makes the search start at the root and reach the foot down
// both shoulders, so the second visit happens on a graph with no cycle in it,
// and the gate's visited-set (issueops.CycleThroughEdgesInGraph's BFS) is what
// has to tell those apart.
func RunDependencyEditorAcceptsADiamond(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	root := fixture.IssuePrefix + "-diamond-root"
	left := fixture.IssuePrefix + "-diamond-left"
	right := fixture.IssuePrefix + "-diamond-right"
	foot := fixture.IssuePrefix + "-diamond-foot"
	for _, id := range []string{root, left, right, foot} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: root, DependsOnID: left, Type: publicops.DepBlocks},
			{IssueID: root, DependsOnID: right, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("seed the two shoulders of the diamond: %v", err)
	}

	// Both feet in ONE request: the second is probed against a graph in which
	// the request itself has already made foot reachable from root.
	result, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: left, DependsOnID: foot, Type: publicops.DepBlocks},
			{IssueID: right, DependsOnID: foot, Type: publicops.DepBlocks},
		},
	})
	if err != nil {
		t.Fatalf("closing a diamond is not a cycle: AddDependencies = %v, want both edges accepted", err)
	}
	if len(result.Added) != 2 {
		t.Fatalf("Added = %#v, want both converging edges", result.Added)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", left, foot, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", right, foot, string(publicops.DepBlocks), 1)
	assertDependencyEditorOutgoingCount(t, ctx, fixture, "dependencies", root, 2)

	// The same graph, closed: foot reaches root through either shoulder.
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: foot, DependsOnID: root, Type: publicops.DepBlocks}},
	}); !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("closing the diamond back onto its root: error = %v, want ErrDependencyCycle — the accepting half above is only meaningful beside a gate that still fires", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, foot)

	// An edge into the HEAD of the diamond, from an issue the diamond cannot
	// reach. The gate searches from the target, so this is the arm whose search
	// runs down both shoulders and arrives at the foot twice.
	outsider := fixture.IssuePrefix + "-diamond-outsider"
	seedDependencyEditorIssue(t, ctx, fixture, outsider)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: outsider, DependsOnID: root, Type: publicops.DepBlocks}},
	}); err != nil {
		t.Fatalf("gating an outside issue on the head of a diamond: %v — reaching one node by two paths is convergence, not a loop", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", outsider, root, string(publicops.DepBlocks), 1)
}

// RunDependencyEditorGateScopeFollowsTheEdgeType pins which edges the ADD-TIME
// gate walks, from the side that accepts.
//
// cycle_detector_contract.go pins edge-type scope for the REPORT, over a
// raw-seeded graph, and RunDependencyEditorRefusesACycleThroughAParentChildHop
// pins that the gate walks one type the report does not. Neither shows the
// gate DECLINING to walk a type: a mutual pair of non-scheduling edges is not a
// scheduling cycle and has to be accepted, because that is what `bd dep add
// --type relates-to` writes in both directions between two issues that
// reference each other.
//
// The parent-child arm is the same fixture from the other side. A pure
// parent-child two-cycle — an issue that is its own parent's parent — is a
// scheduling cycle with no blocking edge anywhere in it, and is refused. Two
// arms over one shape is what separates "walks the scheduling types" from
// "walks everything" and from "walks blocks only": the first arm fails the
// former, the second fails the latter.
func RunDependencyEditorGateScopeFollowsTheEdgeType(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	relatedA := fixture.IssuePrefix + "-gscope-rel-a"
	relatedB := fixture.IssuePrefix + "-gscope-rel-b"
	parent := fixture.IssuePrefix + "-gscope-pc-parent"
	child := fixture.IssuePrefix + "-gscope-pc-child"
	for _, id := range []string{relatedA, relatedB, parent, child} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	// Two requests, not one: a mutual pair written in a single request could be
	// collapsed or reordered, and the claim is about the SECOND edge meeting a
	// stored first one.
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: relatedA, DependsOnID: relatedB, Type: types.DepRelatesTo}},
	}); err != nil {
		t.Fatalf("seed the first half of the mutual non-scheduling pair: %v", err)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: relatedB, DependsOnID: relatedA, Type: types.DepRelatesTo}},
	}); err != nil {
		t.Fatalf("closing a mutual %s pair is not a scheduling cycle: AddDependencies = %v, want it accepted", types.DepRelatesTo, err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", relatedA, relatedB, string(types.DepRelatesTo), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", relatedB, relatedA, string(types.DepRelatesTo), 1)

	// The other side of the same shape: parent-child IS in the walk, so its own
	// two-cycle is refused even with no blocking edge anywhere in the graph.
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild}},
	}); err != nil {
		t.Fatalf("seed the hierarchy edge: %v", err)
	}
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: parent, DependsOnID: child, Type: publicops.DepParentChild}},
	}); !errors.Is(err, publicops.ErrDependencyCycle) {
		t.Fatalf("reversing a parent-child edge: error = %v, want ErrDependencyCycle — parent-child is inside the gate's walk", err)
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, parent)
}

// RunDependencyEditorAcceptsBlockingAcrossIssueTypes pins bd-wg7ve: the
// blocking-hierarchy guard is about an issue's HIERARCHY LINE, never about its
// issue TYPE. An epic may be gated on a task it does not contain, and a task on
// an epic it does not belong to.
//
// EVERY OTHER SEED IN THIS FILE IS A TASK. That is what makes the rule
// unobservable here today: a guard rewritten to refuse "a blocking edge between
// an epic and a task" — the plausible misreading of the ancestor/descendant
// refusal, and one a reviewer would wave through — passes the whole contract,
// because no two seeds anywhere in it have different types.
//
// THE REFUSAL ARM USES THE SAME TWO TYPES. Its epic and task are a real parent
// and child, so the pair differs from the accepting arm in the hierarchy
// relationship and in nothing else, and the two together say the guard reads
// the edge and not the row: a body that refused on type fails the acceptance, a
// body that dropped the ancestry walk fails the refusal, and neither can be
// made to pass by weakening the other.
func RunDependencyEditorAcceptsBlockingAcrossIssueTypes(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	epic := fixture.IssuePrefix + "-xtype-epic"
	task := fixture.IssuePrefix + "-xtype-task"
	other := fixture.IssuePrefix + "-xtype-othertask"
	seedDependencyEditorIssueOfType(t, ctx, fixture, epic, types.TypeEpic)
	seedDependencyEditorIssueOfType(t, ctx, fixture, task, types.TypeTask)
	seedDependencyEditorIssueOfType(t, ctx, fixture, other, types.TypeTask)

	// Both directions across the type boundary, between issues with no
	// hierarchy relationship at all.
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: epic, DependsOnID: task, Type: publicops.DepBlocks},
			{IssueID: other, DependsOnID: epic, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("gating an epic on an unrelated task and a task on an unrelated epic: %v — the guard is about the hierarchy line, not the type", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", epic, task, string(publicops.DepBlocks), 1)
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", other, epic, string(publicops.DepBlocks), 1)
	assertDependencyEditorIssueType(t, ctx, fixture, epic, types.TypeEpic)
	assertDependencyEditorIssueType(t, ctx, fixture, task, types.TypeTask)

	// The same two types, now a real parent and child: refused.
	hierEpic := fixture.IssuePrefix + "-xtype-hier-epic"
	hierTask := fixture.IssuePrefix + "-xtype-hier-task"
	seedDependencyEditorIssueOfType(t, ctx, fixture, hierEpic, types.TypeEpic)
	seedDependencyEditorIssueOfType(t, ctx, fixture, hierTask, types.TypeTask)
	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: hierTask, DependsOnID: hierEpic, Type: publicops.DepParentChild}},
	}); err != nil {
		t.Fatalf("seed the epic/task hierarchy: %v", err)
	}
	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: hierTask, DependsOnID: hierEpic, Type: publicops.DepBlocks}},
	})
	var conflict *publicops.DependencyHierarchyConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("gating a task on the epic it belongs to: error = %v, want *DependencyHierarchyConflictError", err)
	}
	if !conflict.BlockerIsAncestor {
		t.Errorf("conflict = %#v, want BlockerIsAncestor true", conflict)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", hierTask, hierEpic, string(publicops.DepBlocks), 0)
}

func seedDependencyEditorIssue(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string) {
	t.Helper()
	if err := fixture.CreateIssue(ctx, dependencyEditorSeed(id, false), "seed"); err != nil {
		t.Fatalf("seed issue %s: %v", id, err)
	}
}

// seedDependencyEditorIssueOfType seeds a durable issue carrying an ISSUE TYPE
// other than the file's default task. Only the cross-type case needs one, and
// it asserts the type landed rather than trusting the seed: a create that
// normalized the type away would leave that case comparing two tasks and
// quietly testing nothing.
func seedDependencyEditorIssueOfType(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string, issueType types.IssueType) {
	t.Helper()
	seed := dependencyEditorSeed(id, false)
	seed.IssueType = issueType
	if err := fixture.CreateIssue(ctx, seed, "seed"); err != nil {
		t.Fatalf("seed issue %s of type %q: %v", id, issueType, err)
	}
}

// seedDependencyEditorIssueAtStatus seeds a durable issue that is already in a
// terminal status. It seeds a STATUS, never the is_blocked column: no fixture
// in this package can write that flag, so every value a case reads was earned
// by a role verb.
func seedDependencyEditorIssueAtStatus(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string, status types.Status) {
	t.Helper()
	seed := dependencyEditorSeed(id, false)
	seed.Status = status
	if err := fixture.CreateIssue(ctx, seed, "seed"); err != nil {
		t.Fatalf("seed issue %s at status %q: %v", id, status, err)
	}
}

func seedDependencyEditorWisp(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string) {
	t.Helper()
	if err := fixture.CreateWisp(ctx, dependencyEditorSeed(id, true), "seed"); err != nil {
		t.Fatalf("seed wisp %s: %v", id, err)
	}
}

func dependencyEditorSeed(id string, ephemeral bool) *types.Issue {
	return &types.Issue{
		ID:        id,
		Title:     id,
		Status:    types.StatusOpen,
		Priority:  2,
		IssueType: types.TypeTask,
		Ephemeral: ephemeral,
	}
}

// assertDependencyEdgeCount counts edges from source to target in one
// dependency table. The target is matched through the resolved target
// expression because a target's own class decides which typed column holds it,
// independently of the source routing under test.
func assertDependencyEdgeCount(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, table, source, target string, want int) {
	t.Helper()
	var got int
	//nolint:gosec // G201: table is one of the contract's two hardcoded names.
	query := "SELECT COUNT(*) FROM " + table +
		" WHERE issue_id = ? AND COALESCE(depends_on_issue_id, depends_on_wisp_id, depends_on_external) = ?"
	if err := fixture.QueryScalar(ctx, query, []any{source, target}, &got); err != nil {
		t.Fatalf("count %s edges %s -> %s: %v", table, source, target, err)
	}
	if got != want {
		t.Errorf("%s edges %s -> %s = %d, want %d", table, source, target, got, want)
	}
}

func assertDependencyEdgeTypedCount(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, table, source, target, depType string, want int) {
	t.Helper()
	var got int
	//nolint:gosec // G201: table is one of the contract's two hardcoded names.
	query := "SELECT COUNT(*) FROM " + table +
		" WHERE issue_id = ? AND COALESCE(depends_on_issue_id, depends_on_wisp_id, depends_on_external) = ? AND type = ?"
	if err := fixture.QueryScalar(ctx, query, []any{source, target, depType}, &got); err != nil {
		t.Fatalf("count %s %s edges %s -> %s: %v", table, depType, source, target, err)
	}
	if got != want {
		t.Errorf("%s %s edges %s -> %s = %d, want %d", table, depType, source, target, got, want)
	}
}

// assertDependencyEditorTargetColumn checks WHICH typed target column holds an
// edge's target, which assertDependencyEdgeCount's COALESCE deliberately cannot
// see. It asserts the whole triple rather than the wanted column alone: a body
// that wrote the id into two columns would satisfy the positive check and still
// hold a row no reader can classify.
func assertDependencyEditorTargetColumn(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, table, source, target, wantColumn, why string) {
	t.Helper()
	for _, column := range []string{"depends_on_issue_id", "depends_on_wisp_id", "depends_on_external"} {
		want := 0
		if column == wantColumn {
			want = 1
		}
		var got int
		//nolint:gosec // G201: table is one of the contract's two hardcoded names, column one of the three above.
		query := "SELECT COUNT(*) FROM " + table + " WHERE issue_id = ? AND " + column + " = ?"
		if err := fixture.QueryScalar(ctx, query, []any{source, target}, &got); err != nil {
			t.Fatalf("count %s.%s rows %s -> %s: %v", table, column, source, target, err)
		}
		if got != want {
			t.Errorf("%s.%s rows %s -> %s = %d, want %d: the target belongs in %s — %s",
				table, column, source, target, got, want, wantColumn, why)
		}
	}
}

// assertDependencyEditorIssueType reads the stored issue_type of a durable row.
// The cross-type case is the only caller: its whole claim is that two rows have
// DIFFERENT types, and a seed whose type never landed would leave it comparing
// two of the file's default tasks and asserting nothing.
func assertDependencyEditorIssueType(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, id string, want types.IssueType) {
	t.Helper()
	var got string
	if err := fixture.QueryScalar(ctx, "SELECT issue_type FROM issues WHERE id = ?", []any{id}, &got); err != nil {
		t.Fatalf("read the issue_type of %s: %v", id, err)
	}
	if got != string(want) {
		t.Fatalf("%s has issue_type %q, want %q: this case is about two rows of different types and the seed did not produce them", id, got, want)
	}
}

// assertDependencyEditorEventCount counts events of one type for one issue.
// Both event types the role writes go through it — the add cases read
// dependency_added, the removal cases dependency_removed — because the two
// differ only in that argument, and a second helper pinned to one of them was
// a copy waiting to drift.
func assertDependencyEditorEventCount(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, table, issueID string, eventType types.EventType, want int) {
	t.Helper()
	var got int
	//nolint:gosec // G201: table is one of the contract's two hardcoded names.
	query := "SELECT COUNT(*) FROM " + table + " WHERE issue_id = ? AND event_type = ?"
	if err := fixture.QueryScalar(ctx, query, []any{issueID, string(eventType)}, &got); err != nil {
		t.Fatalf("count %s %s rows for %s: %v", table, eventType, issueID, err)
	}
	if got != want {
		t.Errorf("%s %s rows for %s = %d, want %d", table, eventType, issueID, got, want)
	}
}

// assertDependencyEditorJournalCountIsOne asserts exactly one bd_events_journal
// row exists for one issue and op — the same shape as
// assertDependencyEditorEventCount, against the table that has no
// deduplication of its own and so is the one an unconditional journal write on
// a no-op would actually show up in. Every call site pins the count at one
// (the single genuine write); there is no idempotency case that expects zero
// or more than one, so unlike assertDependencyEditorEventCount this does not
// take a want.
func assertDependencyEditorJournalCountIsOne(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, issueID, op string) {
	t.Helper()
	var got int
	query := "SELECT COUNT(*) FROM bd_events_journal WHERE issue_id = ? AND op = ?"
	if err := fixture.QueryScalar(ctx, query, []any{issueID, op}, &got); err != nil {
		t.Fatalf("count bd_events_journal %s rows for %s: %v", op, issueID, err)
	}
	if got != 1 {
		t.Errorf("bd_events_journal %s rows for %s = %d, want 1", op, issueID, got)
	}
}

// assertDependencyEditorEventActor reads the actor off the one event of a
// given type for one issue. It reads the DURABLE stream only: the attribution
// clause is about who is recorded, and the plane that record lands in is
// already pinned by the routing cases.
func assertDependencyEditorEventActor(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, issueID string, eventType types.EventType, want string) {
	t.Helper()
	var got string
	if err := fixture.QueryScalar(ctx,
		"SELECT COALESCE(actor, '') FROM events WHERE issue_id = ? AND event_type = ?",
		[]any{issueID, string(eventType)}, &got); err != nil {
		t.Fatalf("read the %s actor for %s: %v", eventType, issueID, err)
	}
	if got != want {
		t.Errorf("%s actor for %s = %q, want %q: the entry is attributed to the request's Actor", eventType, issueID, got, want)
	}
}

// assertDependencyEditorOutgoingCount counts ALL outgoing edges from one source
// in one table. Paired with assertDependencyEdgeTypedCount it pins a whole
// neighbor set: the typed count says the right edge is there, this one says
// nothing else is.
func assertDependencyEditorOutgoingCount(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, table, source string, want int) {
	t.Helper()
	var got int
	//nolint:gosec // G201: table is one of the contract's two hardcoded names.
	query := "SELECT COUNT(*) FROM " + table + " WHERE issue_id = ?"
	if err := fixture.QueryScalar(ctx, query, []any{source}, &got); err != nil {
		t.Fatalf("count %s edges from %s: %v", table, source, err)
	}
	if got != want {
		t.Errorf("%s edges from %s = %d, want %d", table, source, got, want)
	}
}

// assertDependencyEditorNoEdgesFrom is how a refusal case spells "the request
// is all-or-nothing". It counts BOTH planes for each source, because a refused
// request that left an ephemeral edge behind is exactly the partial commit the
// all-or-nothing rule exists to prevent.
func assertDependencyEditorNoEdgesFrom(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, sources ...string) {
	t.Helper()
	for _, source := range sources {
		for _, table := range []string{"dependencies", "wisp_dependencies"} {
			assertDependencyEditorOutgoingCount(t, ctx, fixture, table, source, 0)
		}
	}
}

func dependencyEditorHistoryCount(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) int {
	t.Helper()
	entries, err := fixture.CountHistory(ctx)
	if err != nil {
		t.Fatalf("CountHistory: %v", err)
	}
	return entries
}

func assertDependencyEditorHistoryDelta(t *testing.T, ctx context.Context, fixture DependencyEditorFixture, before, want int, why string) {
	t.Helper()
	after := dependencyEditorHistoryCount(t, ctx, fixture)
	if after-before != want {
		t.Errorf("history entries went %d -> %d (delta %d), want a delta of %d: %s", before, after, after-before, want, why)
	}
}

// dependencyEditorHistoryProbe takes the history count now and returns the
// assertion for the delta since. It is for cases whose SUBJECT is something
// else and whose history count is one assertion among several: those must keep
// running on a fixture that cannot observe history rather than skip whole, the
// way the two cases about history itself correctly do.
func dependencyEditorHistoryProbe(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) func(want int, why string) {
	t.Helper()
	if fixture.CountHistory == nil {
		return func(int, string) {
			t.Log("fixture.CountHistory is nil: this backend cannot observe history, so only the history half of this case is unchecked")
		}
	}
	before := dependencyEditorHistoryCount(t, ctx, fixture)
	return func(want int, why string) {
		t.Helper()
		assertDependencyEditorHistoryDelta(t, ctx, fixture, before, want, why)
	}
}

// RunDependencyEditorRefusesADottedChildGatedOnItsOwnParent pins
// publicops.CheckDottedChildDependency on the role: an explicit edge from a
// dotted-id child to its own ancestor is refused as a
// *DottedChildDependencyError (ErrValidation) on every leg, and nothing is
// written. (It is decided before any per-edge probe, so the probe-skipped
// spelling, which the wire does not publish, adds nothing here.) It used to be
// enforced only by the CLI ahead of the role, so an HTTP or embedded caller
// could gate bd-abc.1 on bd-abc.
//
// POSITIVE HALF: the hierarchy itself — a parent-child edge to the IMMEDIATE
// dotted parent — is allowed, and so is an edge between siblings. A body that
// refused every edge touching a dotted id would satisfy the refusals alone.
//
// WITH THE HIERARCHY STORED: once that parent-child edge exists (the shape
// `bd create --parent` leaves), a blocking edge on the same pair is still this
// refusal, not the type or hierarchy conflict the stored edge would raise — the
// rule reads nothing, so it answers first — and the stored edge survives.
func RunDependencyEditorRefusesADottedChildGatedOnItsOwnParent(t *testing.T, ctx context.Context, fixture DependencyEditorFixture) {
	t.Helper()
	parent := fixture.IssuePrefix + "-dotted"
	child := parent + ".1"
	grandchild := child + ".2"
	sibling := parent + ".3"
	for _, id := range []string{parent, child, grandchild, sibling} {
		seedDependencyEditorIssue(t, ctx, fixture, id)
	}

	for _, refused := range []struct {
		name string
		edge publicops.DependencyEdge
	}{
		{"child blocks on its parent", publicops.DependencyEdge{IssueID: child, DependsOnID: parent, Type: publicops.DepBlocks}},
		{"grandchild blocks on its grandparent", publicops.DependencyEdge{IssueID: grandchild, DependsOnID: parent, Type: publicops.DepBlocks}},
		{"grandchild parent-child to its grandparent", publicops.DependencyEdge{IssueID: grandchild, DependsOnID: parent, Type: publicops.DepParentChild}},
		{"child relates to its parent", publicops.DependencyEdge{IssueID: child, DependsOnID: parent, Type: publicops.DepRelated}},
	} {
		_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
			Actor: "writer",
			Edges: []publicops.DependencyEdge{refused.edge},
		})
		var dotted *publicops.DottedChildDependencyError
		if !errors.As(err, &dotted) {
			t.Errorf("%s: error = %v, want *DottedChildDependencyError", refused.name, err)
			continue
		}
		if !errors.Is(err, publicops.ErrValidation) {
			t.Errorf("%s: error = %v, want it to match ErrValidation", refused.name, err)
		}
		if dotted.IssueID != refused.edge.IssueID || dotted.DependsOnID != refused.edge.DependsOnID {
			t.Errorf("%s: refusal names %s -> %s, want %s -> %s", refused.name,
				dotted.IssueID, dotted.DependsOnID, refused.edge.IssueID, refused.edge.DependsOnID)
		}
	}
	assertDependencyEditorNoEdgesFrom(t, ctx, fixture, child, grandchild)

	if _, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{
			{IssueID: grandchild, DependsOnID: child, Type: publicops.DepParentChild},
			{IssueID: sibling, DependsOnID: child, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("the immediate parent-child edge and a sibling edge: %v", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", grandchild, child, string(publicops.DepParentChild), 1)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", sibling, child, 1)

	_, err := fixture.Editor.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "writer",
		Edges: []publicops.DependencyEdge{{IssueID: grandchild, DependsOnID: child, Type: publicops.DepBlocks}},
	})
	var dotted *publicops.DottedChildDependencyError
	if !errors.As(err, &dotted) || !errors.Is(err, publicops.ErrValidation) {
		t.Errorf("blocks on a parent whose parent-child edge is stored: error = %v, want *DottedChildDependencyError matching ErrValidation", err)
	}
	assertDependencyEdgeTypedCount(t, ctx, fixture, "dependencies", grandchild, child, string(publicops.DepParentChild), 1)
	assertDependencyEdgeCount(t, ctx, fixture, "dependencies", grandchild, child, 1)
}
