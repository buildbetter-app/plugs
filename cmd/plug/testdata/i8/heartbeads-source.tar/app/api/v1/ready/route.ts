/**
 * GET /api/v1/ready — Actionable issues for AI agents.
 *
 * Returns the native category/workflow-eligible bead.ready membership
 * for the complete project snapshot. Sorted by priority (critical first).
 * No auth required.
 *
 * Query params:
 *   ?unclaimed=true      Only unclaimed issues
 *   ?type=bug,feature    Filter by issue type (comma-separated)
 *   ?assignee=handle     Filter by assignee
 *   ?prefix=beads-map    Filter by repo prefix
 *   ?limit=20            Max issues returned (default: all)
 */

import { loadBeadsData } from "@/lib/parse-beads";
import { fetchBeadsComments, getClaimedNodes, boundComments } from "@/lib/comments";
import type { BeadsComment, ClaimInfo } from "@/lib/comments";
import type { GraphNode } from "@/lib/types";
import { jsonResponse, errorResponse, OPTIONS } from "@/lib/api-helpers";
import { readFileSync } from "fs";
import { join } from "path";

export const dynamic = "force-dynamic";
export { OPTIONS };

let heartbeadsVersion = "0.0.0";
try {
  const pkg = JSON.parse(
    readFileSync(join(process.cwd(), "package.json"), "utf-8")
  );
  heartbeadsVersion = pkg.version || heartbeadsVersion;
} catch {
  // ignore
}

function graphKey(node: GraphNode): string {
  return node.graphKey || `${node.project || ""}\u0000${node.id}`;
}

function serializeComment(c: BeadsComment): Record<string, unknown> {
  return {
    author: {
      handle: c.handle,
      did: c.did,
      ...(c.displayName ? { displayName: c.displayName } : {}),
    },
    text: c.text,
    createdAt: c.createdAt,
    likes: c.likes.length,
    replies: c.replies.map(serializeComment),
  };
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const params = url.searchParams;

    // Parse query params
    const unclaimedOnly = params.get("unclaimed") === "true";
    const typeFilter = params.get("type")?.split(",").filter(Boolean);
    const assigneeFilter = params.get("assignee") || null;
    const prefixFilter = params.get("prefix") || null;
    const projectFilter = params.get("project") || null;
    const limitParam = params.get("limit");
    const limit = limitParam ? Math.max(parseInt(limitParam) || 0, 1) : null;

    // Load beads data + comments in parallel
    const [beadsData, commentsResult] = await Promise.all([
      loadBeadsData(),
      fetchBeadsComments().catch((err) => {
        console.error("[api/v1/ready] Failed to fetch comments:", err);
        return null;
      }),
    ]);

    const claims = commentsResult
      ? getClaimedNodes(boundComments(commentsResult.allComments, beadsData.graphData.nodes), (comment) => `${comment.project || ""}\u0000${comment.nodeId}`)
      : new Map<string, ClaimInfo>();

    // The adapter reads native bead.ready pages and verifies their asOf
    // against the complete project view. Workflow/type/lease guards stay in
    // Plug; hierarchy is never reinterpreted as a blocking prerequisite here.
    let readyIssues = beadsData.graphData.nodes.filter((node) =>
      node.ready && (!projectFilter || node.project === projectFilter)
    );

    // Apply filters
    if (typeFilter) {
      readyIssues = readyIssues.filter((n) =>
        typeFilter.includes(n.issueType)
      );
    }
    if (assigneeFilter) {
      readyIssues = readyIssues.filter(
        (n) => n.assignee === assigneeFilter
      );
    }
    if (prefixFilter) {
      readyIssues = readyIssues.filter((n) => n.prefix === prefixFilter);
    }
    if (unclaimedOnly) {
      readyIssues = readyIssues.filter((n) => !claims.has(`${n.project || ""}\u0000${n.id}`));
    }

    // Sort by priority ascending (0=critical first), then created_at ascending (oldest first)
    readyIssues.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return (
        new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
    });

    // Apply limit
    if (limit) {
      readyIssues = readyIssues.slice(0, limit);
    }

    // Enrich issues
    const enrichedIssues = readyIssues.map((node) => {
      const nodeComments = (commentsResult?.commentsByNode.get(node.id) || []).filter((comment) => comment.project === node.project || (!comment.project && beadsData.graphData.nodes.filter((n) => n.id === node.id).length === 1));
      const claim = claims.get(`${node.project || ""}\u0000${node.id}`) || null;

      return {
        id: node.id,
        legacy_id: node.legacyId || node.id,
        canonical_id: node.canonicalId || null,
        project: node.project || null,
        title: node.title,
        description: node.description || null,
        status: node.status,
        status_category: node.statusCategory,
        priority: node.priority,
        issue_type: node.issueType,
        owner: node.owner || null,
        assignee: node.assignee || null,
        labels: node.labels,
        created_at: node.createdAt,
        updated_at: node.updatedAt,
        prefix: node.prefix,
        blockers: node.dependentIds,   // issues that block this one (upstream)
        dependents: node.blockerIds,   // issues this one blocks (downstream)
        comments: nodeComments.map(serializeComment),
        claimed_by: claim
          ? {
              handle: claim.handle,
              did: claim.did,
              ...(claim.displayName
                ? { displayName: claim.displayName }
                : {}),
              claimed_at: claim.claimedAt,
            }
          : null,
      };
    });

    // Build summary stats
    const byPriority: Record<string, number> = {};
    const byType: Record<string, number> = {};
    let unclaimed = 0;
    for (const issue of readyIssues) {
      const p = String(issue.priority);
      byPriority[p] = (byPriority[p] || 0) + 1;
      byType[issue.issueType] = (byType[issue.issueType] || 0) + 1;
      if (!claims.has(`${issue.project || ""}\u0000${issue.id}`)) unclaimed++;
    }

    const warnings: string[] = [];
    if (!commentsResult) {
      warnings.push("Failed to fetch comments from indexer");
    }

    return jsonResponse({
      issues: enrichedIssues,
      stats: {
        total_ready: enrichedIssues.length,
        unclaimed,
        by_priority: byPriority,
        by_type: byType,
      },
      _meta: {
        generated_at: new Date().toISOString(),
        api_version: "v1" as const,
        heartbeads_version: heartbeadsVersion,
        freshness: beadsData.freshness,
        ...(warnings.length ? { warnings } : {}),
      },
    });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : "Unknown error";
    if (message.includes("HEARTBEADS_BINDING") || message.startsWith("--binding") || message.startsWith("unable to read binding") || message.startsWith("binding.")) {
      return errorResponse(
        "No Plug binding found",
        404,
        "Pass --binding /absolute/path/host-binding.json to heartbeads."
      );
    }
    console.error("[api/v1/ready] Error:", error);
    return errorResponse("Internal server error", 500);
  }
}
