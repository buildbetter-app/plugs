import { NextRequest, NextResponse } from "next/server";
import { getAuthenticatedAgent } from "@/lib/agent";
import { getSession } from "@/lib/session";
import { loadProjection } from "@/lib/plug-adapter.mjs";
import type { GraphNode } from "@/lib/types";

export const dynamic = "force-dynamic";

/** Only these ATProto collections are allowed through /api/records. */
const ALLOWED_COLLECTIONS = new Set([
  "org.impactindexer.review.comment",
  "org.impactindexer.review.like",
]);

const PROJECTS = new Set(["cody-ops", "signals-v2"]);

async function requireBoundNode(project: unknown, nodeId: unknown) {
  if (typeof project !== "string" || !PROJECTS.has(project)) {
    throw new Error("A bound project is required");
  }
  if (typeof nodeId !== "string" || nodeId.length === 0) {
    throw new Error("A bound node id is required");
  }
  const data = await loadProjection() as { graphData: { nodes: GraphNode[] } };
  const matches = data.graphData.nodes.filter((node) => node.project === project && node.id === nodeId);
  if (matches.length !== 1) throw new Error("Record subject is not in the selected Plug project");
  return matches[0];
}

function subjectNodeId(record: Record<string, unknown>): string | null {
  const subject = record.subject;
  if (!subject || typeof subject !== "object" || Array.isArray(subject)) return null;
  const uri = (subject as Record<string, unknown>).uri;
  return typeof uri === "string" && uri.startsWith("beads:") ? uri.slice("beads:".length) : null;
}

async function requireExistingSubject(agent: Awaited<ReturnType<typeof getAuthenticatedAgent>>, repo: string, collection: string, rkey: string, project: unknown, nodeId: unknown) {
  if (!agent) throw new Error("Unauthorized");
  const existing = await agent.com.atproto.repo.getRecord({ repo, collection, rkey });
  const value = existing.data.value as Record<string, unknown>;
  const existingNode = subjectNodeId(value) || value.nodeId;
  if (value.project !== project || existingNode !== nodeId) {
    throw new Error("Existing record subject does not match the selected Plug project and node");
  }
}

/**
 * POST /api/records — Create a new record
 * Body: { collection, rkey?, record }
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { collection, rkey, record, project } = body;

    if (!collection || typeof collection !== "string") {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!record || typeof record !== "object") {
      return NextResponse.json(
        { error: "Record is required" },
        { status: 400 }
      );
    }
    const nodeId = subjectNodeId(record as Record<string, unknown>) || body.nodeId;
    await requireBoundNode(project, nodeId);

    const res = await agent.com.atproto.repo.createRecord({
      repo: session.did,
      collection,
      rkey: rkey || undefined,
      record: { ...record, project, nodeId },
    });

    return NextResponse.json({
      success: true,
      uri: res.data.uri,
      cid: res.data.cid,
    });
  } catch (error) {
    console.error("Failed to create record:", error);
    return NextResponse.json(
      { error: "Failed to create record" },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/records — Update an existing record
 * Body: { collection, rkey, record }
 */
export async function PUT(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { collection, rkey, record, project } = body;

    if (!collection || typeof collection !== "string") {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!rkey || typeof rkey !== "string") {
      return NextResponse.json(
        { error: "Record key is required" },
        { status: 400 }
      );
    }
    if (!record || typeof record !== "object") {
      return NextResponse.json(
        { error: "Record is required" },
        { status: 400 }
      );
    }
    const nodeId = subjectNodeId(record as Record<string, unknown>) || body.nodeId;
    await requireBoundNode(project, nodeId);
    await requireExistingSubject(agent, session.did, collection, rkey, project, nodeId);

    await agent.com.atproto.repo.putRecord({
      repo: session.did,
      collection,
      rkey,
      record: { ...record, project, nodeId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to update record:", error);
    return NextResponse.json(
      { error: "Failed to update record" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/records?collection=...&rkey=...
 * Deletes a record from the authenticated user's repo.
 */
export async function DELETE(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const collection = searchParams.get("collection");
    const rkey = searchParams.get("rkey");
    const project = searchParams.get("project");
    const nodeId = searchParams.get("nodeId");
    const requestedDid = searchParams.get("did");

    if (!collection) {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!rkey) {
      return NextResponse.json(
        { error: "Record key is required" },
        { status: 400 }
      );
    }
    if (requestedDid && requestedDid !== session.did) {
      return NextResponse.json({ error: "Record identity does not match the session" }, { status: 403 });
    }
    await requireBoundNode(project, nodeId);
    await requireExistingSubject(agent, session.did, collection, rkey, project, nodeId);

    await agent.com.atproto.repo.deleteRecord({
      repo: session.did,
      collection,
      rkey,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete record:", error);
    return NextResponse.json(
      { error: "Failed to delete record" },
      { status: 500 }
    );
  }
}
