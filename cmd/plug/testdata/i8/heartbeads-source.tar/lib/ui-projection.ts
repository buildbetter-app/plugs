import type { BeadsApiResponse, GraphNode } from "./types";
import type { BeadsComment } from "./comments";
import { nodeKey } from "./diff-beads";

// Canvas, selection, URL, activity and comment joins share one UI-only key.
// HTTP projections and record subjects keep the original public identifier.
export function uiProjection(snapshot: BeadsApiResponse): BeadsApiResponse {
  return {
    ...snapshot,
    graphData: {
      nodes: snapshot.graphData.nodes.map((node) => ({
        ...node,
        id: nodeKey(node),
        legacyId: node.legacyId ?? node.id,
        blockerIds: node.blockerKeys ?? [],
        dependentIds: node.dependentKeys ?? [],
        childIds: node.childKeys ?? [],
        parentId: node.parentKey,
      })),
      links: snapshot.graphData.links.map((link) => ({
        ...link,
        source: link.sourceKey ?? link.source,
        target: link.targetKey ?? link.target,
      })),
    },
  };
}

export function uiComments(comments: BeadsComment[], nodes: GraphNode[]): BeadsComment[] {
  const qualify = (comment: BeadsComment): BeadsComment | null => {
    const matches = nodes.filter((node) => (node.legacyId ?? node.id) === comment.nodeId &&
      (!comment.project || node.project === comment.project));
    if (matches.length !== 1) return null;
    return {
      ...comment,
      nodeId: matches[0].id,
      project: matches[0].project,
      replies: comment.replies.map(qualify).filter((reply): reply is BeadsComment => reply !== null),
    };
  };
  return comments.map(qualify).filter((comment): comment is BeadsComment => comment !== null);
}
