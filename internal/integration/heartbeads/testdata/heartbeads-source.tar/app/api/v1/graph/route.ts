/**
 * GET /api/v1/graph — Full project snapshot for AI agents.
 *
 * Returns the entire beads graph with issues, dependencies, comments,
 * claims, and activity in a single JSON response. No auth required.
 *
 * Query params:
 *   ?status=open,in_progress   Filter issues by status (comma-separated)
 *   ?priority=0,1              Filter by priority (comma-separated)
 *   ?prefix=beads-map          Filter by repo prefix
 *   ?include=comments,activity Opt-in fields (default: all)
 *   ?limit=50                  Activity feed cap (default 50, max 200)
 */

import { loadBeadsData } from "@/lib/parse-beads";
import { fetchBeadsComments, getClaimedNodes, boundComments, threadComments } from "@/lib/comments";
import type { BeadsComment, ClaimInfo } from "@/lib/comments";
import { buildHistoricalFeed } from "@/lib/activity";
import type { GraphNode } from "@/lib/types";
import { jsonResponse, errorResponse, OPTIONS } from "@/lib/api-helpers";
import { readFileSync } from "fs";
import { join } from "path";

export const dynamic = "force-dynamic";
export { OPTIONS };

// Read version from package.json at module load time
let heartbeadsVersion = "0.0.0";
try {
  const pkg = JSON.parse(
    readFileSync(join(process.cwd(), "package.json"), "utf-8")
  );
  heartbeadsVersion = pkg.version || heartbeadsVersion;
} catch {
  // ignore
}

/** Serialize a BeadsComment tree for API output */
function serializeComment(c: BeadsComment): Record<string, unknown> {
  return {
    author: {
      handle: c.handle,
      did: c.did,
      ...(c.displayName ? { displayName: c.displayName } : {}),
    },
    text: c.text,
    createdAt: c.createdAt,
    likes: c.likes.length,
    replies: c.replies.map(serializeComment),
  };
}

/** Serialize a claim for API output */
function graphKey(node: GraphNode): string {
  return node.graphKey || `${node.project || ""}\u0000${node.id}`;
}

function endpointKey(link: { source: unknown; target: unknown; sourceKey?: string; targetKey?: string }, side: "source" | "target"): string {
  const explicit = side === "source" ? link.sourceKey : link.targetKey;
  if (explicit) return explicit;
  const endpoint = link[side];
  return typeof endpoint === "object" && endpoint ? graphKey(endpoint as GraphNode) : String(endpoint);
}

function serializeClaim(claim: ClaimInfo) {
  return {
    handle: claim.handle,
    did: claim.did,
    ...(claim.displayName ? { displayName: claim.displayName } : {}),
    claimed_at: claim.claimedAt,
  };
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const params = url.searchParams;

    // Parse query params
    const statusFilter = params.get("status")?.split(",").filter(Boolean);
    const priorityFilter = params
      .get("priority")
      ?.split(",")
      .map(Number)
      .filter((n) => !isNaN(n));
    const prefixFilter = params.get("prefix") || null;
    const projectFilter = params.get("project") || null;
    const includeParam = params.get("include");
    const limit = Math.min(
      Math.max(parseInt(params.get("limit") || "50") || 50, 1),
      200
    );

    // Determine what to include (default: everything)
    let includeComments = true;
    let includeActivity = true;
    if (includeParam !== null) {
      const includes = includeParam.split(",").filter(Boolean);
      includeComments = includes.includes("comments");
      includeActivity = includes.includes("activity");
    }

    // Load beads data + config in parallel with optional comments
    const beadsPromise = loadBeadsData();
    const commentsPromise = (includeComments || includeActivity)
      ? fetchBeadsComments().catch((err) => {
          console.error("[api/v1/graph] Failed to fetch comments:", err);
          return null;
        })
      : Promise.resolve(null);

    const [beadsData, commentsResult] = await Promise.all([
      beadsPromise,
      commentsPromise,
    ]);

    if (projectFilter && !beadsData.projects?.[projectFilter]) {
      return errorResponse("Unknown project", 400, "project must be cody-ops or signals-v2.");
    }
    const selectedProjects = projectFilter
      ? { [projectFilter]: beadsData.projects![projectFilter] }
      : (beadsData.projects || {});
    const selectedNodes = projectFilter
      ? beadsData.graphData.nodes.filter((node) => node.project === projectFilter)
      : beadsData.graphData.nodes;
    const selectedNodeKeys = new Set(selectedNodes.map(graphKey));
    const selectedLinks = beadsData.graphData.links.filter((link) => {
      return selectedNodeKeys.has(endpointKey(link, "source")) && selectedNodeKeys.has(endpointKey(link, "target"));
    });
    const repos = Object.keys(selectedProjects);
    const scopedComments = boundComments(commentsResult?.allComments || [], beadsData.graphData.nodes);
    const threads = threadComments(scopedComments);
    const claims = commentsResult
      ? getClaimedNodes(scopedComments, (comment) => `${comment.project || ""}\u0000${comment.nodeId}`)
      : new Map<string, ClaimInfo>();

    // Build maps with the project-qualified internal key. Public IDs remain
    // unchanged in the response and record subjects.
    const nodeMap = new Map<string, GraphNode>(
      beadsData.graphData.nodes.map((n) => [graphKey(n), n])
    );

    // Filter and enrich issues
    let issues = selectedNodes;

    if (statusFilter) {
      issues = issues.filter((n) => statusFilter.includes(n.status));
    }
    if (priorityFilter) {
      issues = issues.filter((n) => priorityFilter.includes(n.priority));
    }
    if (prefixFilter) {
      issues = issues.filter((n) => n.prefix === prefixFilter);
    }
    if (projectFilter) {
      issues = issues.filter((n) => n.project === projectFilter);
    }

    const enrichedIssues = issues.map((node) => {
      const nodeComments = (threads.commentsByNode.get(node.id) || []).filter((comment) => comment.project === node.project);
      const claim = claims.get(`${node.project || ""}\u0000${node.id}`) || null;

      return {
        id: node.id,
        legacy_id: node.legacyId || node.id,
        canonical_id: node.canonicalId || null,
        project: node.project || null,
        title: node.title,
        description: node.description || null,
        status: node.status,
        status_category: node.statusCategory,
        priority: node.priority,
        issue_type: node.issueType,
        owner: node.owner || null,
        assignee: node.assignee || null,
        labels: node.labels,
        created_at: node.createdAt,
        updated_at: node.updatedAt,
        closed_at: node.closedAt || null,
        close_reason: node.closeReason || null,
        prefix: node.prefix,
        blockers: node.dependentIds,   // issues that block this one (upstream)
        dependents: node.blockerIds,   // issues this one blocks (downstream)
        ...(includeComments
          ? { comments: nodeComments.map(serializeComment) }
          : {}),
        claimed_by: claim ? serializeClaim(claim) : null,
      };
    });

    // Build dependencies
    const dependencies = selectedLinks.map((link) => {
      const src = typeof link.source === "object" ? (link.source as { id: string }).id : link.source;
      const tgt = typeof link.target === "object" ? (link.target as { id: string }).id : link.target;
      const sourceNode = nodeMap.get(endpointKey(link, "source"));
      const targetNode = nodeMap.get(endpointKey(link, "target"));
      return { from: src, to: tgt, type: link.type, project: sourceNode?.project || targetNode?.project || null };
    });

    // Build activity feed
    let activity: Record<string, unknown>[] = [];
    if (includeActivity) {
      const feed = buildHistoricalFeed(
        selectedNodes,
        selectedLinks,
        commentsResult ? scopedComments : null
      );
      activity = feed.slice(0, limit).map((event) => ({
        type: event.type,
        time: new Date(event.time).toISOString(),
        issue_id: event.nodeId,
        project: event.project || null,
        ...(event.nodeTitle ? { issue_title: event.nodeTitle } : {}),
        ...(event.actor ? { actor: { handle: event.actor.handle } } : {}),
        ...(event.detail ? { detail: event.detail } : {}),
      }));
    }

    // Warnings for partial data
    const warnings: string[] = [];
    if (includeComments && !commentsResult) {
      warnings.push("Failed to fetch comments from indexer");
    }

    return jsonResponse({
      project: {
        name: "Plug",
        prefix: null,
        repos,
        repoUrls: {},
        projects: selectedProjects,
      },
      issues: enrichedIssues,
      dependencies,
      stats: (() => {
        const source = (projectFilter ? selectedProjects[projectFilter!].stats : beadsData.stats) as Record<string, unknown>;
        return {
          total: Number(source.total ?? 0),
          open: Number(source.open ?? 0),
          in_progress: Number(source.inProgress ?? source.in_progress ?? 0),
          blocked: Number(source.blocked ?? 0),
          closed: Number(source.closed ?? 0),
          actionable: Number(source.actionable ?? 0),
        };
      })(),
        ...(includeActivity ? { activity } : {}),
      projects: selectedProjects,
      _meta: {
        generated_at: new Date().toISOString(),
        api_version: "v1" as const,
        heartbeads_version: heartbeadsVersion,
        freshness: beadsData.freshness,
        ...(warnings.length ? { warnings } : {}),
      },
    });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : "Unknown error";
    if (message.includes("HEARTBEADS_BINDING") || message.startsWith("--binding") || message.startsWith("unable to read binding") || message.startsWith("binding.")) {
      return errorResponse(
        "No Plug binding found",
        404,
        "Pass --binding /absolute/path/host-binding.json to heartbeads."
      );
    }
    console.error("[api/v1/graph] Error:", error);
    return errorResponse("Internal server error", 500);
  }
}
