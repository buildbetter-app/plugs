/**
 * GET /api/v1/issues/:id — Single issue detail for AI agents.
 *
 * Returns one issue with full description, threaded comments,
 * claim info, and enriched blockers/dependents (with title + status).
 * No auth required.
 */

import { loadBeadsData } from "@/lib/parse-beads";
import { fetchBeadsComments, getClaimedNodes, boundComments } from "@/lib/comments";
import type { BeadsComment, ClaimInfo } from "@/lib/comments";
import type { GraphNode } from "@/lib/types";
import { jsonResponse, errorResponse, OPTIONS } from "@/lib/api-helpers";
import { readFileSync } from "fs";
import { join } from "path";

export const dynamic = "force-dynamic";
export { OPTIONS };

let heartbeadsVersion = "0.0.0";
try {
  const pkg = JSON.parse(
    readFileSync(join(process.cwd(), "package.json"), "utf-8")
  );
  heartbeadsVersion = pkg.version || heartbeadsVersion;
} catch {
  // ignore
}

function graphKey(node: GraphNode): string {
  return node.graphKey || `${node.project || ""}\u0000${node.id}`;
}

function serializeComment(c: BeadsComment): Record<string, unknown> {
  return {
    author: {
      handle: c.handle,
      did: c.did,
      ...(c.displayName ? { displayName: c.displayName } : {}),
    },
    text: c.text,
    createdAt: c.createdAt,
    likes: c.likes.length,
    replies: c.replies.map(serializeComment),
  };
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: issueId } = await params;
    const projectFilter = new URL(request.url).searchParams.get("project");

    // Load beads data + comments in parallel
    const [beadsData, commentsResult] = await Promise.all([
      loadBeadsData(),
      fetchBeadsComments().catch((err) => {
        console.error("[api/v1/issues] Failed to fetch comments:", err);
        return null;
      }),
    ]);

    // Find the issue
    const nodeMap = new Map<string, GraphNode>(
      beadsData.graphData.nodes.map((n) => [graphKey(n), n])
    );
    const matches = beadsData.graphData.nodes.filter((candidate) =>
      candidate.id === issueId && (!projectFilter || candidate.project === projectFilter)
    );
    if (matches.length > 1) return errorResponse("Ambiguous issue id", 409, "Supply an explicit ?project=cody-ops or ?project=signals-v2.");
    const node = matches.length === 1 ? matches[0] : undefined;

    if (!node) {
      return errorResponse(
        "Issue not found",
        404,
        `No uniquely selected issue with id "${issueId}". Supply ?project=cody-ops or ?project=signals-v2.`
      );
    }

    // Build enriched blockers/dependents with title + status
    // dependentIds = issues that block this one (upstream)
    // blockerIds = issues this one blocks (downstream)
    const dependentKeys = node.dependentKeys || node.dependentIds.map((id) => `${node.project || ""}\u0000${id}`);
    const blockerKeys = node.blockerKeys || node.blockerIds.map((id) => `${node.project || ""}\u0000${id}`);
    const enrichedBlockers = dependentKeys.map((key, index) => {
      const n = nodeMap.get(key);
      const id = n?.id || node.dependentIds[index];
      return n
        ? { id: n.id, project: n.project || null, title: n.title, status: n.status }
        : { id, project: node.project || null, title: null, status: null };
    });

    const enrichedDependents = blockerKeys.map((key, index) => {
      const n = nodeMap.get(key);
      const id = n?.id || node.blockerIds[index];
      return n
        ? { id: n.id, project: n.project || null, title: n.title, status: n.status }
        : { id, project: node.project || null, title: null, status: null };
    });

    // Comments and claims
    const nodeComments = boundComments(commentsResult?.commentsByNode.get(issueId) || [], beadsData.graphData.nodes).filter((comment) => comment.project === node.project);
    const claims = commentsResult
      ? getClaimedNodes(boundComments(commentsResult.allComments, beadsData.graphData.nodes), (comment) => `${comment.project || ""}\u0000${comment.nodeId}`)
      : new Map<string, ClaimInfo>();
    const claim = claims.get(`${node.project || ""}\u0000${node.id}`) || null;

    const warnings: string[] = [];
    if (!commentsResult) {
      warnings.push("Failed to fetch comments from indexer");
    }

    return jsonResponse({
      issue: {
        id: node.id,
        legacy_id: node.legacyId || node.id,
        canonical_id: node.canonicalId || null,
        project: node.project || null,
        title: node.title,
        description: node.description || null,
        status: node.status,
        priority: node.priority,
        issue_type: node.issueType,
        owner: node.owner || null,
        assignee: node.assignee || null,
        labels: node.labels,
        created_at: node.createdAt,
        updated_at: node.updatedAt,
        closed_at: node.closedAt || null,
        close_reason: node.closeReason || null,
        prefix: node.prefix,
        blockers: enrichedBlockers,
        dependents: enrichedDependents,
        comments: nodeComments.map(serializeComment),
        claimed_by: claim
          ? {
              handle: claim.handle,
              did: claim.did,
              ...(claim.displayName
                ? { displayName: claim.displayName }
                : {}),
              claimed_at: claim.claimedAt,
            }
          : null,
      },
      _meta: {
        generated_at: new Date().toISOString(),
        api_version: "v1" as const,
        heartbeads_version: heartbeadsVersion,
        freshness: beadsData.freshness,
        ...(warnings.length ? { warnings } : {}),
      },
    });
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : "Unknown error";
    if (message.includes("HEARTBEADS_BINDING") || message.startsWith("--binding") || message.startsWith("unable to read binding") || message.startsWith("binding.")) {
      return errorResponse(
        "No Plug binding found",
        404,
        "Pass --binding /absolute/path/host-binding.json to heartbeads."
      );
    }
    console.error("[api/v1/issues] Error:", error);
    return errorResponse("Internal server error", 500);
  }
}
