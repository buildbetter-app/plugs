import { NextResponse } from "next/server";
import { bindingConfig } from "@/lib/plug-adapter.mjs";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json(await bindingConfig());
  } catch (error) {
    return NextResponse.json({
      name: "Plug",
      prefix: null,
      repoCount: 0,
      repos: [],
      projects: {},
      error: error instanceof Error ? error.message : "Plug binding unavailable",
    });
  }
}

