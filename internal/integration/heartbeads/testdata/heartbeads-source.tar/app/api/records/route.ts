import { NextRequest, NextResponse } from "next/server";
import { getAuthenticatedAgent } from "@/lib/agent";
import { getSession } from "@/lib/session";
import { loadProjection } from "@/lib/plug-adapter.mjs";
import type { GraphNode } from "@/lib/types";

export const dynamic = "force-dynamic";

/** Only these ATProto collections are allowed through /api/records. */
const ALLOWED_COLLECTIONS = new Set([
  "org.impactindexer.review.comment",
  "org.impactindexer.review.like",
]);

const PROJECTS = new Set(["cody-ops", "signals-v2"]);
const COMMENT_COLLECTION = "org.impactindexer.review.comment";
type BoundScope = { project: string; nodeId: string };
type Agent = NonNullable<Awaited<ReturnType<typeof getAuthenticatedAgent>>>;
class RecordScopeError extends Error {}

async function requireBoundNode(project: unknown, nodeId: unknown) {
  if (typeof project !== "string" || !PROJECTS.has(project) || typeof nodeId !== "string" || !nodeId) {
    throw new RecordScopeError("An explicit bound project and original node id are required");
  }
  const data = await loadProjection() as { graphData: { nodes: GraphNode[] } };
  const nodes = data.graphData.nodes;
  if (nodes.filter((node) => node.project === project && node.id === nodeId).length !== 1) {
    throw new RecordScopeError("Record subject is not in the selected Plug project");
  }
  return { nodes, scope: { project, nodeId } };
}

function recordValue(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new RecordScopeError("Invalid record value");
  return value as Record<string, unknown>;
}

function subjectURI(record: Record<string, unknown>): string {
  const subject = recordValue(record.subject);
  if (typeof subject.uri !== "string" || !subject.uri) throw new RecordScopeError("Record subject URI is required");
  return subject.uri;
}

function sameScope(actual: BoundScope, expected: BoundScope) {
  if (actual.project !== expected.project || actual.nodeId !== expected.nodeId) {
    throw new RecordScopeError("Record subject does not match the selected Plug project and node");
  }
}

function checkStoredScope(value: Record<string, unknown>, scope: BoundScope) {
  if ((value.project !== undefined && value.project !== scope.project) ||
      (value.nodeId !== undefined && value.nodeId !== scope.nodeId)) {
    throw new RecordScopeError("Contradictory stored record scope");
  }
}

// Old comments have only beads:<original-id>. Resolve against BOTH projects,
// never against the requested project alone. An ambiguous old ID must refuse.
function commentScope(value: Record<string, unknown>, nodes: GraphNode[]): BoundScope {
  const uri = subjectURI(value);
  if (!uri.startsWith("beads:") || uri.length === 6) throw new RecordScopeError("Expected a beads comment subject");
  const nodeId = uri.slice(6);
  if (value.project !== undefined && (typeof value.project !== "string" || !PROJECTS.has(value.project))) {
    throw new RecordScopeError("Unknown stored project");
  }
  const matches = nodes.filter((node) => node.id === nodeId && (value.project === undefined || node.project === value.project));
  if (matches.length !== 1 || !matches[0].project) throw new RecordScopeError("Unknown or ambiguous legacy record subject");
  const scope = { project: matches[0].project, nodeId };
  checkStoredScope(value, scope);
  return scope;
}

async function referencedCommentScope(agent: Agent, uri: unknown, nodes: GraphNode[], seen: Set<string>, ancestors: boolean): Promise<BoundScope> {
  if (typeof uri !== "string") throw new RecordScopeError("Comment reference is required");
  const parts = /^at:\/\/([^/]+)\/org\.impactindexer\.review\.comment\/([^/]+)$/.exec(uri);
  if (!parts || seen.has(uri) || seen.size >= 32) throw new RecordScopeError("Invalid or cyclic comment reference");
  const next = new Set(seen); next.add(uri);
  try {
    const result = await agent.com.atproto.repo.getRecord({ repo: parts[1], collection: COMMENT_COLLECTION, rkey: parts[2] });
    return resolveRecordScope(agent, COMMENT_COLLECTION, recordValue(result.data.value), nodes, next, ancestors);
  } catch (error) {
    if (error instanceof RecordScopeError) throw error;
    throw new RecordScopeError("Referenced comment is unavailable");
  }
}

async function resolveRecordScope(agent: Agent, collection: string, value: Record<string, unknown>, nodes: GraphNode[], seen = new Set<string>(), ancestors = true): Promise<BoundScope> {
  if (collection === COMMENT_COLLECTION) {
    const scope = commentScope(value, nodes);
    if (ancestors && value.replyTo !== undefined) sameScope(await referencedCommentScope(agent, value.replyTo, nodes, seen, true), scope);
    return scope;
  }
  // Legacy likes carry only an AT-URI; their referenced comment establishes
  // identity. Caller-supplied node/project must agree with that target.
  const scope = await referencedCommentScope(agent, subjectURI(value), nodes, seen, false);
  checkStoredScope(value, scope);
  return scope;
}

async function requireRequestedSubject(agent: Agent, collection: string, record: Record<string, unknown>, nodes: GraphNode[], scope: BoundScope, existing?: Record<string, unknown>) {
  checkStoredScope(record, scope);
  // An unchanged stored reply reference may survive deletion of its ancestor.
  // Its stored direct subject was already verified in the authenticated repo.
  const retainedReply = collection === COMMENT_COLLECTION && existing &&
    record.replyTo === existing.replyTo && (record.replyTo === undefined ||
      (typeof record.replyTo === "string" && /^at:\/\/[^/]+\/org\.impactindexer\.review\.comment\/[^/]+$/.test(record.replyTo)));
  const actual = await resolveRecordScope(agent, collection, { ...record, ...scope }, nodes, new Set(), !retainedReply);
  sameScope(actual, scope);
}

async function requireExistingSubject(agent: Agent, repo: string, collection: string, rkey: string, nodes: GraphNode[], scope: BoundScope) {
  const existing = await agent.com.atproto.repo.getRecord({ repo, collection, rkey });
  const value = recordValue(existing.data.value);
  // Stored comments establish their identity directly; deletion must not
  // require all ancestors to remain live. Likes still require a live target.
  sameScope(await resolveRecordScope(agent, collection, value, nodes, new Set(), false), scope);
  return value;
}

/**
 * POST /api/records — Create a new record
 * Body: { collection, rkey?, record }
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { collection, rkey, record, project } = body;

    if (!collection || typeof collection !== "string") {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!record || typeof record !== "object") {
      return NextResponse.json(
        { error: "Record is required" },
        { status: 400 }
      );
    }
    const nodeId = body.nodeId;
    const { nodes, scope } = await requireBoundNode(project, nodeId);
    await requireRequestedSubject(agent, collection, recordValue(record), nodes, scope);

    const res = await agent.com.atproto.repo.createRecord({
      repo: session.did,
      collection,
      rkey: rkey || undefined,
      record: { ...record, project, nodeId },
    });

    return NextResponse.json({
      success: true,
      uri: res.data.uri,
      cid: res.data.cid,
    });
  } catch (error) {
    console.error("Failed to create record:", error);
    if (error instanceof RecordScopeError) return NextResponse.json({ error: error.message }, { status: 403 });
    return NextResponse.json(
      { error: "Failed to create record" },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/records — Update an existing record
 * Body: { collection, rkey, record }
 */
export async function PUT(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { collection, rkey, record, project } = body;

    if (!collection || typeof collection !== "string") {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!rkey || typeof rkey !== "string") {
      return NextResponse.json(
        { error: "Record key is required" },
        { status: 400 }
      );
    }
    if (!record || typeof record !== "object") {
      return NextResponse.json(
        { error: "Record is required" },
        { status: 400 }
      );
    }
    const nodeId = body.nodeId;
    const { nodes, scope } = await requireBoundNode(project, nodeId);
    const existing = await requireExistingSubject(agent, session.did, collection, rkey, nodes, scope);
    await requireRequestedSubject(agent, collection, recordValue(record), nodes, scope, existing);

    await agent.com.atproto.repo.putRecord({
      repo: session.did,
      collection,
      rkey,
      record: { ...record, project, nodeId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to update record:", error);
    if (error instanceof RecordScopeError) return NextResponse.json({ error: error.message }, { status: 403 });
    return NextResponse.json(
      { error: "Failed to update record" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/records?collection=...&rkey=...
 * Deletes a record from the authenticated user's repo.
 */
export async function DELETE(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.did) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const agent = await getAuthenticatedAgent();
    if (!agent) {
      return NextResponse.json(
        { error: "Failed to authenticate" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const collection = searchParams.get("collection");
    const rkey = searchParams.get("rkey");
    const project = searchParams.get("project");
    const nodeId = searchParams.get("nodeId");
    const requestedDid = searchParams.get("did");

    if (!collection) {
      return NextResponse.json(
        { error: "Collection is required" },
        { status: 400 }
      );
    }
    if (!ALLOWED_COLLECTIONS.has(collection)) {
      return NextResponse.json(
        { error: "Collection not allowed" },
        { status: 403 }
      );
    }
    if (!rkey) {
      return NextResponse.json(
        { error: "Record key is required" },
        { status: 400 }
      );
    }
    if (requestedDid && requestedDid !== session.did) {
      return NextResponse.json({ error: "Record identity does not match the session" }, { status: 403 });
    }
    const { nodes, scope } = await requireBoundNode(project, nodeId);
    await requireExistingSubject(agent, session.did, collection, rkey, nodes, scope);

    await agent.com.atproto.repo.deleteRecord({
      repo: session.did,
      collection,
      rkey,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete record:", error);
    if (error instanceof RecordScopeError) return NextResponse.json({ error: error.message }, { status: 403 });
    return NextResponse.json(
      { error: "Failed to delete record" },
      { status: 500 }
    );
  }
}
