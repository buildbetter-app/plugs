import { projectionStore } from "@/lib/plug-adapter.mjs";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  let cancelStream: (() => void) | undefined;
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder();
      let closed = request.signal.aborted;
      let watcherStop: (() => void) | undefined;
      let heartbeat: ReturnType<typeof setInterval> | undefined;
      let cleanupDone = false;

      const cleanup = () => {
        if (cleanupDone) return;
        cleanupDone = true;
        closed = true;
        if (heartbeat !== undefined) {
          clearInterval(heartbeat);
          heartbeat = undefined;
        }
        const stop = watcherStop;
        watcherStop = undefined;
        stop?.();
      };
      cancelStream = cleanup;

      const closeController = () => {
        try { controller.close(); } catch { /* already closed */ }
      };
      const send = (data: unknown) => {
        if (closed) return false;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
          return true;
        } catch {
          cleanup();
          return false;
        }
      };

      if (closed) {
        cleanup();
        closeController();
        return;
      }

      heartbeat = setInterval(() => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(": heartbeat\n\n"));
        } catch {
          cleanup();
        }
      }, 30000);

      const onAbort = () => {
        cleanup();
        closeController();
      };
      request.signal.addEventListener("abort", onAbort, { once: true });

      // Loading the singleton/binding is asynchronous. A disconnect before it
      // resolves must not start a watcher after the stream has been cancelled.
      void projectionStore().then((store) => {
        if (closed || cleanupDone || request.signal.aborted) return;
        watcherStop = store.watch(send, (error: unknown) => {
          if (!send({
            error: error instanceof Error ? error.message : "Plug projection refresh failed",
            freshness: { state: "stale" },
          })) cleanup();
        }, { intervalMs: 1000 });
        if (closed || cleanupDone) {
          watcherStop?.();
          watcherStop = undefined;
        }
      }).catch((error) => {
        if (closed || cleanupDone) return;
        send({ error: error instanceof Error ? error.message : "Plug binding failed" });
        cleanup();
        closeController();
      });
    },
    cancel() {
      cancelStream?.();
    },
  });
  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
