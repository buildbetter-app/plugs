import { NextResponse } from "next/server";
import { loadBeadsData } from "@/lib/parse-beads";

export async function GET() {
  try {
    const data = await loadBeadsData();
    return NextResponse.json(data);
  } catch (error: any) {
    if (error?.message?.includes("HEARTBEADS_BINDING") || error?.message?.startsWith("--binding") || error?.message?.startsWith("unable to read binding") || error?.message?.startsWith("binding.")) {
      return NextResponse.json(
        {
          error: "No Plug binding found",
          hint: "Pass --binding /absolute/path/host-binding.json to heartbeads",
        },
        { status: 404 }
      );
    }
    console.error("Failed to load Plug projection:", error);
    return NextResponse.json(
      { error: "Failed to load Plug projection" },
      { status: 500 }
    );
  }
}
