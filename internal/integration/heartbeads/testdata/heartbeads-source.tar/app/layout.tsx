import type { Metadata, Viewport } from "next";
import { AuthProvider } from "@/lib/auth";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.PUBLIC_URL || "http://localhost:3000"),
  title: "Heartbeads",
  description:
    "Interactive dependency graph viewer for beads issues — see your project's heartbeat",
  openGraph: {
    title: "Heartbeads",
    description: "Interactive dependency graph viewer for beads issues — see your project's heartbeat",
    type: "website",
    siteName: "Heartbeads",
    images: [
      {
        url: "/image.png",
        width: 1200,
        height: 630,
        alt: "Heartbeads — interactive dependency graph viewer",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Heartbeads",
    description: "Interactive dependency graph viewer for beads issues — see your project's heartbeat",
    images: ["/image.png"],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem("heartbeads-theme");if(t==="dark"||(!t&&window.matchMedia("(prefers-color-scheme:dark)").matches)){document.documentElement.classList.add("dark")}}catch(e){}})()`,
          }}
        />
      </head>
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
