import { loadProjection } from "./plug-adapter.mjs";
import type { BeadDependency, BeadIssue, BeadsApiResponse, GraphData } from "./types";

/** Heartbeads reads the explicitly bound Plug projection; JSONL is unavailable. */
export async function loadBeadsData(bindingPath?: string): Promise<BeadsApiResponse> {
  return (await loadProjection(bindingPath)) as BeadsApiResponse;
}

export function parseIssuesJsonl(_beadsDir?: string): BeadIssue[] {
  throw new Error("Heartbeads is Plug-bound; JSONL loading is unavailable");
}
export function extractDependencies(_issues: BeadIssue[]): BeadDependency[] {
  throw new Error("Heartbeads is Plug-bound; JSONL loading is unavailable");
}
export function buildGraphData(_issues: BeadIssue[], _dependencies: BeadDependency[]): GraphData {
  throw new Error("Heartbeads is Plug-bound; JSONL loading is unavailable");
}

