import type { BeadsApiResponse, GraphLink, GraphNode } from "./types";

export interface NodeChange {
  field: string;
  from: string;
  to: string;
}

export interface BeadsDiff {
  /** Internal project-qualified node keys, never raw IDs. */
  addedNodeIds: Set<string>;
  removedNodeIds: Set<string>;
  changedNodes: Map<string, NodeChange[]>;
  addedLinkKeys: Set<string>;
  removedLinkKeys: Set<string>;
  /** Any persisted projection or freshness field changed. */
  hasChanges: boolean;
  /** Changes that should create graph/activity animation metadata. */
  hasAnimationChanges: boolean;
  freshnessChanged: boolean;
}

export function nodeKey(node: Pick<GraphNode, "id" | "project" | "graphKey">): string {
  return node.graphKey || `${node.project || ""}\u0000${node.id}`;
}

function endpointKey(link: GraphLink, side: "source" | "target"): string {
  const explicit = side === "source" ? link.sourceKey : link.targetKey;
  if (explicit) return explicit;
  const endpoint = link[side];
  if (typeof endpoint === "object") return nodeKey(endpoint as GraphNode);
  return String(endpoint);
}

/** Build a stable internal key; public source/target IDs remain lossless. */
export function linkKey(link: GraphLink): string {
  return `${endpointKey(link, "source")}->${endpointKey(link, "target")}:${link.type}`;
}

function stable(value: unknown): string {
  if (value === undefined) return "";
  if (typeof value === "string") return value;
  try { return JSON.stringify(value); } catch { return String(value); }
}

const NODE_FIELDS: Array<[string, (node: GraphNode) => unknown]> = [
  ["status", (node) => node.status],
  ["statusCategory", (node) => node.statusCategory],
  ["ready", (node) => node.ready],
  ["priority", (node) => node.priority],
  ["title", (node) => node.title],
  ["description", (node) => node.description || ""],
  ["owner", (node) => node.owner || ""],
  ["assignee", (node) => node.assignee || ""],
  ["createdBy", (node) => node.createdBy || ""],
  ["createdAt", (node) => node.createdAt || ""],
  ["updatedAt", (node) => node.updatedAt || ""],
  ["closedAt", (node) => node.closedAt || ""],
  ["closeReason", (node) => node.closeReason || ""],
  ["acceptanceCriteria", (node) => node.acceptanceCriteria || ""],
  ["estimatedMinutes", (node) => node.estimatedMinutes ?? ""],
  ["labels", (node) => node.labels || []],
  ["project", (node) => node.project || ""],
  ["canonicalId", (node) => node.canonicalId || ""],
  ["legacyId", (node) => node.legacyId || node.id],
  ["parentKey", (node) => node.parentKey || ""],
  ["dependentKeys", (node) => node.dependentKeys || []],
  ["blockerKeys", (node) => node.blockerKeys || []],
];

const ANIMATION_FIELDS = new Set(["status", "priority", "title", "owner", "assignee"]);

export function diffBeadsData(oldData: BeadsApiResponse | null, newData: BeadsApiResponse): BeadsDiff {
  if (!oldData) {
    return {
      addedNodeIds: new Set(newData.graphData.nodes.map(nodeKey)),
      removedNodeIds: new Set(),
      changedNodes: new Map(),
      addedLinkKeys: new Set(newData.graphData.links.map(linkKey)),
      removedLinkKeys: new Set(),
      hasChanges: true,
      hasAnimationChanges: true,
      freshnessChanged: true,
    };
  }

  const oldNodeMap = new Map(oldData.graphData.nodes.map((node) => [nodeKey(node), node]));
  const newNodeMap = new Map(newData.graphData.nodes.map((node) => [nodeKey(node), node]));
  const addedNodeIds = new Set<string>();
  const removedNodeIds = new Set<string>();
  const changedNodes = new Map<string, NodeChange[]>();
  let hasAnimationChanges = false;

  for (const [key, node] of newNodeMap) {
    const old = oldNodeMap.get(key);
    if (!old) {
      addedNodeIds.add(key);
      hasAnimationChanges = true;
      continue;
    }
    const changes: NodeChange[] = [];
    for (const [field, read] of NODE_FIELDS) {
      const from = stable(read(old));
      const to = stable(read(node));
      if (from !== to) {
        changes.push({ field, from, to });
        if (ANIMATION_FIELDS.has(field)) hasAnimationChanges = true;
      }
    }
    if (changes.length) changedNodes.set(key, changes);
  }
  for (const key of oldNodeMap.keys()) {
    if (!newNodeMap.has(key)) {
      removedNodeIds.add(key);
      hasAnimationChanges = true;
    }
  }

  const oldLinkKeys = new Set(oldData.graphData.links.map(linkKey));
  const newLinkKeys = new Set(newData.graphData.links.map(linkKey));
  const addedLinkKeys = new Set([...newLinkKeys].filter((key) => !oldLinkKeys.has(key)));
  const removedLinkKeys = new Set([...oldLinkKeys].filter((key) => !newLinkKeys.has(key)));
  if (addedLinkKeys.size || removedLinkKeys.size) hasAnimationChanges = true;

  const freshnessChanged = stable(oldData.freshness) !== stable(newData.freshness);
  const hasChanges = addedNodeIds.size > 0 || removedNodeIds.size > 0 || changedNodes.size > 0 || addedLinkKeys.size > 0 || removedLinkKeys.size > 0 || freshnessChanged || stable(oldData.projects) !== stable(newData.projects) || stable(oldData.stats) !== stable(newData.stats);
  return { addedNodeIds, removedNodeIds, changedNodes, addedLinkKeys, removedLinkKeys, hasChanges, hasAnimationChanges, freshnessChanged };
}
