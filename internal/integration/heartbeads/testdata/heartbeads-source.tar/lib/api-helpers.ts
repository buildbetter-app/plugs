/**
 * Shared helpers for /api/v1/* routes.
 * Provides CORS headers, JSON response builders, and OPTIONS handler.
 */

import { NextResponse } from "next/server";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

/**
 * Build a JSON response with CORS and Cache-Control headers.
 */
export function jsonResponse(data: unknown, status = 200) {
  return NextResponse.json(data, {
    status,
    headers: {
      ...CORS_HEADERS,
      "Cache-Control": "public, max-age=30",
    },
  });
}

/**
 * Build an error JSON response with CORS headers (no caching).
 */
export function errorResponse(
  error: string,
  status: number,
  hint?: string
) {
  return NextResponse.json(
    { error, ...(hint ? { hint } : {}) },
    { status, headers: CORS_HEADERS }
  );
}

/**
 * Preflight OPTIONS handler for CORS. Re-export from each route file.
 */
export function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}
