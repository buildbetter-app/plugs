/**
 * Shared comment-fetching logic for beads.
 *
 * Fetches comments and likes from the Hypergoat GraphQL indexer,
 * resolves Bluesky profiles, builds threaded comment trees, and
 * detects claim info. Used by both the React hook (useBeadsComments)
 * and the public API routes (/api/v1/*).
 */

// ============================================================================
// Types
// ============================================================================

export interface BeadsLike {
  project?: string;
  nodeId?: string;
  did: string;
  handle: string;
  displayName?: string;
  avatar?: string;
  createdAt: string;
  uri: string; // AT-URI of the like record
  rkey: string;
}

export interface BeadsComment {
  did: string;
  handle: string;
  displayName?: string;
  avatar?: string;
  text: string;
  createdAt: string;
  uri: string; // AT-URI of the comment record
  rkey: string;
  legacyId?: string; // Original public ID when nodeId is UI-qualified
  nodeId: string; // The public legacy issue ID this comment targets
  project?: string; // Explicit bound project carried by prepared callers
  replyTo?: string; // AT-URI of parent comment (for threading)
  likes: BeadsLike[]; // Likes on this comment
  replies: BeadsComment[]; // Nested child comments (built during assembly)
}

export interface ClaimInfo {
  handle: string;
  did: string;
  displayName?: string;
  avatar?: string;
  claimedAt: string;
}

export interface FetchCommentsResult {
  /** Qualified roots, newest-first, including replies whose parent was deleted. */
  rootComments: BeadsComment[];
  /** Map from node ID -> threaded comment trees (root comments with nested replies) */
  commentsByNode: Map<string, BeadsComment[]>;
  /** Map from node ID -> total comment count (including replies) */
  commentedNodeIds: Map<string, number>;
  /** Flat list of ALL comments (including replies), newest-first */
  allComments: BeadsComment[];
}

// ============================================================================
// Profile resolution (cached, deduplicated)
// ============================================================================

interface ResolvedProfile {
  did: string;
  handle: string;
  displayName?: string;
  avatar?: string;
}

const profileCache = new Map<string, ResolvedProfile>();
const profileInflight = new Map<string, Promise<ResolvedProfile>>();

async function resolveProfile(did: string): Promise<ResolvedProfile> {
  const cached = profileCache.get(did);
  if (cached) return cached;

  const inflight = profileInflight.get(did);
  if (inflight) return inflight;

  const promise = (async () => {
    try {
      const res = await fetch(
        `https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor=${encodeURIComponent(did)}`
      );
      if (!res.ok) throw new Error(`Profile fetch failed: ${res.status}`);
      const data = await res.json();
      const profile: ResolvedProfile = {
        did,
        handle: data.handle || did,
        displayName: data.displayName || undefined,
        avatar: data.avatar || undefined,
      };
      profileCache.set(did, profile);
      return profile;
    } catch {
      // Fallback: use DID as handle
      const fallback: ResolvedProfile = {
        did,
        handle: did.slice(0, 20) + "...",
      };
      profileCache.set(did, fallback);
      return fallback;
    } finally {
      profileInflight.delete(did);
    }
  })();

  profileInflight.set(did, promise);
  return promise;
}

// ============================================================================
// Hypergoat GraphQL fetching
// ============================================================================

const INDEXER_URL =
  process.env.INDEXER_URL ||
  "https://hypergoat-app-production.up.railway.app/graphql";

const FETCH_RECORDS_QUERY = `
  query FetchRecords($collection: String!, $first: Int, $after: String) {
    records(collection: $collection, first: $first, after: $after) {
      edges {
        node {
          cid
          collection
          did
          rkey
          uri
          value
        }
      }
      pageInfo {
        hasNextPage
        endCursor
      }
    }
  }
`;

interface IndexerRecord {
  cid: string;
  collection: string;
  did: string;
  rkey: string;
  uri: string;
  value: Record<string, unknown>;
}

interface IndexerResponse {
  data?: {
    records?: {
      edges: Array<{ node: IndexerRecord }>;
      pageInfo: { hasNextPage: boolean; endCursor?: string };
    };
  };
  errors?: Array<{ message: string }>;
}

async function fetchRecordsByCollection(
  collection: string
): Promise<IndexerRecord[]> {
  const allRecords: IndexerRecord[] = [];
  let cursor: string | undefined;
  let hasMore = true;
  let pages = 0;
  const MAX_PAGES = 5; // Safety limit

  while (hasMore && pages < MAX_PAGES) {
    const res = await fetch(INDEXER_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: FETCH_RECORDS_QUERY,
        variables: {
          collection,
          first: 100,
          after: cursor,
        },
      }),
    });

    if (!res.ok) {
      throw new Error(`Indexer fetch failed: ${res.status}`);
    }

    const json: IndexerResponse = await res.json();

    if (json.errors?.length) {
      throw new Error(json.errors[0].message);
    }

    const records = json.data?.records;
    if (!records) break;

    for (const edge of records.edges) {
      allRecords.push(edge.node);
    }

    hasMore = records.pageInfo.hasNextPage;
    cursor = records.pageInfo.endCursor;
    pages++;
  }

  return allRecords;
}

// ============================================================================
// Core: fetch and process comments
// ============================================================================

/**
 * Fetch all beads comments and likes from Hypergoat, resolve profiles,
 * build threaded trees, and group by node.
 *
 * This is the pure data-fetching function used by both:
 * - `hooks/useBeadsComments.ts` (client-side React hook)
 * - `app/api/v1/*` routes (server-side API)
 */
export async function fetchBeadsComments(): Promise<Pick<FetchCommentsResult, "allComments">> {
  // 1. Fetch comments and likes in parallel from Hypergoat
  const [commentRecords, likeRecords] = await Promise.all([
    fetchRecordsByCollection("org.impactindexer.review.comment"),
    fetchRecordsByCollection("org.impactindexer.review.like"),
  ]);

  // 2. Filter to only beads-targeted comments
  const beadsCommentRecords = commentRecords.filter((r) => {
    const value = r.value as Record<string, unknown>;
    const subject = value.subject as
      | { uri?: string; type?: string }
      | undefined;
    return (
      subject?.uri &&
      typeof subject.uri === "string" &&
      subject.uri.startsWith("beads:") &&
      (value.nodeId === undefined || value.nodeId === subject.uri.slice(6)) &&
      (value.project === undefined || typeof value.project === "string")
    );
  });

  // 3. Build likes-by-comment-URI map
  const likesByCommentUri = new Map<string, IndexerRecord[]>();
  for (const likeRecord of likeRecords) {
    const value = likeRecord.value as Record<string, unknown>;
    const subject = value.subject as
      | { uri?: string; type?: string }
      | undefined;
    if (
      subject?.uri &&
      typeof subject.uri === "string" &&
      subject.uri.startsWith("at://")
    ) {
      const existing = likesByCommentUri.get(subject.uri) || [];
      existing.push(likeRecord);
      likesByCommentUri.set(subject.uri, existing);
    }
  }

  // 4. Resolve profiles for all unique DIDs (commenters + likers)
  const allDids = new Set<string>();
  for (const r of beadsCommentRecords) allDids.add(r.did);
  for (const r of likeRecords) allDids.add(r.did);

  const profiles = await Promise.all(
    [...allDids].map((did) => resolveProfile(did))
  );
  const profileMap = new Map(profiles.map((p) => [p.did, p]));

  // 5. Build flat comment list with likes attached
  const allFlat: BeadsComment[] = [];

  for (const record of beadsCommentRecords) {
    const value = record.value as Record<string, unknown>;
    const subject = value.subject as { uri: string };
    const nodeId = subject.uri.replace(/^beads:/, "");
    const project = typeof value.project === "string" ? value.project : undefined;
    const text = (value.text as string) || "";
    const createdAt = (value.createdAt as string) || "";
    const replyTo = (value.replyTo as string) || undefined;
    const profile = profileMap.get(record.did);

    // Build likes for this comment
    const likeRecordsForComment =
      likesByCommentUri.get(record.uri) || [];
    const likes: BeadsLike[] = likeRecordsForComment.filter((lr) =>
      (lr.value.project === undefined || typeof lr.value.project === "string") &&
      (lr.value.nodeId === undefined || typeof lr.value.nodeId === "string")
    ).map((lr) => {
      const lp = profileMap.get(lr.did);
      const lv = lr.value as Record<string, unknown>;
      return {
        did: lr.did,
        handle: lp?.handle || lr.did.slice(0, 20) + "...",
        displayName: lp?.displayName,
        avatar: lp?.avatar,
        createdAt: (lv.createdAt as string) || "",
        project: lv.project as string | undefined,
        nodeId: lv.nodeId as string | undefined,
        uri: lr.uri,
        rkey: lr.rkey,
      };
    });

    const comment: BeadsComment = {
      did: record.did,
      handle: profile?.handle || record.did.slice(0, 20) + "...",
      displayName: profile?.displayName,
      avatar: profile?.avatar,
      text,
      createdAt,
      uri: record.uri,
      rkey: record.rkey,
      nodeId,
      project,
      replyTo,
      likes,
      replies: [], // Will be filled during tree assembly
    };

    allFlat.push(comment);
  }

  // Scope cannot be resolved from raw record fields alone. Keep records flat
  // until the caller can bind them against the complete two-project snapshot.
  return { allComments: allFlat.sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)) };
}

/** Resolve flat records against BOTH projects before thread assembly/filtering. */
export function boundComments(comments: BeadsComment[], nodes: Array<{ id: string; legacyId?: string; project?: string }>): BeadsComment[] {
  const byUri = new Map(comments.map((comment) => [comment.uri, comment]));
  const scopes = new Map(comments.map((comment) => {
    const matches = nodes.filter((node) => (node.legacyId ?? node.id) === comment.nodeId &&
      (comment.project === undefined || node.project === comment.project));
    return [comment.uri, matches.length === 1 ? matches[0].project : undefined];
  }));
  const valid = (comment: BeadsComment, seen = new Set<string>()): boolean => {
    const project = scopes.get(comment.uri);
    if (!project || seen.has(comment.uri) || seen.size >= 32) return false;
    const parent = comment.replyTo ? byUri.get(comment.replyTo) : undefined;
    if (!parent) return true; // Stored scoped orphan remains visible/removable.
    if (scopes.get(parent.uri) !== project || parent.nodeId !== comment.nodeId) return false;
    const next = new Set(seen); next.add(comment.uri);
    return valid(parent, next);
  };
  return comments.filter((comment) => valid(comment)).map((comment) => {
    const project = scopes.get(comment.uri)!;
    return {
      ...comment, project, replies: [],
      likes: comment.likes.filter((like) =>
        (like.project === undefined || like.project === project) &&
        (like.nodeId === undefined || like.nodeId === comment.nodeId)),
    };
  });
}

/** One URI-based tree builder for UI and HTTP, called only after qualification. */
export function threadComments(comments: BeadsComment[]): FetchCommentsResult {
  const flat = comments.map((comment) => ({ ...comment, replies: [] as BeadsComment[] }));
  const byUri = new Map(flat.map((comment) => [comment.uri, comment]));
  const rootComments: BeadsComment[] = [];
  for (const comment of flat) {
    const parent = comment.replyTo ? byUri.get(comment.replyTo) : undefined;
    if (parent && parent.project === comment.project && parent.nodeId === comment.nodeId) {
      parent.replies.push(comment);
    } else {
      // Do not discard a valid owned reply when its ancestor has been deleted.
      rootComments.push(comment);
    }
  }
  const newestFirst = (a: BeadsComment, b: BeadsComment) => Date.parse(b.createdAt) - Date.parse(a.createdAt);
  rootComments.sort(newestFirst);
  for (const comment of flat) comment.replies.sort((a, b) => -newestFirst(a, b));
  const commentsByNode = new Map<string, BeadsComment[]>();
  for (const comment of rootComments) {
    commentsByNode.set(comment.nodeId, [...(commentsByNode.get(comment.nodeId) || []), comment]);
  }
  const commentedNodeIds = new Map<string, number>();
  for (const comment of flat) commentedNodeIds.set(comment.nodeId, (commentedNodeIds.get(comment.nodeId) || 0) + 1);
  return { rootComments, commentsByNode, commentedNodeIds, allComments: flat.sort(newestFirst) };
}

// ============================================================================
// Claim detection
// ============================================================================

/**
 * Extract claim info from comments.
 * A claim comment has text starting with "@" and no spaces (e.g. "@alice.bsky.social").
 * First claim per node wins.
 */
export function getClaimedNodes(
  allComments: BeadsComment[],
  keyOf: (comment: BeadsComment) => string = (comment) => comment.nodeId
): Map<string, ClaimInfo> {
  const claims = new Map<string, ClaimInfo>();

  // Sort oldest-first so the first claim wins
  const sorted = [...allComments].sort(
    (a, b) =>
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  for (const comment of sorted) {
    const key = keyOf(comment);
    if (claims.has(key)) continue;

    const text = comment.text.trim();
    if (text.startsWith("@") && text.indexOf(" ") === -1) {
      claims.set(key, {
        handle: comment.handle,
        did: comment.did,
        displayName: comment.displayName,
        avatar: comment.avatar,
        claimedAt: comment.createdAt,
      });
    }
  }

  return claims;
}
