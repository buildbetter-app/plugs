import { readFileSync } from "fs";
import { isAbsolute } from "path";

export interface PlugDiscovery {
  bindingPath: string;
  repoRoot: string;
  repoName: string;
  issuePrefix?: string;
  additionalRepos: number;
  projects: string[];
}

/** Resolve only the caller-supplied binding; cwd and BEADS_DIR are ignored. */
export function discoverBeadsDir(): PlugDiscovery {
  const bindingPath = process.env.HEARTBEADS_BINDING || process.env.PLUG_BINDING;
  if (!bindingPath || !isAbsolute(bindingPath)) {
    throw new Error("HEARTBEADS_BINDING must name an absolute host binding");
  }
  let binding: { projects?: Record<string, { workspace?: string }> };
  try {
    binding = JSON.parse(readFileSync(bindingPath, "utf8"));
  } catch {
    throw new Error(`unable to read binding ${bindingPath}`);
  }
  const projects = Object.keys(binding.projects || {}).sort();
  if (projects.length !== 2 || projects[0] !== "cody-ops" || projects[1] !== "signals-v2") {
    throw new Error("binding must select exactly cody-ops and signals-v2");
  }
  return {
    bindingPath,
    repoRoot: binding.projects?.[projects[0]]?.workspace || "",
    repoName: "Plug",
    additionalRepos: 1,
    projects,
  };
}

export function getRepoUrls(_bindingPath?: string): Record<string, string> {
  return {};
}

