import { projectionStore } from "./plug-adapter.mjs";

/** Watch the two-project Plug projection; no filesystem watcher is involved. */
export function watchBeadsFiles(
  _ignored: string,
  onChange: (snapshot: unknown) => void,
  onError?: (error: unknown) => void,
  intervalMs = 1000
): () => void {
  let cleanup: (() => void) | undefined;
  let cancelled = false;
  void projectionStore().then((store) => {
    if (cancelled) return;
    cleanup = store.watch(onChange, onError, { intervalMs });
  }).catch((error) => onError?.(error));
  return () => {
    cancelled = true;
    cleanup?.();
  };
}

