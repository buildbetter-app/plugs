// ============================================================================
// User settings — persisted in localStorage
// ============================================================================

export interface BeadsMapSettings {
  elevenLabsApiKey?: string;
  elevenLabsVoiceId: string;
  elevenLabsModel: string;
}

const STORAGE_KEY = "heartbeads-settings";

const DEFAULTS: BeadsMapSettings = {
  elevenLabsVoiceId: "UgBBYS2sOqTuMpoF3BR0", // Mark - Natural Conversations
  elevenLabsModel: "eleven_flash_v2_5",
};

/** Read settings from localStorage, merged with defaults */
export function getSettings(): BeadsMapSettings {
  if (typeof window === "undefined") return { ...DEFAULTS };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULTS };
    return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULTS };
  }
}

/** Write settings to localStorage */
export function saveSettings(settings: Partial<BeadsMapSettings>): void {
  if (typeof window === "undefined") return;
  const current = getSettings();
  const merged = { ...current, ...settings };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
}

/** Check if ElevenLabs API key is configured */
export function hasApiKey(): boolean {
  const s = getSettings();
  return !!s.elevenLabsApiKey && s.elevenLabsApiKey.trim().length > 0;
}
