/**
 * Shared utilities for heartbeads.
 */

import { getPrefixLabel } from "@/lib/types";
import type { GraphNode } from "@/lib/types";

/**
 * Formats an ISO date string as a human-readable relative time.
 * - < 60s: "just now"
 * - < 60m: "Xm ago"
 * - < 24h: "Xh ago"
 * - < 7d:  "Xd ago"
 * - else:  "Mon DD" (e.g. "Feb 10")
 */
export function formatRelativeTime(isoString?: string): string {
  if (!isoString) return "Unavailable";
  const date = new Date(isoString);
  if (!Number.isFinite(date.getTime())) return "Unavailable";
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/**
 * Build a copy-pasteable text for a node's description with metadata header.
 * Format:
 *   [Project Name] issue-id
 *   https://github.com/org/repo  (if available)
 *
 *   <description>
 */
export function buildDescriptionCopyText(
  node: GraphNode,
  repoUrl?: string,
): string {
  const lines: string[] = [];
  lines.push(`[${getPrefixLabel(node.prefix)}] ${node.legacyId ?? node.id}`);
  if (repoUrl) lines.push(repoUrl);
  lines.push("");
  lines.push(node.description || "");
  return lines.join("\n");
}
