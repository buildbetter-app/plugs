"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { fetchBeadsComments } from "@/lib/comments";

// Re-export types so existing imports from this module continue to work
export type { BeadsComment, BeadsLike } from "@/lib/comments";

export interface UseBeadsCommentsResult {
  /** Flat list of ALL comments (including replies), newest-first, for the All Comments panel */
  allComments: BeadsComment[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

// Need to import the concrete type for state usage
import type { BeadsComment } from "@/lib/comments";

export function useBeadsComments(): UseBeadsCommentsResult {
  const [allComments, setAllComments] = useState<BeadsComment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const cancelledRef = useRef(false);

  const fetchAndProcess = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const result = await fetchBeadsComments();

      // Update state (only if not cancelled)
      if (!cancelledRef.current) {
        setAllComments(result.allComments);
      }
    } catch (err) {
      if (!cancelledRef.current) {
        const message =
          err instanceof Error ? err.message : "Failed to fetch comments";
        console.error("Failed to fetch beads comments:", err);
        setError(message);
      }
    } finally {
      if (!cancelledRef.current) {
        setIsLoading(false);
      }
    }
  }, []);

  // Fetch on mount
  useEffect(() => {
    cancelledRef.current = false;
    fetchAndProcess();
    return () => {
      cancelledRef.current = true;
    };
  }, [fetchAndProcess]);

  return {
    allComments,
    isLoading,
    error,
    refetch: fetchAndProcess,
  };
}
