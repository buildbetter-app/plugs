import { readFileSync } from "fs";

/** @type {import("next").NextConfig} */
const nextConfig = {
  env: {
    NEXT_PUBLIC_APP_VERSION: JSON.parse(
      readFileSync(new URL("./package.json", import.meta.url), "utf-8")
    ).version,
  },
};

export default nextConfig;
