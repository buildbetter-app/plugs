"""Independent reconstruction-only logical charge calculation, AUTHORED_NOT_RUN.

The counted Go types/category sites are pinned to receiver 26e90d85. This
does not count detached history, lowering, ledger or recovery multiplicity,
and cannot approve a complete receiving usage, refusal or publication.
The seven reconstruction/budget/size/wire files remain exactly c26 bytes.
No target module/function, fixture, SQL, compiler, product or ELF has run.
"""

import sqlite3

import native_delta_wire_v2 as wire
import native_delta_row_policy_v2 as rows
import native_delta_semantic_policy_v2 as semantic


RECEIVER_SOURCE = "26e90d85a0be080538b34b97e17849e4ced61d8b"
ACCOUNTING = "native-delta-decoded-accounting/1"
CATEGORIES = frozenset((
    "head_tar", "head_tar_copies", "header", "schemas", "commit_metadata",
    "decoded_operations", "decoded_baseline_rows", "reconstructed_table_metadata",
    "reconstructed_rows", "image_metadata", "reconstructed_images",
    "aggregate_images", "checkpoints", "commit_proofs"))


def _times(left, right):
    result = wire.uint(left) * wire.uint(right)
    wire.need(result <= wire.UINT64_MAX, "V2_CHARGE_SIZE_OVERFLOW")
    return result


def _text_size(value, guard):
    """Compact encoding/json string size, without encoding a full string."""
    wire.need(type(value) is str, "V2_CHARGE_STRING_TYPE_REFUSED")
    size = 2
    for index, char in enumerate(value):
        if index % 4096 == 0:
            guard()
        code = ord(char)
        wire.need(not 0xD800 <= code <= 0xDFFF, "V2_CHARGE_INVALID_UNICODE_REFUSED")
        if char in ('"', "\\", "\b", "\f", "\n", "\r", "\t"):
            count = 2
        elif code < 0x20 or char in ("<", ">", "&", "\u2028", "\u2029"):
            count = 6
        else:
            count = 1 if code < 0x80 else 2 if code < 0x800 else 3 if code < 0x10000 else 4
        size = wire.add(size, count)
    return size


def _value_size(value, guard):
    """JSON value bytes, excluding newline; Row numbers retain exact tokens.

    The input is a bounded row/schema/record, or a small constructed metadata
    skeleton. Aggregate images/maps are counted from disk rather than built.
    """
    guard()
    if value is None:
        return 4
    if type(value) is bool:
        return 4 if value else 5
    if type(value) is str:
        return _text_size(value, guard)
    if type(value) is int:
        return len(str(wire.uint(value)))
    if type(value) is rows._Number:
        return wire.uint(len(value.spelling))
    if type(value) is list:
        size = 2
        for index, nested in enumerate(value):
            size = wire.add(size, (1 if index else 0) + _value_size(nested, guard))
        return size
    if type(value) is dict:
        size = 2
        for index, (key, nested) in enumerate(value.items()):
            size = wire.add(size, (1 if index else 0) + _text_size(key, guard) + 1)
            size = wire.add(size, _value_size(nested, guard))
        return size
    raise wire.Refusal("V2_CHARGE_JSON_TYPE_REFUSED")


def _uint_token(value):
    wire.need(type(value) is rows._Number and 1 <= len(value.spelling) <= 20 and
              value.spelling.isascii() and value.spelling.isdecimal(),
              "V2_CHARGE_TYPED_UINT_TOKEN_REFUSED")
    number = wire.uint(int(value.spelling))
    wire.need(str(number) == value.spelling, "V2_CHARGE_NONCANONICAL_UINT_REFUSED")
    return number


def _record_size(raw, guard):
    """Count the named native Go struct after its typed numeric decoding.

    All fields/omissions already passed the independent wire/policy replay.
    Maps and struct order do not affect size. Only Row numeric spellings are
    left as json.Number; actual uint fields use canonical decimal encoding.
    """
    value = rows._decode(raw, guard)
    kind = value["type"]
    if kind == "header":
        value["commit_count"] = _uint_token(value["commit_count"])
        coverage = value["history_coverage"]
        if coverage is not None:
            coverage["verified_commit_count"] = _uint_token(coverage["verified_commit_count"])
            coverage["events_attachment"]["rows"] = _uint_token(coverage["events_attachment"]["rows"])
            for boundary in coverage["boundaries"]:
                boundary["commit_ordinal_from_head"] = _uint_token(boundary["commit_ordinal_from_head"])
                if "commit_schema_version" in boundary:
                    boundary["commit_schema_version"] = _uint_token(boundary["commit_schema_version"])
                if "sql_dolt_codes" in boundary:
                    boundary["sql_dolt_codes"] = [_uint_token(code) for code in boundary["sql_dolt_codes"]]
    elif kind == "schema":
        for field in ("main_version", "ignored_version"):
            if value["profile"][field] is not None:
                value["profile"][field] = _uint_token(value["profile"][field])
        for table in value["tables"]:
            for column in table["columns"]:
                if column["primary_key_ordinal"] is not None:
                    column["primary_key_ordinal"] = _uint_token(column["primary_key_ordinal"])
    elif kind == "commit":
        value["sequence"] = _uint_token(value["sequence"])
    else:
        wire.need(kind == "row" and value["op"] in ("insert", "update"),
                  "V2_CHARGE_UNCOUNTED_RECORD_TYPE_REFUSED")
    return wire.add(_value_size(value, guard), 1)


def _base64_size(length):
    # JSON base64 strings contain no escaping beyond their two quote bytes.
    return wire.add(2, _times(4, (wire.uint(length) + 2) // 3))


def _staged_row_size(key, payload, normalized, column_count, guard):
    """NativeDeltaRow from staged first-parent disk row, Op reset to insert.

    Decode only this bounded binary row payload. Base64 fields are counted
    from their byte lengths, without constructing another encoded row.
    """
    wire.need(type(key) is bytes and type(payload) is bytes and type(normalized) is bytes,
              "V2_CHARGE_STAGED_ROW_TYPES_REFUSED")
    view, offset = memoryview(payload), 0

    def take_uint():
        nonlocal offset
        wire.need(offset + 8 <= len(view), "V2_CHARGE_PAYLOAD_TRUNCATED")
        result = int.from_bytes(view[offset:offset + 8], "big")
        offset += 8
        return result

    def take_string():
        nonlocal offset
        length = take_uint()
        end = wire.add(offset, length)
        wire.need(end <= len(view), "V2_CHARGE_PAYLOAD_TRUNCATED")
        result = bytes(view[offset:end]).decode("utf-8", "strict")
        offset = end
        return result

    count = take_uint()
    wire.need(count == column_count and count <= 1024, "V2_CHARGE_STAGED_CELL_WIDTH_REFUSED")
    cells_size = 2
    for index in range(count):
        guard()
        kind, value = take_string(), take_string()
        wire.need(kind in wire.CELL_KINDS, "V2_CHARGE_STAGED_CELL_KIND_REFUSED")
        cell_size = _value_size({"kind": kind, "value": value}, guard)
        cells_size = wire.add(cells_size, (1 if index else 0) + cell_size)
    length = take_uint()
    wire.need(length == len(normalized) and offset + length == len(view) and
              view[offset:] == normalized, "V2_CHARGE_STAGED_NORMALIZED_BINDING_MISMATCH")
    skeleton = {"type": "row", "op": "insert", "key": "", "cells": [], "normalized_json": ""}
    size = wire.add(_value_size(skeleton, guard), 1)
    # Replace exactly two empty JSON strings and one empty array.
    size = wire.add(size - 6, cells_size)
    size = wire.add(size, _base64_size(len(key)))
    return wire.add(size, _base64_size(len(normalized)))


class ReconstructionCharges:
    """One complete native reconstruction charge pass bound to actual bytes.

    Event sizes/counts stay in the existing guarded private replay DB. The
    source set is re-opened and independently authenticated through EOF; no
    receiver-reported categories or charge counts are input to computation.
    """

    def __init__(self, capture_set, replay, *, guard):
        self.capture_set, self.replay, self.guard = capture_set, replay, guard
        self.started = self.verified = False
        self.categories, self.counts = {}, {}
        self.events = self.total = 0
        self.state_id = self.opening = self.base = self.table = None
        self.event_hash = wire.domain_hash("caller-native-reconstruction-charge-events/1")

    def _charge(self, phase, size):
        self.guard()
        wire.need(phase in CATEGORIES, "V2_CHARGE_CATEGORY_REFUSED")
        size = wire.uint(size)
        ordinal = wire.add(self.events, 1)
        total = wire.add(self.total, size)
        category = wire.add(self.categories.get(phase, 0), size)
        count = wire.add(self.counts.get(phase, 0), 1)
        self.replay._execute("INSERT INTO accounting_reconstruction_events VALUES (?,?,?)",
                             (wire.u(ordinal), phase, wire.u(size)))
        self.event_hash.update(wire.u(ordinal))
        self.event_hash.update(wire.s(phase))
        self.event_hash.update(wire.u(size))
        self.events, self.total = ordinal, total
        self.categories[phase], self.counts[phase] = category, count

    def _profile(self):
        value = self.replay._one("SELECT raw FROM schemas WHERE id=?", (self.opening["schema_id"],))
        wire.need(value is not None, "V2_CHARGE_SCHEMA_MISSING")
        return wire.strict_json(value[0])["profile"]

    def _image_metadata_size(self):
        sequence = self.opening["sequence"] if self.opening["type"] == "commit" else 0
        value = {"sequence": sequence, "commit_id": self.opening["commit_id"],
                 "tables": {}, "schema_profile": self._profile()}
        return wire.add(_value_size(value, self.guard), 1)

    def _definition(self, name):
        value = self.replay._one("SELECT raw FROM definitions WHERE schema_id=? AND name=?",
                                 (self.opening["schema_id"], name))
        wire.need(value is not None, "V2_CHARGE_TABLE_DEFINITION_MISSING")
        return wire.strict_json(value[0])

    def _begin_state(self, record, raw):
        wire.need(self.state_id is None and self.table is None, "V2_CHARGE_NESTED_STATE_REFUSED")
        kind = record["type"]
        state_id = b"K" + wire.text(record["commit_id"]) if kind == "commit" else (
            b"H" if kind == "head-checkpoint" else b"C")
        known = self.replay._one("SELECT raw,kind,complete FROM states WHERE id=?", (state_id,))
        wire.need(known is not None and known == (raw, kind, 1),
                  "V2_CHARGE_REPLAY_STATE_BINDING_MISMATCH")
        self.state_id, self.opening = state_id, record
        self.base = None
        if kind == "commit":
            self._charge("commit_metadata", _record_size(raw, self.guard))
            if record["mode"] == "delta":
                base = self.replay._retained(record["base_commit"])
                wire.need(base is not None and base[1] == 1, "V2_CHARGE_BASE_STATE_MISSING")
                self.base = base[0]
        self._charge("image_metadata", self._image_metadata_size())

    def _begin_table(self, record):
        wire.need(self.state_id is not None and self.table is None, "V2_CHARGE_TABLE_ORDER_REFUSED")
        name = wire.text(record["name"])
        definition = self._definition(name)
        if record["mode"] == "delta":
            prior = self.replay._one("SELECT table_schema_id FROM state_tables WHERE state_id=? AND name=?",
                                     (self.base, name))
            wire.need(self.base is not None and prior is not None and
                      prior[0] == record["table_schema_id"], "V2_CHARGE_BASE_TABLE_BINDING_MISMATCH")
            for key, payload, normalized in self.replay._iter(
                    "SELECT key,payload,normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key",
                    (self.base, name)):
                size = _staged_row_size(key, payload, normalized, len(definition["columns"]), self.guard)
                self._charge("decoded_baseline_rows", size)
        self.table = (name, record)

    def _table_size(self, name, *, emit_rows):
        definition = self._definition(name)
        columns = sorted(column["name"] for column in definition["columns"])
        metadata = wire.add(_value_size({"columns": columns, "rows": []}, self.guard), 1)
        if emit_rows:
            self._charge("reconstructed_table_metadata", metadata)
        size, count = metadata - 1, 0
        for (normalized,) in self.replay._iter(
                "SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key", (self.state_id, name)):
            self.guard()
            fields = rows._decode(normalized, self.guard)
            wire.need(type(fields) is dict, "V2_CHARGE_NORMALIZED_OBJECT_REQUIRED")
            row_size = wire.add(_value_size(fields, self.guard), 1)
            wire.need(row_size == len(normalized), "V2_CHARGE_NORMALIZED_SIZE_MISMATCH")
            if emit_rows:
                self._charge("reconstructed_rows", row_size)
            size = wire.add(size, (1 if count else 0) + row_size - 1)
            count = wire.add(count, 1)
        actual = self.replay._one("SELECT rows FROM state_tables WHERE state_id=? AND name=?", (self.state_id, name))
        wire.need(actual is not None and int.from_bytes(actual[0], "big") == count,
                  "V2_CHARGE_TABLE_ROW_CENSUS_MISMATCH")
        return size

    def _end_table(self, record):
        wire.need(self.table is not None, "V2_CHARGE_TABLE_TERMINAL_ORDER_REFUSED")
        name, opening = self.table
        known = self.replay._one("SELECT rows,sha256 FROM state_tables WHERE state_id=? AND name=?",
                                 (self.state_id, name))
        wire.need(known is not None and int.from_bytes(known[0], "big") ==
                  record["rows"] == opening["expected_rows"] and
                  known[1] == record["sha256"] == opening["expected_sha256"],
                  "V2_CHARGE_TABLE_COMMITMENT_MISMATCH")
        self._table_size(name, emit_rows=True)
        self.table = None

    def _image_size(self):
        tables, count = 2, 0
        for (name,) in self.replay._iter("SELECT name FROM state_tables WHERE state_id=? ORDER BY name", (self.state_id,)):
            key_size = _text_size(name.decode("utf-8", "strict"), self.guard)
            tables = wire.add(tables, (1 if count else 0) + key_size + 1)
            tables = wire.add(tables, self._table_size(name, emit_rows=False))
            count = wire.add(count, 1)
        return wire.add(self._image_metadata_size() - 2, tables)

    def _proof_size(self):
        value = {"sequence": self.opening["sequence"], "commit_id": self.opening["commit_id"],
                 "schema_id": self.opening["schema_id"],
                 "root_sha256": self.opening["expected_root_sha256"], "tables": {}}
        size, count = wire.add(_value_size(value, self.guard), 1), 0
        for name, row_count, sha256 in self.replay._iter(
                "SELECT name,rows,sha256 FROM state_tables WHERE state_id=? ORDER BY name", (self.state_id,)):
            size = wire.add(size, (1 if count else 0) + _text_size(name.decode("utf-8", "strict"), self.guard) + 1)
            size = wire.add(size, _value_size({"Rows": int.from_bytes(row_count, "big"), "SHA256": sha256}, self.guard))
            count = wire.add(count, 1)
        return size

    def _end_state(self, kind):
        wire.need(self.state_id is not None and self.table is None and
                  kind == "end_" + self.opening["type"], "V2_CHARGE_STATE_TERMINAL_ORDER_REFUSED")
        size = self._image_size()
        if self.opening["type"] == "commit":
            self._charge("reconstructed_images", size)
            self.replay._execute("INSERT INTO accounting_reconstruction_images VALUES (?,?)",
                                 (self.state_id, wire.u(size)))
            self._charge("commit_proofs", self._proof_size())
        else:
            self._charge("checkpoints", size)
        self.state_id = self.opening = self.base = None

    def build(self):
        """Return partial per-pass expectations only after complete second EOF."""
        try:
            self.guard()
            original, replay = self.capture_set, self.replay
            wire.need(not self.started and type(original) is wire.CaptureSet and
                      type(replay) is semantic.SemanticReplay and original.root_fd is not None and
                      original.transport_verified and replay.structural_verified and replay.policy_verified,
                      "V2_CHARGE_AUTHENTICATED_POLICY_REPLAY_REQUIRED")
            self.started = True
            replay._execute("CREATE TABLE accounting_reconstruction_events(ordinal BLOB PRIMARY KEY,"
                            "phase TEXT NOT NULL,size BLOB NOT NULL) WITHOUT ROWID")
            replay._execute("CREATE TABLE accounting_reconstruction_images(state_id BLOB PRIMARY KEY,"
                            "size BLOB NOT NULL) WITHOUT ROWID")
            original._root_stable()
            self._charge("head_tar", original.root["head_archive"]["size"])
            self._charge("head_tar_copies", _times(2, original.root["head_archive"]["size"]))
            with wire.CaptureSet(str(original.directory), expected_store_id=original.root["store_id"],
                                 expected_projects=original.root["projects"], expected_head=original.root["head"],
                                 guard=self.guard) as source:
                wire.need(source.root_sha256 == original.root_sha256 and source.root == original.root,
                          "V2_CHARGE_REOPENED_ROOT_BINDING_MISMATCH")
                for record, raw in source.records():
                    self.guard()
                    kind = record["type"]
                    if kind in ("header", "schema"):
                        wire.need(self.state_id is None, "V2_CHARGE_METADATA_ORDER_REFUSED")
                        self._charge("header" if kind == "header" else "schemas", _record_size(raw, self.guard))
                    elif kind in ("commit", "head-checkpoint", "current"):
                        self._begin_state(record, raw)
                    elif kind == "table":
                        self._begin_table(record)
                    elif kind == "row":
                        wire.need(self.table is not None, "V2_CHARGE_ROW_CONTEXT_REQUIRED")
                        size = len(raw) if record["op"] == "delete" else _record_size(raw, self.guard)
                        self._charge("decoded_operations", size)
                    elif kind == "end_table":
                        self._end_table(record)
                    elif kind in ("end_commit", "end_head-checkpoint", "end_current"):
                        self._end_state(kind)
                    elif kind == "drop_table":
                        wire.need(self.state_id is not None and self.table is None,
                                  "V2_CHARGE_DROP_CONTEXT_REQUIRED")
                    else:
                        wire.need(kind == "end" and self.state_id is None and self.table is None,
                                  "V2_CHARGE_TERMINAL_ORDER_REFUSED")
                wire.need(source.transport_verified, "V2_CHARGE_SECOND_AUTHENTICATED_EOF_REQUIRED")
            # Exact duplicate charges made before aggregate image decoding.
            images, image_bytes = 0, 0
            for (size,) in replay._iter("SELECT a.size FROM accounting_reconstruction_images a "
                                       "JOIN commits c ON c.state_id=a.state_id ORDER BY c.sequence"):
                count = int.from_bytes(size, "big")
                self._charge("aggregate_images", count)
                images, image_bytes = wire.add(images, 1), wire.add(image_bytes, count)
            wire.need(images == original.root["totals"]["commits"] and
                      image_bytes == original.root["totals"]["full_image_bytes"],
                      "V2_CHARGE_FULL_IMAGE_COUNTER_MISMATCH")
            original._root_stable()
            replay.db.commit()
            self.verified = True
            return {"status": "ONE_RECONSTRUCTION_PASS_CHARGES_DERIVED_PARTIAL",
                    "accounting": ACCOUNTING, "receiver_source_schema_pin": RECEIVER_SOURCE,
                    "capture_set_sha256": original.root_sha256,
                    "categories": dict(self.categories), "charges": dict(self.counts),
                    "cumulative_pass_charge_bytes": self.total, "events": self.events,
                    "event_sha256": self.event_hash.hexdigest(),
                    "event_domain": "caller-native-reconstruction-charge-events/1",
                    "event_rows": "accounting_reconstruction_events",
                    "aggregate_image_bytes": image_bytes,
                    "receiver_reported_maps_used_as_inputs": False,
                    "whole_operation_pass_multiplicity": "PENDING_ORIGINAL_LIFECYCLE_BINDING",
                    "detached_history_lowering_ledger_and_envelope_categories": "PENDING",
                    "typed_refusal_prefix_matching": "PENDING",
                    "actual_receiver_rss": "SEPARATE_ORIGINAL_MEASUREMENT_REQUIRED",
                    "receiver_source_review_and_compiled_pair": "PENDING_SEPARATE_PROOF",
                    "full_receiving_category_recomputation": "PENDING",
                    "publication_authorized": False}
        except wire.Refusal:
            raise
        except (OSError, ValueError, KeyError, TypeError, OverflowError, UnicodeError,
                RecursionError, sqlite3.Error):
            raise wire.Refusal("V2_CHARGE_RECONSTRUCTION_FAULT") from None
