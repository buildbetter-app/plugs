"""Independent caller transport/hash layer for immutable D2 plus D3.

AUTHORED_NOT_RUN. This module is not a receiver, complete replay adapter,
procedure, or execution binding. Records remain untrusted until the caller
has consumed EOF, checked ``transport_verified``, replayed the graph and
cells, and reconciled the separately bound receiver/evidence receipts.

Contract: D2 7d44af86416ee72d0feb3c4e71818ceb98010d8f20652bd3c8476a68d100288c
Amendment: D3 96a1a79ed42d3f8942a4d574091f6181ae61c746bcc0ec1d65b0a1617bb2b2b6
Wire: 1134f49bf52bfd72a2f18a72d69ca1d7daacc18a1d44b45fadff4cb6662cbfc5

There is no aggregate wire-size limit. File/record bounds and checked uint64
counters are distinct from the receiver's temporary decoded-size ceiling.
All external failures contain fixed codes; source names/values never enter
an exception message. The class reads only its explicitly owned set root.
"""

import base64
import binascii
import decimal
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct


UINT64_MAX = (1 << 64) - 1
PART_BYTES = 64 << 20
RECORD_BYTES = 128 << 20
ROOT_BYTES = 1 << 20
HEADER_BYTES = 4096
HEAD_BYTES = 128 << 20
READ_BYTES = 1 << 20
CONTRACT = "beads-native-delta/2"
SET_FORMAT = "beads-native-capture-set/2"
PART_FORMAT = "beads-native-part/2"
EVIDENCE_FORMAT = "beads-physical-evidence/2"
TOTAL_FIELDS = frozenset(("schemas", "commits", "table_transactions",
                          "row_operations", "reconstructed_rows",
                          "reconstructed_cells", "full_image_bytes"))
CELL_KINDS = frozenset(("sql-null", "string", "string-bytes", "bytes", "bool",
                       "int", "int8", "int16", "int32", "int64", "uint",
                       "uint8", "uint16", "uint32", "uint64", "float32-bits",
                       "float64-bits", "time", "secret-reference"))
HEX = re.compile(r"[0-9a-f]{64}\Z")
UNSIGNED = re.compile(r"(?:0|[1-9][0-9]*)\Z")


class Refusal(Exception):
    """A fixed caller code, never raw decoder/filesystem text."""


def need(condition, code):
    if not condition:
        raise Refusal(code)


class JSONInteger(int):
    """Retain the spelling so a uint64 field cannot accept JSON -0."""

    def __new__(cls, spelling):
        result = int.__new__(cls, spelling)
        result.spelling = spelling
        return result


def uint(value):
    need(type(value) in (int, JSONInteger), "V2_UINT64_TYPE_REFUSED")
    if isinstance(value, JSONInteger):
        need(UNSIGNED.fullmatch(value.spelling) is not None,
             "V2_UINT64_SPELLING_REFUSED")
    need(0 <= value <= UINT64_MAX, "V2_UINT64_RANGE_REFUSED")
    return int(value)


def add(left, right):
    result = uint(left) + uint(right)
    need(result <= UINT64_MAX, "V2_COUNTER_OVERFLOW")
    return result


def text(value, *, empty=False):
    need(type(value) is str and (empty or bool(value)), "V2_STRING_REFUSED")
    try:
        return value.encode("utf-8", "strict")
    except UnicodeError:
        raise Refusal("V2_UTF8_REFUSED") from None


def digest(value):
    need(type(value) is str and HEX.fullmatch(value) is not None,
         "V2_SHA256_REFUSED")
    return bytes.fromhex(value)


def fields(value, required, optional=()):
    need(type(value) is dict and set(required) <= value.keys() <=
         set(required) | set(optional), "V2_OBJECT_FIELDS_REFUSED")


def array(value):
    need(type(value) is list, "V2_ARRAY_REFUSED")
    return value


def strict_json(raw):
    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, "V2_DUPLICATE_JSON_KEY")
            result[name] = value
        return result

    def nonfinite(_):
        raise Refusal("V2_NONFINITE_JSON_REFUSED")

    try:
        value = json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs,
                           parse_int=JSONInteger, parse_float=decimal.Decimal,
                           parse_constant=nonfinite)
        # json.loads accepts escaped lone surrogates; Go wire strings do not.
        todo = [value]
        while todo:
            item = todo.pop()
            if isinstance(item, str):
                text(item, empty=True)
            elif type(item) is dict:
                todo.extend(item.keys())
                todo.extend(item.values())
            elif type(item) is list:
                todo.extend(item)
        return value
    except Refusal:
        raise
    except (ValueError, UnicodeError, RecursionError, decimal.InvalidOperation):
        raise Refusal("V2_JSON_REFUSED") from None


def b64(value, *, nonempty=False):
    text(value, empty=not nonempty)
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        raise Refusal("V2_BASE64_REFUSED") from None
    need(base64.b64encode(raw).decode("ascii") == value and
         (not nonempty or bool(raw)), "V2_BASE64_CANONICAL_REFUSED")
    return raw


def u(value):
    return struct.pack(">Q", uint(value))


def b(value):
    need(type(value) is bytes, "V2_BINARY_OPERAND_REFUSED")
    return u(len(value)) + value


def s(value):
    return b(text(value, empty=True))


def optional(value):
    return b"\x00" if value is None else b"\x01" + u(value)


def domain_hash(domain):
    result = hashlib.sha256()
    result.update(domain.encode("ascii") + b"\x00")
    return result


def table_schema(table):
    fields(table, ("name", "columns"))
    text(table["name"])
    names, ordinals = set(), []
    for column in array(table["columns"]):
        fields(column, ("name", "sql_type", "primary_key_ordinal"))
        text(column["name"])
        text(column["sql_type"])
        need(column["name"] not in names, "V2_DUPLICATE_COLUMN")
        names.add(column["name"])
        if column["primary_key_ordinal"] is not None:
            ordinals.append(uint(column["primary_key_ordinal"]))
    need(sorted(ordinals) == list(range(len(ordinals))),
         "V2_PRIMARY_KEY_ORDINALS_REFUSED")
    return table


def table_schema_id(table):
    table_schema(table)
    result = domain_hash("beads-native-table-schema/2")
    result.update(s(table["name"]))
    result.update(u(len(table["columns"])))
    for column in table["columns"]:
        result.update(s(column["name"]))
        result.update(s(column["sql_type"]))
        result.update(optional(column["primary_key_ordinal"]))
    return result.hexdigest()


def profile(value):
    fields(value, ("format", "scope", "main_version", "ignored_version", "absences"))
    text(value["format"])
    text(value["scope"])
    for key in ("main_version", "ignored_version"):
        if value[key] is not None:
            uint(value[key])
    previous = None
    for absence in array(value["absences"]):
        fields(absence, ("family", "reason"), ("column",))
        family, reason = text(absence["family"]), text(absence["reason"])
        column = text(absence["column"]) if "column" in absence else b""
        # D3: an empty column is represented by omission, never explicit "".
        current = (family, column, reason)
        need(previous is None or previous < current, "V2_ABSENCE_ORDER_REFUSED")
        previous = current
    return value


def schema_id(schema):
    fields(schema, ("type", "schema_id", "profile", "tables"))
    need(schema["type"] == "schema", "V2_SCHEMA_TYPE_REFUSED")
    p = profile(schema["profile"])
    result = domain_hash("beads-native-schema/2")
    result.update(s(p["format"]))
    result.update(s(p["scope"]))
    result.update(optional(p["main_version"]))
    result.update(optional(p["ignored_version"]))
    result.update(u(len(p["absences"])))
    for absence in p["absences"]:
        for name in ("family", "column", "reason"):
            result.update(s(absence.get(name, "")))
    result.update(u(len(array(schema["tables"]))))
    previous = None
    for table in schema["tables"]:
        current = text(table["name"])
        need(previous is None or previous < current, "V2_SCHEMA_TABLE_ORDER_REFUSED")
        previous = current
        result.update(s(table["name"]))
        result.update(bytes.fromhex(table_schema_id(table)))
    return result.hexdigest()


def cells(value):
    for cell in array(value):
        fields(cell, ("kind", "value"))
        need(cell["kind"] in CELL_KINDS, "V2_CELL_KIND_REFUSED")
        text(cell["value"], empty=True)
    return value


def row_payload(row_cells, normalized):
    cells(row_cells)
    need(type(normalized) is bytes and normalized.endswith(b"\n"),
         "V2_NORMALIZED_ROW_NEWLINE_REFUSED")
    result = bytearray(u(len(row_cells)))
    for cell in row_cells:
        result.extend(s(cell["kind"]))
        result.extend(s(cell["value"]))
    result.extend(b(normalized))
    return bytes(result)


def primary_key(table, row_cells):
    table_schema(table)
    cells(row_cells)
    need(len(row_cells) == len(table["columns"]), "V2_CELL_WIDTH_REFUSED")
    ordered = []
    for column, cell in zip(table["columns"], row_cells):
        ordinal = column["primary_key_ordinal"]
        if ordinal is not None:
            need(cell["kind"] not in ("sql-null", "secret-reference"),
                 "V2_PRIMARY_KEY_CELL_REFUSED")
            ordered.append((uint(ordinal), cell))
    if not ordered:
        return None
    result = bytearray(b"pk\x00" + u(len(ordered)))
    for _, cell in sorted(ordered, key=lambda item: item[0]):
        result.extend(s(cell["kind"]))
        result.extend(s(cell["value"]))
    return bytes(result)


def bag_key(payload, occurrence):
    need(type(payload) is bytes, "V2_BINARY_OPERAND_REFUSED")
    return b"bag\x00" + hashlib.sha256(payload).digest() + u(occurrence)


def table_hash(table, expected_rows, rows):
    """Stream validated (raw_key, row_payload) pairs; do not collect a table."""
    result = domain_hash("beads-native-table/2")
    result.update(bytes.fromhex(table_schema_id(table)))
    result.update(u(expected_rows))
    previous, count = None, 0
    for key, payload in rows:
        need(type(key) is bytes and bool(key) and type(payload) is bytes,
             "V2_TABLE_ROW_OPERANDS_REFUSED")
        need(previous is None or previous < key, "V2_TABLE_KEY_ORDER_REFUSED")
        # Hash prefixes and bytes separately instead of copying a whole row.
        result.update(u(len(key)))
        result.update(key)
        result.update(u(len(payload)))
        result.update(payload)
        previous, count = key, add(count, 1)
    need(count == uint(expected_rows), "V2_TABLE_ROW_COUNT_MISMATCH")
    return result.hexdigest()


def state_hash(tables):
    """Stream sorted (name, table_sha256, row_count) triples."""
    result, previous = domain_hash("beads-native-commit/2"), None
    for name, table_digest, count in tables:
        current = text(name)
        need(previous is None or previous < current, "V2_STATE_TABLE_ORDER_REFUSED")
        previous = current
        result.update(s(name))
        result.update(digest(table_digest))
        result.update(u(count))
    return result.hexdigest()


def totals(value):
    fields(value, TOTAL_FIELDS)
    for number in value.values():
        uint(number)
    return value


def identity(value):
    text(value["store_id"])
    for project in array(value["projects"]):
        text(project)
    text(value["head"])


def coverage(value):
    if value is None:
        return
    fields(value, ("format", "status", "verified_commit_count", "boundaries",
                   "events_attachment"))
    text(value["format"])
    text(value["status"])
    uint(value["verified_commit_count"])
    for boundary in array(value["boundaries"]):
        fields(boundary, ("commit_id", "child_commit_ids", "commit_ordinal_from_head", "reason"),
               ("commit_schema_version", "sql_dolt_codes"))
        text(boundary["commit_id"])
        for child in array(boundary["child_commit_ids"]):
            text(child)
        need(uint(boundary["commit_ordinal_from_head"]) >= 1,
             "V2_BOUNDARY_ORDINAL_REFUSED")
        need(boundary["reason"] in ("ghost_parent", "missing_root_chunk",
             "missing_table_chunk", "missing_archive_chunk", "unreadable_schema", "other"),
             "V2_BOUNDARY_REASON_REFUSED")
        if "commit_schema_version" in boundary:
            uint(boundary["commit_schema_version"])
        if "sql_dolt_codes" in boundary:
            codes = [uint(code) for code in array(boundary["sql_dolt_codes"])]
            need(bool(codes) and codes == sorted(set(codes)) and
                 all(1 <= code <= 65535 for code in codes), "V2_BOUNDARY_SQL_CODES_REFUSED")
    attachment = value["events_attachment"]
    fields(attachment, ("member", "sha256", "rows"))
    text(attachment["member"])
    digest(attachment["sha256"])
    uint(attachment["rows"])


def record_shape(value):
    """Closed record grammar only; graph/cell/operation replay is separate."""
    need(type(value) is dict and type(value.get("type")) is str,
         "V2_RECORD_TYPE_REFUSED")
    kind = value["type"]
    if kind == "header":
        fields(value, ("type", "format", "store_id", "projects", "head",
                       "commit_count", "history_coverage", "ignore", "config_policy"))
        need(value["format"] == CONTRACT, "V2_HEADER_FORMAT_REFUSED")
        identity(value)
        uint(value["commit_count"])
        coverage(value["history_coverage"])
        ignore = value["ignore"]
        fields(ignore, ("columns", "rows"))
        for column in array(ignore["columns"]):
            text(column)
        need(len(set(ignore["columns"])) == len(ignore["columns"]),
             "V2_IGNORE_COLUMNS_REFUSED")
        for row in array(ignore["rows"]):
            need(type(row) is dict and row.keys() == set(ignore["columns"]),
                 "V2_IGNORE_ROW_FIELDS_REFUSED")
        need(type(value["config_policy"]) is dict, "V2_CONFIG_POLICY_REFUSED")
        for key, policy in value["config_policy"].items():
            text(key)
            need(policy in ("public", "secret"), "V2_CONFIG_POLICY_VALUE_REFUSED")
    elif kind == "schema":
        need(schema_id(value) == digest(value["schema_id"]).hex(),
             "V2_SCHEMA_ID_MISMATCH")
    elif kind == "commit":
        fields(value, ("type", "sequence", "commit_id", "parents", "first_parent",
                       "metadata", "schema_id", "mode", "base_commit", "expected_root_sha256"))
        need(uint(value["sequence"]) >= 1, "V2_COMMIT_SEQUENCE_REFUSED")
        text(value["commit_id"])
        for parent in array(value["parents"]):
            text(parent)
        for key in ("first_parent", "base_commit"):
            if value[key] is not None:
                text(value[key])
        need(type(value["metadata"]) is dict, "V2_METADATA_OBJECT_REFUSED")
        digest(value["schema_id"])
        digest(value["expected_root_sha256"])
        need(value["mode"] in ("snapshot", "delta"), "V2_COMMIT_MODE_REFUSED")
    elif kind in ("head-checkpoint", "current"):
        fields(value, ("type", "commit_id", "schema_id", "expected_root_sha256"))
        text(value["commit_id"])
        digest(value["schema_id"])
        digest(value["expected_root_sha256"])
    elif kind == "table":
        fields(value, ("type", "name", "table_schema_id", "mode", "expected_rows", "expected_sha256"))
        text(value["name"])
        digest(value["table_schema_id"])
        digest(value["expected_sha256"])
        uint(value["expected_rows"])
        need(value["mode"] in ("replace", "delta"), "V2_TABLE_MODE_REFUSED")
    elif kind == "row":
        if value.get("op") == "delete":
            fields(value, ("type", "op", "key"))
        else:
            fields(value, ("type", "op", "key", "cells", "normalized_json"))
            need(value["op"] in ("insert", "update"), "V2_ROW_OP_REFUSED")
            cells(value["cells"])
            normalized = b64(value["normalized_json"], nonempty=True)
            need(normalized.endswith(b"\n") and type(strict_json(normalized)) is dict,
                 "V2_NORMALIZED_ROW_OBJECT_REFUSED")
        b64(value["key"], nonempty=True)
    elif kind == "drop_table":
        fields(value, ("type", "name", "previous_table_schema_id"))
        text(value["name"])
        digest(value["previous_table_schema_id"])
    elif kind == "end_table":
        fields(value, ("type", "row_operations", "rows", "sha256"))
        uint(value["row_operations"])
        uint(value["rows"])
        digest(value["sha256"])
    elif kind == "end_commit":
        fields(value, ("type", "sequence", "commit_id", "table_count", "root_sha256"))
        need(uint(value["sequence"]) >= 1, "V2_COMMIT_SEQUENCE_REFUSED")
        text(value["commit_id"])
        uint(value["table_count"])
        digest(value["root_sha256"])
    elif kind in ("end_head-checkpoint", "end_current"):
        fields(value, ("type", "table_count", "root_sha256"))
        uint(value["table_count"])
        digest(value["root_sha256"])
    elif kind == "end":
        fields(value, ("type", "totals", "head_root_sha256", "current_root_sha256"))
        totals(value["totals"])
        digest(value["head_root_sha256"])
        digest(value["current_root_sha256"])
    else:
        raise Refusal("V2_RECORD_TYPE_REFUSED")
    return value


def root_shape(value):
    fields(value, ("format", "contract", "store_id", "projects", "head", "head_archive",
                   "part_count", "final_part_sha256", "stream_sha256", "stream_bytes", "totals"))
    need(value["format"] == SET_FORMAT and value["contract"] == CONTRACT,
         "V2_SET_FORMAT_REFUSED")
    identity(value)
    fields(value["head_archive"], ("sha256", "size"))
    digest(value["head_archive"]["sha256"])
    need(uint(value["head_archive"]["size"]) <= HEAD_BYTES, "V2_HEAD_ARCHIVE_SIZE_REFUSED")
    need(uint(value["part_count"]) >= 1, "V2_PART_COUNT_REFUSED")
    need(uint(value["stream_bytes"]) >= 1, "V2_STREAM_BYTES_REFUSED")
    digest(value["final_part_sha256"])
    digest(value["stream_sha256"])
    totals(value["totals"])
    return value


def _signature(info):
    return (info.st_dev, info.st_ino, info.st_uid, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class CaptureSet:
    """One-pass owned-set reader, without a total wire cap or file-name list.

    Use as a context manager and exhaust records(). Staging callers must not
    publish from yielded records. Only after EOF is transport_verified true;
    semantic replay and receiver/evidence reconciliation remain mandatory.
    """

    def __init__(self, directory, *, expected_store_id, expected_projects,
                 expected_head=None, guard=lambda: None):
        self.directory = Path(directory)
        self.expected_store_id = expected_store_id
        self.expected_projects = list(expected_projects)
        self.expected_head = expected_head
        self.guard = guard
        self.root_fd = self.parts_fd = None
        self.started = False
        self.transport_verified = False
        self.records_seen = 0

    def __enter__(self):
        try:
            need(self.directory.is_absolute() and
                 self.directory.resolve(strict=True) == self.directory,
                 "V2_SET_CANONICAL_PATH_REFUSED")
            self.guard()
            self.root_fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY |
                                   os.O_NOFOLLOW | os.O_CLOEXEC)
            self.root_info = os.fstat(self.root_fd)
            need(self.root_info.st_uid == os.getuid(), "V2_SET_OWNER_REFUSED")
            seen = set()
            with os.scandir(self.root_fd) as entries:
                for entry in entries:
                    self.guard()
                    need(entry.name in ("capture-set.json", "head.tar", "parts"),
                         "V2_SET_ENTRY_REFUSED")
                    seen.add(entry.name)
            need(seen == {"capture-set.json", "head.tar", "parts"}, "V2_SET_ENTRY_MISSING")
            self.root_raw = self._small_file("capture-set.json", ROOT_BYTES)
            self.root_sha256 = hashlib.sha256(self.root_raw).hexdigest()
            self.root = root_shape(strict_json(self.root_raw))
            need(self.root["store_id"] == self.expected_store_id and
                 self.root["projects"] == self.expected_projects and
                 (self.expected_head is None or self.root["head"] == self.expected_head),
                 "V2_CALLER_IDENTITY_MISMATCH")
            self._head_archive()
            self.parts_fd = os.open("parts", os.O_RDONLY | os.O_DIRECTORY |
                                    os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.root_fd)
            need(os.fstat(self.parts_fd).st_uid == os.getuid(), "V2_PARTS_OWNER_REFUSED")
            count = 0
            with os.scandir(self.parts_fd) as entries:
                for entry in entries:
                    self.guard()
                    name = entry.name
                    need(re.fullmatch(r"[0-9]{20}\.part", name) is not None,
                         "V2_PART_FILENAME_REFUSED")
                    sequence = int(name[:20])
                    need(1 <= sequence <= self.root["part_count"], "V2_PART_FILENAME_REFUSED")
                    count = add(count, 1)
            need(count == self.root["part_count"], "V2_PART_DIRECTORY_COUNT_MISMATCH")
            return self
        except Refusal:
            self.close()
            raise
        except (OSError, ValueError):
            self.close()
            raise Refusal("V2_SET_OPEN_REFUSED") from None

    def close(self):
        for name in ("parts_fd", "root_fd"):
            fd = getattr(self, name)
            if fd is not None:
                os.close(fd)
                setattr(self, name, None)

    def __exit__(self, *_):
        self.close()

    def _regular(self, name, parent=None):
        self.guard()
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                     dir_fd=self.root_fd if parent is None else parent)
        info = os.fstat(fd)
        if not (stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()):
            os.close(fd)
            raise Refusal("V2_REGULAR_OWNED_FILE_REFUSED")
        return fd, info

    def _stable(self, fd, before):
        need(_signature(os.fstat(fd)) == _signature(before), "V2_FILE_CHANGED_DURING_READ")

    def _root_stable(self):
        self.guard()
        after = os.stat(self.directory, follow_symlinks=False)
        need(_signature(after) == _signature(self.root_info),
             "V2_SET_ROOT_IDENTITY_CHANGED")

    def _small_file(self, name, ceiling):
        fd, before = self._regular(name)
        try:
            need(before.st_size <= ceiling, "V2_SMALL_FILE_LIMIT_REFUSED")
            data = bytearray()
            while True:
                self.guard()
                chunk = os.read(fd, min(READ_BYTES, ceiling + 1 - len(data)))
                if not chunk:
                    break
                need(len(data) + len(chunk) <= ceiling, "V2_SMALL_FILE_LIMIT_REFUSED")
                data.extend(chunk)
            self._stable(fd, before)
            need(len(data) == before.st_size, "V2_FILE_LENGTH_MISMATCH")
            return bytes(data)
        finally:
            os.close(fd)

    def _head_archive(self):
        fd, before = self._regular("head.tar")
        try:
            head = self.root["head_archive"]
            need(before.st_size == head["size"] <= HEAD_BYTES, "V2_HEAD_ARCHIVE_SIZE_REFUSED")
            result, size = hashlib.sha256(), 0
            while True:
                self.guard()
                chunk = os.read(fd, READ_BYTES)
                if not chunk:
                    break
                size = add(size, len(chunk))
                need(size <= head["size"], "V2_HEAD_ARCHIVE_SIZE_REFUSED")
                result.update(chunk)
            self._stable(fd, before)
            need(size == head["size"] and result.hexdigest() == head["sha256"],
                 "V2_HEAD_ARCHIVE_HASH_MISMATCH")
        finally:
            os.close(fd)

    def _part_header(self, fd):
        line = bytearray()
        while True:
            self.guard()
            need(len(line) < HEADER_BYTES, "V2_PART_HEADER_LIMIT_REFUSED")
            byte = os.read(fd, 1)
            need(bool(byte), "V2_PART_HEADER_TRUNCATED")
            line.extend(byte)
            if byte == b"\n":
                break
        return bytes(line)

    def _payload_chunks(self):
        previous, total = None, 0
        stream_hash = hashlib.sha256()
        for sequence in range(1, self.root["part_count"] + 1):
            self._root_stable()
            fd, before = self._regular(f"{sequence:020d}.part", self.parts_fd)
            try:
                line = self._part_header(fd)
                header = strict_json(line)
                fields(header, ("format", "sequence", "previous_part_sha256",
                                "payload_bytes", "payload_sha256"))
                need(header["format"] == PART_FORMAT and uint(header["sequence"]) == sequence,
                     "V2_PART_SEQUENCE_REFUSED")
                if header["previous_part_sha256"] is not None:
                    digest(header["previous_part_sha256"])
                need(header["previous_part_sha256"] == previous, "V2_PART_CHAIN_MISMATCH")
                remaining = uint(header["payload_bytes"])
                need(1 <= remaining <= PART_BYTES and
                     (sequence == self.root["part_count"] or remaining == PART_BYTES),
                     "V2_PART_PAYLOAD_SIZE_REFUSED")
                need(before.st_size == len(line) + remaining, "V2_PART_FILE_SIZE_MISMATCH")
                digest(header["payload_sha256"])
                part_hash, payload_hash = hashlib.sha256(line), hashlib.sha256()
                while remaining:
                    self.guard()
                    chunk = os.read(fd, min(READ_BYTES, remaining))
                    need(bool(chunk), "V2_PART_PAYLOAD_TRUNCATED")
                    remaining -= len(chunk)
                    total = add(total, len(chunk))
                    part_hash.update(chunk)
                    payload_hash.update(chunk)
                    stream_hash.update(chunk)
                    yield chunk
                need(not os.read(fd, 1), "V2_PART_TRAILING_BYTES_REFUSED")
                self._stable(fd, before)
                need(payload_hash.hexdigest() == header["payload_sha256"],
                     "V2_PART_PAYLOAD_HASH_MISMATCH")
                previous = part_hash.hexdigest()
            finally:
                os.close(fd)
        need(previous == self.root["final_part_sha256"], "V2_FINAL_PART_HASH_MISMATCH")
        need(total == self.root["stream_bytes"] and
             stream_hash.hexdigest() == self.root["stream_sha256"], "V2_STREAM_HASH_MISMATCH")
        self._root_stable()

    def records(self):
        """Yield (closed_shape_record, exact_record_bytes), one bounded line."""
        need(self.root_fd is not None and not self.started, "V2_TRANSPORT_ALREADY_CONSUMED")
        self.started = True
        buffer, ended = bytearray(), False
        try:
            for chunk in self._payload_chunks():
                start = 0
                while start < len(chunk):
                    stop = chunk.find(b"\n", start)
                    end = len(chunk) if stop < 0 else stop + 1
                    need(len(buffer) + end - start <= RECORD_BYTES, "V2_LOGICAL_RECORD_LIMIT_REFUSED")
                    buffer.extend(memoryview(chunk)[start:end])
                    start = end
                    if stop < 0:
                        continue
                    need(not ended, "V2_RECORD_AFTER_END_REFUSED")
                    raw = bytes(buffer)
                    buffer.clear()
                    value = record_shape(strict_json(raw))
                    self.records_seen = add(self.records_seen, 1)
                    if self.records_seen == 1:
                        need(value["type"] == "header", "V2_FIRST_RECORD_NOT_HEADER")
                        need(all(value[key] == self.root[key] for key in ("store_id", "projects", "head")) and
                             value["commit_count"] == self.root["totals"]["commits"],
                             "V2_HEADER_ROOT_MISMATCH")
                    else:
                        need(value["type"] != "header", "V2_REPEATED_HEADER_REFUSED")
                    if value["type"] == "end":
                        need(value["totals"] == self.root["totals"], "V2_END_ROOT_TOTALS_MISMATCH")
                        ended = True
                    yield value, raw
            need(not buffer, "V2_FINAL_RECORD_NEWLINE_REQUIRED")
            need(ended, "V2_END_RECORD_MISSING")
            self.transport_verified = True
        except Refusal:
            raise
        except (OSError, ValueError, KeyError, TypeError, OverflowError, RecursionError):
            raise Refusal("V2_TRANSPORT_READ_REFUSED") from None
