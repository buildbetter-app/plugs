# Typed-wire integer correction to reconstruction accounting

AUTHORED_NOT_RUN. This separately named successor preserves the original96089586
source and its immutable bounded review. The original has a concrete caller
source blocker: wire.strict_json uses parse_int=JSONInteger, a subclass of int,
but _value_size uses type(value) is int. Original sequence values and the
main_version/ignored_version values returned by _profile reach that exact-type
branch without conversion, so valid non-null versions and commit sequences
refuse with V2_CHARGE_JSON_TYPE_REFUSED before receiving. No function was run
to establish this; it follows from the bound AST/data flow.

The sole source-line change allows type(value) in (int, wire.JSONInteger).
Both still pass wire.uint before canonical decimal size is counted. This
preserves uint64 range and original unsigned spelling checks (including -0
refusal). SQL JSON/normalized row numbers still use the separate rows._Number
branch and preserve original spelling; bool has its existing prior branch.
There is no permissive isinstance numeric conversion, float path, change to
any category, or change to the per-pass scope. The exact fourteen-category
reconstruction calculation, second EOF and disk preimages are otherwise
parent-exact. Receiver26e schema source references and seven dependencies
remain bound to the original delivered bytes.

The existing frozen pair harness d9346643 selects original960 by module name;
it inherits this source blocker until a separately named harness/overlay
successor selects this corrected module. All original sources, overlays and
receipts stay immutable. Ordinary source review/integration proceed in the
existing lane without a new ACK or whole-result hold. The real pair remains
NOT_RUN here; no source result is runtime credit.

Validation: standard-library AST parsing, exact one-line source comparison,
Git-object reference/hash checks and file metadata only. No supplied module,
function, SQL, fixture, compiler, test, product or ELF executed. No collector
query, retry, gate, worker, public/private dispatch, repository edit or commit.
Full receiving multiplicity, eight other categories, refusal/admission,
persistent readback, numeric/time conformance, final procedure and fresh1200
loose/archive cases remain pending. Publication is false; private HARD_DISABLED,
item4 PAUSED, c75 STOP_ALL and both consumed R5 NOT_PASS remain unchanged.
