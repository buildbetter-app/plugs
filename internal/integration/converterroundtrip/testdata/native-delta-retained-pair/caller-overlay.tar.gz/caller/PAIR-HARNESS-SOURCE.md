# Retained genuine native pair harness source

AUTHORED_NOT_RUN. This supplies the concrete existing pair harness requested by
036 and the controller. Both new sources are outside the repository; 036 owns
their integration into the existing ordinary converterroundtrip test and data
route. No Test entry point, workflow, gate, worker, collector or production CLI
is added here. Existing execution authorization is retained; this source handoff
does not dispatch anything. Source review remains the normal finite lane.

The fixed genuine inputs are producer1a75f75f/tree6ee2f640/sole295ba4e4 and
receiver26e90d85/tree95b117fb/solec26e87d6. Producer ELFf24314b9 and receiver
ELF19bdf3a4 are byte-bound, together with all32 genuine retained capture files.
The exact three-entry set is producer/output/capture-set; inventory/evidence and
sidecars stay siblings. This is the32-commit/6-schema physical capture with a
79,209,683-byte old-full-image equivalent, single/multi-leaf descriptions and a
genuine CREATE VIEW through history. It is not either1200-commit public case.

The new Python CLI interface is:

```
python3 BUNDLE/caller/native_delta_pair_harness_v2.py --bundle ABS_COMBINED_ROOT --manifest-sha256 HASH --manifest-bytes N --output ABS_ABSENT_OWNED_DIR
```

The ordinary test validates/extracts036's unchanged deterministic base bundle
d879a0b2 and this small caller/policy overlay into one fresh owned root. The
overlay's manifest.json describes the exact combined regular-file census and
every SHA256/size, including the base INPUTS.json and receipts. Neither archive
is a native wire aggregate limit. No privileged public-reference helper or
workflow transfer hook is repurposed. The Go companion source is copied into
the ordinary test package/BUILD by its owner, as part of the same source step.

Before importing helpers, the Python entrypoint binds the combined manifest,
exact helper/ELF bytes, owned regular frozen files and directory edges. It copies
the receiver to an owned0500 executable, retaining its exact digest. The complete
SemanticReplay (mandatory semantic callback) and corrected d9 attachment module
reconstruct and reconcile the capture. d9 uses manifest available-unverified
for attached source history and independently row-derived inventory history;
their equality is not required. AR33-F1 remains withdrawn. Exact three physical
exceptions are inert, including nonempty nonlocal; no definition SQL is parsed
or executed. The reconstruction960 helper calculates only its reviewed14-category
one-pass slice. It never becomes the full22-category usage expectation.

For memory then SQLite, the harness launches the actual prepare-request and
default native-receive commands, with exact policy/root/binary bindings. The
constructor stdout bytes become the request file unchanged. The decoded limit
flag is omitted, retaining the actual default2GiB/origin default. File-backed
stdout/stderr have no total wire/evidence cap. Each direct child has actual PID,
argv, direct wait/exit, monotonic elapsed and wall-clock endpoints; only that
owned process group is terminated on guard/timeout. The inherited environment
is passed without overlay; values are not logged. Originals are synced, closed,
frozen0444 and hashed before parsing. Any nonzero exit stays a refused pair;
its originals remain for the ordinary collector, with no unchanged retry.

Stable case paths are OUTPUT/{memory,sqlite}/constructor.{stdout,stderr,argv.json,
wait.json} and receive.{stdout,stderr,argv.json,wait.json}. Each has whole-file
bindings in constructor.originals.json / receive.originals.json. Existing1855
extractor compares every commit/table proof and totals against independent disk
states. Receiver RSS stays the actual RUSAGE_SELF measurement, separate from
logical charge and wrapper measurement. Restore time is explicitly a captured
nondeterministic original scalar, checked inside the actual child wall-clock
interval; it is not an independently predicted timestamp. The Go companion
must also match it to the recovered persistent profile.

Each case's expected/manifest.json binds expected/readback.ndjson and a body
file for each present table, generated one table at a time from disk-normalized
rows in key order, with sorted columns. Every immutable commit and current state
has schema/root/table commitments, source/imported counts, and explicit absence
over the complete state-table union. Current leases are filtered against the
actual admitted restore clock. All typed originals remain in root/head/parts;
body comparison alone does not reconstruct physical SQL types. The manifest's
binding is also in expectation-binding.json and HARNESS-RESULT.json.

OUTPUT/sqlite/retained.sqlite is the actual default receiver's completed,
published file. After direct wait the harness requires no WAL/SHM/journal
sidecars, freezes it0444 and writes retained-target.json. The Go companion
inspectRetainedNativePair(t, CASE_DIR, EXPECTATION_MANIFEST_BINDING) preserves
that file and opens an exact writable copy in CASE_DIR/inspection-copy through
the supported SQLite driver. Driver Open may write initialization/WAL setup;
only recovery/read APIs are used afterward. The original stays byte-exact.

The companion checks recovered explicit constructor policy/source plan and
admission selection (not host authentication); actual restore clock; logical
metadata before/after; complete source-to-target revision mappings/frontier;
every present and absent table at its mapped revision; current family history,
source/imported/expired counts; and every retained original root/head/part blob.
This includes dolt_schemas absence and exact view-family rows through history,
and full large description values via independent expected body hashes/bytes.
It writes persistent-readback.ndjson and persistent-readback-result.json,
retaining the inspection clone and any sidecars actually surviving Close.
The file/image arrays are not accumulated across historical states. The driver
does return a complete individual record; no new lower-layer streaming API or
heap-bound claim is made. Raw reverse/undo originals are compared, but no reverse
converter or undo operation is executed by these sources.

All Python/Go result publication_authorized fields are false. Python success is
explicitly partial until companion/integration evidence exists. Full independent
business mapper/verification/config-sidecars/ontology/allocator semantics, all
22 accounting preimages and actual lifecycle multiplicity/refusal prefixes,
numeric/time conformance controls, actual genuine pair execution/original review,
final procedure and both fresh1200 cases remain pending. Source/ELF/focused/whole
evidence does not transfer to those results. Both prior R5 NOT_PASS, private
HARD_DISABLED, item4 PAUSED and c75 STOP_ALL remain literal.

Validation here: Python standard-library AST parsing, source/API comparison,
Go formatting/parser only, and byte/hash/size/mode checks. No supplied module,
function, SQL, fixture, compiler, test, product or ELF ran. No collector was
queried, resumed or launched. All earlier supplied source bytes are preserved.
