"""Retained genuine 1a75 -> 26e pair harness source, AUTHORED_NOT_RUN.

Runs only when called by the existing ordinary remote test route. Authoring
this file does not dispatch a gate or approve a pair. The input bundle and
every helper/ELF/original are byte-bound before helper import or execution.
Independent replay, receiver statements and later Go persistent inspection
remain separate evidence. No result authorizes publication or a 1200 case.
"""

import argparse
import datetime
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time


PRODUCER = "1a75f75feae282890c4b9b8769c54e8b6a23c2f4"
RECEIVER = "26e90d85a0be080538b34b97e17849e4ced61d8b"
SET_SHA = "f35639353f2e314e7f72b03190bb513ca7811417549f4b6716805862e6adb947"
ELF_SHA = "19bdf3a4e8a9af11e24223d5708085ab4d7ca769e31140011248b68ffd87e89b"
_TIME = re.compile(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?Z\Z")
wire = streams = semantic = artifacts = charges = rows = None


def guard():
    if any(os.path.lexists(p) for p in ("/tmp/plug-swarm/PAUSE", "/tmp/plug-swarm/STOP")):
        raise RuntimeError("V2_PAIR_STOPPED")


def require(condition):
    if not condition:
        raise RuntimeError("V2_PAIR_BINDING_REFUSED")


def _signature(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _binding(path, *, mode=0o444, expected=None):
    """Bootstrap no-follow file/ancestor binding, also used after direct wait."""
    guard()
    path = Path(path)
    require(path.is_absolute() and str(path) == os.path.normpath(str(path)) and
            ".." not in path.parts)
    fds, edges = [], []
    try:
        fds.append(os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC))
        for name in path.parts[1:-1]:
            guard()
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         dir_fd=fds[-1])
            edges.append((fds[-1], name, fd, os.fstat(fd)))
            fds.append(fd)
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=fds[-1])
        fds.append(fd)
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid() and
                before.st_nlink == 1 and stat.S_IMODE(before.st_mode) == mode)
        digest, size = hashlib.sha256(), 0
        while True:
            guard()
            block = os.read(fd, 65536)
            if not block:
                break
            digest.update(block)
            size += len(block)
        require(_signature(before) == _signature(os.fstat(fd)) ==
                _signature(os.stat(path.name, dir_fd=fds[-2], follow_symlinks=False)))
        for parent, name, child, info in edges:
            current = os.stat(name, dir_fd=parent, follow_symlinks=False)
            require(stat.S_ISDIR(current.st_mode) and
                    (current.st_dev, current.st_ino) == (info.st_dev, info.st_ino) ==
                    (os.fstat(child).st_dev, os.fstat(child).st_ino))
        result = {"sha256": digest.hexdigest(), "bytes": size}
        require(size == before.st_size and (expected is None or result == expected))
        return result
    finally:
        for fd in reversed(fds):
            os.close(fd)


def _json(raw):
    def pairs(items):
        value = {}
        for key, nested in items:
            require(key not in value)
            value[key] = nested
        return value
    return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs,
                      parse_constant=lambda _: require(False))


def _small(path, binding, limit):
    require(binding["bytes"] <= limit)
    _binding(path, expected=binding)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        value = bytearray()
        while True:
            guard()
            block = os.read(fd, min(65536, limit + 1 - len(value)))
            if not block:
                break
            value.extend(block)
            require(len(value) <= limit)
        require({"sha256": hashlib.sha256(value).hexdigest(), "bytes": len(value)} == binding)
        return bytes(value)
    finally:
        os.close(fd)


def _write(path, chunks, mode=0o444):
    guard()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        for block in chunks:
            guard()
            view = memoryview(block)
            while view:
                count = os.write(fd, view)
                require(count > 0)
                view = view[count:]
        os.fsync(fd)
        os.fchmod(fd, mode)
    finally:
        os.close(fd)
    return _binding(path, mode=mode)


def _dump(path, value):
    return _write(path, (json.dumps(value, ensure_ascii=True, sort_keys=True,
                                  separators=(",", ":"), allow_nan=False).encode() + b"\n",))


def _bound_bundle(root, manifest_path, expected):
    manifest = _json(_small(manifest_path, expected, 1 << 20))
    require(manifest["format"] == "native-delta-retained-pair-inputs/1" and
            manifest["producer_head"] == PRODUCER and manifest["receiver_head"] == RECEIVER and
            manifest["set_sha256"] == SET_SHA and manifest["receiver_elf_sha256"] == ELF_SHA)
    actual = set()
    for directory, subdirs, files in os.walk(root, followlinks=False):
        guard()
        require(not os.path.islink(directory))
        for name in subdirs:
            require(not os.path.islink(Path(directory) / name))
        for name in files:
            actual.add(str((Path(directory) / name).relative_to(root)))
    require(actual == set(manifest["files"]) | {"manifest.json"} and
            manifest_path == root / "manifest.json")
    for name, description in manifest["files"].items():
        require(name and not Path(name).is_absolute() and ".." not in Path(name).parts)
        _binding(root / name, expected=description)
    require(manifest["files"]["receiver/native-receive"]["sha256"] == ELF_SHA and
            manifest["files"]["producer/output/capture-set/capture-set.json"]["sha256"] == SET_SHA)
    return manifest


def _helpers(root, manifest):
    global wire, streams, semantic, artifacts, charges, rows
    names = ("native_delta_wire_v2", "native_delta_row_policy_v2", "native_delta_replay_v2",
             "native_delta_semantic_policy_v2", "native_delta_receiver_checks_v2",
             "native_delta_receiver_streams_v2", "native_delta_artifacts_distinct_history_v2",
             "native_delta_reconstruction_charges_v2")
    require(all(name not in sys.modules for name in names))
    for name in names:
        _binding(root / "caller" / (name + ".py"),
                 expected=manifest["files"]["caller/" + name + ".py"])
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / "caller"))
    loaded = {name: importlib.import_module(name) for name in names}
    wire, rows = loaded[names[0]], loaded[names[1]]
    semantic, streams = loaded[names[3]], loaded[names[5]]
    artifacts, charges = loaded[names[6]], loaded[names[7]]


def _copy_executable(source, expected, target):
    _binding(source, expected=expected)
    def chunks():
        fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            while True:
                block = os.read(fd, 65536)
                if not block:
                    break
                yield block
        finally:
            os.close(fd)
    result = _write(target, chunks(), mode=0o500)
    require(result == expected)
    return result


def _execute(argv, directory, prefix):
    """Own direct child, file-backed unbounded-total originals; no shell/pipes."""
    argv_binding = _dump(directory / (prefix + ".argv.json"), argv)
    paths = [directory / (prefix + suffix) for suffix in (".stdout", ".stderr")]
    fds, process, failure = [], None, None
    started_wall, started_mono = time.time_ns(), time.monotonic_ns()
    try:
        for path in paths:
            fds.append(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                               os.O_NOFOLLOW | os.O_CLOEXEC, 0o600))
        guard()
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=fds[0], stderr=fds[1],
                                   cwd=directory, env=os.environ.copy(), start_new_session=True,
                                   close_fds=True)
        while True:
            guard()
            require(time.monotonic_ns() - started_mono <= 7200 * 10**9)
            try:
                status = process.wait(timeout=1)
                break
            except subprocess.TimeoutExpired:
                pass
    except BaseException as error:
        failure = error
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
        status = None if process is None else process.returncode
    finally:
        ended_wall, ended_mono = time.time_ns(), time.monotonic_ns()
        for fd in fds:
            os.fsync(fd)
            os.fchmod(fd, 0o444)
            os.close(fd)
    wait = {"format": "native-delta-direct-child-wait/1", "pid": None if process is None else process.pid,
            "argv": argv_binding, "exit_code": status, "direct_wait_completed": process is not None and
            process.returncode is not None, "interrupted": failure is not None,
            "start_unix_ns": started_wall, "end_unix_ns": ended_wall,
            "elapsed_monotonic_ns": ended_mono - started_mono,
            "environment": "inherited exact parent environment; no overlay; values not logged",
            "child_rss": "receiver RUSAGE_SELF receipt is a separate measurement"}
    _dump(directory / (prefix + ".wait.json"), wait)
    if failure is not None:
        raise failure
    return {"wait": wait, "stdout": _binding(paths[0]), "stderr": _binding(paths[1])}


def _instant(text):
    match = _TIME.fullmatch(text)
    require(match is not None)
    fraction = match[2] or ""
    require(not fraction or fraction[-1] != "0")
    parsed = datetime.datetime.strptime(match[1], "%Y-%m-%dT%H:%M:%S")
    seconds = (parsed - datetime.datetime(1970, 1, 1)).days * 86400 + parsed.hour * 3600 + parsed.minute * 60 + parsed.second
    return seconds * 10**9 + int(fraction.ljust(9, "0") or "0")


def _restore_clock(path, binding, wait, scratch):
    """Bound original nondeterministic clock scalar to the actual launch interval.

    This is not an independently predicted timestamp. The Go companion must
    separately match recoveredProfile.HistoryTime from the persistent store.
    """
    original = streams._Original(str(path), binding, guard)
    try:
        with streams._DiskKeys(str(scratch), guard) as disk:
            parser = streams._JSON(original, disk)
            def read(key):
                if key != "restore_time":
                    parser.skip()
                    return None
                value = bytearray()
                def append(block):
                    require(len(value) + len(block) <= 30)
                    value.extend(block)
                parser.string(append)
                return value.decode("ascii")
            required = ("format", "policy_sha256", "binary_sha256", "request_sha256", "archive_sha256",
                        "driver", "history_mode", "restore_time", "verification", "committed_report",
                        "cross_project_id_collisions", "native_delta")
            scalars = parser.object(required, (), read)
            original.whitespace()
            original.finish()
        value = scalars["restore_time"]
        require(wait["start_unix_ns"] <= _instant(value) <= wait["end_unix_ns"])
        return value
    finally:
        original.close()


def _constructor(path, binding, policy, root):
    value = wire.strict_json(_small(path, binding, 64 << 20))
    wire.fields(value, ("format", "policy_sha256", "archive_sha256", "source_store_id", "projects",
                        "admission", "idempotency_key", "source_plan"))
    require(value["format"] == "plug-native-receiving-request/1" and value["policy_sha256"] == policy["sha256"] and
            value["archive_sha256"] == SET_SHA and value["source_store_id"] == root["store_id"] and
            value["projects"] == root["projects"])
    require(value["source_plan"]["ArchiveSHA256"] == SET_SHA and
            value["source_plan"]["SourceStoreID"] == root["store_id"] and
            value["source_plan"]["Target"]["StoreID"] == "" and
            value["source_plan"]["Target"]["Incarnation"] == "")
    # Complete source-plan/admission/mapper validation is the Go companion's
    # ordinary recovered-binding comparison, not inferred from these scalars.
    return value


def _lease_kept(raw, restore_time):
    value = rows._decode(raw, guard)
    expires = rows._utc_time(value["lease_expires_at"])
    return _instant(expires) > _instant(restore_time)


def _body(replay, state_id, name, history, restore_time):
    identity = {"store_id": replay.header["store_id"], "project": replay.header["projects"][0]}
    yield b'{"source_identity":'
    yield from rows._go_json(identity, guard)
    yield b',"table":' + rows._go_string(name)
    yield b',"history":' + rows._go_string(history) + b',"columns":'
    schema = replay._one("SELECT schema_id FROM states WHERE id=?", (state_id,))[0]
    definition = replay._definition(schema, name)
    yield from rows._go_json(sorted(column["name"] for column in definition["columns"]), guard)
    yield b',"rows":['
    index = 0
    for (raw,) in replay._iter("SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key",
                               (state_id, wire.text(name))):
        if state_id == b"C" and name == "leases" and not _lease_kept(raw, restore_time):
            continue
        require(raw.endswith(b"\n"))
        if index:
            yield b","
        yield raw[:-1]
        index += 1
    yield b"]}"


def _expected(replay, output, restore_time, manifest):
    """Stream every expected body and explicit absence, including dropped tables.

    The ordinary Go companion must match each body against the imported store
    at its recovered source mapping, and compare each original capture blob.
    """
    expected_dir = output / "expected"
    expected_dir.mkdir(mode=0o700)
    ledger = expected_dir / "readback.ndjson"
    counts = {"historical_states": 0, "historical_tables": 0, "historical_rows": 0,
              "current_tables": 0, "current_source_rows": 0, "current_imported_rows": 0}
    def lines():
        for state_id, kind, schema_id, root in replay._iter(
                "SELECT id,kind,schema_id,root FROM states WHERE kind!='head-checkpoint' ORDER BY id"):
            guard()
            sequence, commit = 0, ""
            if kind == "commit":
                commit, encoded = replay._one("SELECT id,sequence FROM commits WHERE state_id=?", (state_id,))
                sequence = int.from_bytes(encoded, "big")
                counts["historical_states"] += 1
            event = {"type": "state", "kind": kind, "sequence": sequence, "commit_id": commit,
                     "schema_id": schema_id, "root_sha256": root}
            yield json.dumps(event, sort_keys=True, separators=(",", ":")).encode() + b"\n"
            for (encoded_name,) in replay._iter("SELECT DISTINCT name FROM state_tables ORDER BY name"):
                name = encoded_name.decode("utf-8")
                table = replay._one("SELECT rows,table_schema_id,sha256 FROM state_tables WHERE state_id=? AND name=?",
                                    (state_id, encoded_name))
                prefix = "source/native-history/" if kind == "commit" else "source/native-current/"
                tuple_raw = b"".join(rows._go_json([replay.header["store_id"], replay.header["projects"][0], name], guard))
                event = {"type": "table", "kind": kind, "sequence": sequence, "commit_id": commit,
                         "family": name, "ref_id": prefix + hashlib.sha256(tuple_raw).hexdigest(),
                         "present": table is not None}
                if table is not None:
                    history = "retained-native-commit"
                    if kind == "current":
                        classified = replay._one("SELECT history FROM policy_classification WHERE name=?", (encoded_name,))
                        history = classified[0] if classified else "opaque-native-physical"
                    filename = ("current" if kind == "current" else str(sequence).zfill(20)) + "-" + hashlib.sha256(encoded_name).hexdigest() + ".json"
                    binding = _write(expected_dir / filename, _body(replay, state_id, name, history, restore_time))
                    source_rows = int.from_bytes(table[0], "big")
                    imported_rows = source_rows
                    if kind == "current" and name == "leases":
                        imported_rows = sum(1 for (raw,) in replay._iter(
                            "SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key", (state_id, encoded_name))
                                            if _lease_kept(raw, restore_time))
                    event.update({"body_file": filename, "body": binding, "history": history,
                                  "source_rows": source_rows, "imported_rows": imported_rows,
                                  "table_schema_id": table[1], "table_sha256": table[2]})
                    if kind == "commit":
                        counts["historical_tables"] += 1
                        counts["historical_rows"] += source_rows
                    else:
                        counts["current_tables"] += 1
                        counts["current_source_rows"] += source_rows
                        counts["current_imported_rows"] += imported_rows
                yield json.dumps(event, sort_keys=True, separators=(",", ":")).encode() + b"\n"
    binding = _write(ledger, lines())
    manifest_binding = _dump(expected_dir / "manifest.json", {"format": "native-delta-independent-readback-expectations/1",
          "ledger": binding, "counts": counts, "restore_time": restore_time,
          "commit_count": replay.header["commit_count"], "history_coverage": replay.header["history_coverage"],
          "capture_set_sha256": SET_SHA, "source_store_id": replay.header["store_id"],
          "projects": replay.header["projects"], "producer_head": PRODUCER, "receiver_head": RECEIVER,
          "capture_files": {name[len("producer/output/capture-set/"):]: description for name, description in manifest["files"].items()
                            if name.startswith("producer/output/capture-set/")},
          "persistent_readback": "PENDING_GO_COMPANION", "publication_authorized": False})
    return counts, manifest_binding


def run(root, manifest_path, expected_manifest, output):
    guard()
    manifest = _bound_bundle(root, manifest_path, expected_manifest)
    _helpers(root, manifest)
    require(output.is_absolute() and not os.path.lexists(output))
    parent = output.parent
    with streams._DirectoryChain(str(parent), guard) as chain:
        info = os.fstat(chain.fd)
        require(info.st_uid == os.getuid() and not info.st_mode & 0o022)
        os.mkdir(output.name, 0o700, dir_fd=chain.fd)
        chain.recheck()
    scratch = output / "scratch"
    scratch.mkdir(mode=0o700)
    elf = output / "native-receive"
    _copy_executable(root / "receiver/native-receive", manifest["files"]["receiver/native-receive"], elf)
    capture_dir = root / "producer/output/capture-set"
    output_inputs = root / "producer/output"
    with wire.CaptureSet(str(capture_dir),
                        expected_store_id="native/a8169e2cd3b429e00307154774f0343277017a5d4726b546099948a3123bcb07",
                        expected_projects=["public"], expected_head="3fa1iormje3tmhe2uredeqrnr0rglmv3",
                        guard=guard) as capture:
        with semantic.SemanticReplay(str(scratch), guard=guard) as replay:
            replay_result = replay.consume(capture)
            require(capture.root_sha256 == SET_SHA)
            _dump(output / "independent-replay.json", replay_result)
            artifact_result = artifacts.bind_artifacts(capture, replay, head_path=str(capture_dir / "head.tar"),
                head_binding=manifest["files"]["producer/output/capture-set/head.tar"],
                inventory_path=str(output_inputs / "inventory.json"),
                inventory_binding=manifest["files"]["producer/output/inventory.json"],
                evidence_path=str(output_inputs / "physical-evidence.json"),
                evidence_binding=manifest["files"]["producer/output/physical-evidence.json"],
                expected_database="public_native_delta", scratch_parent=str(scratch), guard=guard)
            _dump(output / "independent-artifacts.json", artifact_result)
            _dump(output / "one-reconstruction-pass-charges.json", charges.ReconstructionCharges(capture, replay, guard=guard).build())
            results = {}
            for engine in ("memory", "sqlite"):
                case = output / engine
                case.mkdir(mode=0o700)
                policy_path = root / "policies" / (engine + ".json")
                policy_binding = manifest["files"]["policies/" + engine + ".json"]
                common = ["--capture-set", str(capture_dir), "--policy", str(policy_path),
                          "--driver", engine, "--expected-binary-sha256", ELF_SHA]
                constructor = _execute([str(elf), "prepare-request", *common], case, "constructor")
                _dump(case / "constructor.originals.json", constructor)
                require(constructor["wait"]["exit_code"] == 0 and constructor["stderr"]["bytes"] == 0)
                _constructor(case / "constructor.stdout", constructor["stdout"], policy_binding, capture.root)
                target = case / "retained.sqlite"
                receive = _execute([str(elf), *common, "--request", str(case / "constructor.stdout"),
                                    "--target", str(target) if engine == "sqlite" else ""], case, "receive")
                _dump(case / "receive.originals.json", receive)
                require(receive["wait"]["exit_code"] == 0)
                clock = _restore_clock(case / "receive.stdout", receive["stdout"], receive["wait"], scratch)
                expected = {"policy_sha256": policy_binding["sha256"], "binary_sha256": ELF_SHA,
                            "request_sha256": constructor["stdout"]["sha256"], "archive_sha256": SET_SHA,
                            "driver": engine, "restore_time": clock}
                extracted = streams.extract_success(str(case / "receive.stdout"), receive["stdout"],
                    str(case / "receive.stderr"), receive["stderr"], scratch_parent=str(scratch), guard=guard,
                    replay=replay, expected_receipt=expected, expected_limit=2147483648, expected_origin="default")
                verification = extracted["outer_fields"]["verification"]
                require(verification["archive_blob"] is True and verification["reopen"] ==
                        ("driver-reopened" if engine == "sqlite" else "same-process-memory"))
                counts, expectation_binding = _expected(replay, case, clock, manifest)
                _dump(case / "expectation-binding.json", expectation_binding)
                require(verification["history_images"] == counts["historical_states"] and
                        verification["history_tables"] == counts["historical_tables"] and
                        verification["history_rows"] == counts["historical_rows"] and
                        verification["current_families"] == counts["current_tables"] and
                        verification["current_rows"] == counts["current_imported_rows"])
                if engine == "sqlite":
                    # Freeze only after a successful direct wait. Do not open
                    # the driver here or mutate a file being used by a child.
                    require(not any(os.path.lexists(str(target) + suffix) for suffix in ("-wal", "-shm", "-journal")))
                    fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                    try:
                        os.fchmod(fd, 0o444)
                    finally:
                        os.close(fd)
                    _dump(case / "retained-target.json", _binding(target))
                _dump(case / "receiver-extraction.json", extracted)
                results[engine] = {"direct_constructor_and_default_exit": 0,
                                   "independent_commit_table_proofs": "MATCHED", "restore_time": clock,
                                   "restore_clock": "ORIGINAL_WITHIN_DIRECT_CHILD_WALL_CLOCK_BRACKET; RECOVERY_COMPARISON_PENDING",
                                   "counts": counts, "expectation_manifest": expectation_binding,
                                   "persistent_inspection": "PENDING_GO_COMPANION"}
            # Full rebind after child execution, not only the initial intake.
            _bound_bundle(root, manifest_path, expected_manifest)
            capture._root_stable()
    result = {"format": "native-delta-retained-pair-harness/1", "status": "ORIGINALS_AND_SOURCE_PROOFS_MATCHED_PARTIAL",
              "input_manifest": expected_manifest, "producer_head": PRODUCER, "receiver_head": RECEIVER,
              "receiver_elf_sha256": ELF_SHA, "capture_set_sha256": SET_SHA, "cases": results,
              "category_preimages": "14_RECONSTRUCTION_CATEGORIES_ONE_PASS_ONLY; EIGHT_AND_MULTIPLICITY_PENDING",
              "full_business_mapping_admission_and_persistent_readback": "PENDING_GO_COMPANION_AND_INTEGRATION",
              "numeric_time_runtime_conformance": "PENDING_INDEPENDENT_CONTROLS",
              "public_1200_loose_archive": "NOT_RUN", "private": "HARD_DISABLED", "item4": "PAUSED",
              "c75": "STOP_ALL", "publication_authorized": False}
    _dump(output / "HARNESS-RESULT.json", result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--manifest-bytes", required=True, type=int)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        run(Path(args.bundle), Path(args.bundle) / "manifest.json",
            {"sha256": args.manifest_sha256, "bytes": args.manifest_bytes}, Path(args.output))
    except BaseException:
        # Preserve original files/target for the ordinary collector. Never
        # include an untrusted value, OS error or source cell in diagnostics.
        sys.stderr.write("V2_PAIR_HARNESS_NOT_PASS\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
