"""Independent partial typed-row/secret checks, AUTHORED_NOT_RUN.

This supplies a row validator, NOT StructuralReplay's complete policy hook.
Schema profiles, CP11, authenticated ignore classification, metadata and
source/head/current/evidence authority must still be checked by integration.
No provided-module/fixture/SQL/product invocation or admission is performed.
The earlier reviewed modules are unchanged. All external errors are fixed
codes; no value/name/cell/raw parser text is exposed in failure messages.
"""

from fractions import Fraction
import json
import re
import struct

import native_delta_wire_v2 as wire


_SQL_NAME = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]{0,127}\Z")
_SIGNED = re.compile(r"(?:0|-[1-9][0-9]*|[1-9][0-9]*)\Z")
_FLOAT_BITS = re.compile(r"(?:0|[1-9a-f][0-9a-f]*)\Z")
_NUMBER = re.compile(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\Z")
_TIME = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):"
                   r"([0-9]{2})(\.[0-9]{1,9})?(Z|[+-][0-9]{2}:[0-9]{2})\Z")
_PATTERNS = ("api_key", "api-key", "apikey", "secret", "token", "password", "passwd",
             "credential", "private_key", "privatekey", "privkey", "dsn", "access_key")
_SEGMENTS = frozenset(("key", "keys", "apikey", "pwd", "pat", "auth", "bearer", "cert",
                       "credential", "credentials", "secret", "token", "password"))


class _Number:
    """Go json.Number spelling, including exact SQL JSON decimal/exponent text."""

    def __init__(self, spelling):
        wire.need(type(spelling) is str and _NUMBER.fullmatch(spelling) is not None,
                  "V2_ROW_NUMBER_SPELLING_REFUSED")
        self.spelling = spelling


def _decode(raw, guard):
    def pairs(items):
        value = {}
        for key, item in items:
            guard()
            wire.need(key not in value, "V2_ROW_DUPLICATE_JSON_KEY")
            wire.text(key, empty=True)
            value[key] = item
        return value

    def constant(_):
        raise wire.Refusal("V2_ROW_NONFINITE_JSON_REFUSED")

    guard()
    value = json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs,
                       parse_int=_Number, parse_float=_Number, parse_constant=constant)
    # Check escaped surrogates too. Decoded input is one bounded row/cell,
    # never an aggregate history, and every string must preserve UTF-8.
    def walk(item):
        guard()
        if type(item) is str:
            wire.text(item, empty=True)
        elif type(item) is dict:
            for nested in item.values():
                walk(nested)
        elif type(item) is list:
            for nested in item:
                walk(nested)

    walk(value)
    return value


def _go_string(value):
    wire.text(value, empty=True)
    return (json.dumps(value, ensure_ascii=False)
            .replace("&", "\\u0026").replace("<", "\\u003c")
            .replace(">", "\\u003e").replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029").encode("utf-8", "strict"))


def _go_json(value, guard):
    """Sorted compact map JSON; no Python float/Decimal serialization path."""
    guard()
    if value is None:
        yield b"null"
    elif type(value) is bool:
        yield b"true" if value else b"false"
    elif type(value) is str:
        yield _go_string(value)
    elif type(value) is _Number:
        yield value.spelling.encode("ascii")
    elif type(value) is dict:
        yield b"{"
        for index, key in enumerate(sorted(value)):
            if index:
                yield b","
            yield _go_string(key)
            yield b":"
            yield from _go_json(value[key], guard)
        yield b"}"
    elif type(value) is list:
        yield b"["
        for index, nested in enumerate(value):
            if index:
                yield b","
            yield from _go_json(nested, guard)
        yield b"]"
    else:
        raise wire.Refusal("V2_ROW_JSON_VALUE_TYPE_REFUSED")


def _compare_canonical(value, raw, guard):
    offset = 0
    for chunk in _go_json(value, guard):
        guard()
        wire.need(raw[offset:offset + len(chunk)] == chunk,
                  "V2_ROW_TYPED_OR_CANONICAL_NORMALIZED_MISMATCH")
        offset = wire.add(offset, len(chunk))
    wire.need(raw[offset:] == b"\n", "V2_ROW_NORMALIZED_TERMINAL_NEWLINE_REFUSED")


def _simple_lower(value):
    """Go rune-wise simple lower, avoiding Python context/full expansions."""
    out = []
    for char in value:
        lowered = char.lower()
        # Unicode's dotted capital I has a full-lower expansion in Python,
        # while Go's rune table maps it to a single ASCII i.
        if len(lowered) != 1:
            wire.need(char == "\u0130", "V2_ROW_UNSUPPORTED_CASE_MAPPING")
            lowered = "i"
        out.append(lowered)
    return "".join(out)


def secret_key(value):
    wire.text(value, empty=True)
    lower = _simple_lower(value)
    return any(part in lower for part in _PATTERNS) or any(
        segment in _SEGMENTS for segment in re.split(r"[._-]", lower))


def validate_secret_references(value, *, guard):
    """Unchanged generic recursive predicate; no peer or policy exemption."""
    guard()
    if type(value) is dict:
        if "$secret" in value:
            wire.need(len(value) == 1 and type(value["$secret"]) is str and
                      bool(value["$secret"]), "V2_ROW_SECRET_REFERENCE_SHAPE_REFUSED")
            wire.text(value["$secret"])
            return
        for key, item in value.items():
            guard()
            if secret_key(key):
                wire.need(type(item) is dict and item.keys() == {"$secret"} and
                          type(item["$secret"]) is str and bool(item["$secret"]),
                          "V2_ROW_PRESENT_CREDENTIAL_REFUSED")
            validate_secret_references(item, guard=guard)
    elif type(value) is list:
        for item in value:
            validate_secret_references(item, guard=guard)


def _empty_peer(value):
    return (value is None or type(value) is str and value == "" or
            type(value) is dict and value.keys() == {"$bytes"} and value["$bytes"] == "")


def _row_secrets(family, values, guard):
    if family in ("config", "metadata", "local_metadata"):
        key = values.get("key")
        validate_secret_references({key if type(key) is str else "": values.get("value")},
                                   guard=guard)
        for column, value in values.items():
            if column not in ("key", "value"):
                validate_secret_references({column: value}, guard=guard)
        return
    for key, value in values.items():
        guard()
        if family == "federation_peers" and key == "password_encrypted" and _empty_peer(value):
            continue
        validate_secret_references({key: value}, guard=guard)


def _fraction(bits, width):
    """Exact nonnegative finite IEEE value, with no binary-float conversion."""
    fraction_bits, exponent_bits, bias = (23, 8, 127) if width == 32 else (52, 11, 1023)
    exponent = bits >> fraction_bits
    mantissa = bits & ((1 << fraction_bits) - 1)
    wire.need(exponent < (1 << exponent_bits) - 1, "V2_ROW_NONFINITE_FLOAT_REFUSED")
    power = (exponent if exponent else 1) - bias - fraction_bits
    if exponent:
        mantissa += 1 << fraction_bits
    return Fraction(mantissa << power, 1) if power >= 0 else Fraction(mantissa, 1 << -power)


def _decimal_exponent(value):
    # Exact floor(log10(value)), bounded by the physical IEEE width.
    num, den = value.numerator, value.denominator
    exponent = len(str(num)) - len(str(den))
    below = num < den * 10 ** exponent if exponent >= 0 else num * 10 ** -exponent < den
    return exponent - 1 if below else exponent


def _float_json(encoded, width, guard):
    """Shortest correctly rounded decimal from exact IEEE rounding intervals.

    The n-digit closest decimal and its two neighbors cover the interval
    candidates. IEEE even significands include midpoint ties; odd ones do
    not. At the first successful digit count, closest/even selects Go's
    shortest decimal, followed by encoding/json's width-specific cutoffs.
    No float repr/printf or receiver-produced spelling is used as an oracle.
    """
    wire.need(type(encoded) is str and len(encoded) <= width // 4 and
              _FLOAT_BITS.fullmatch(encoded) is not None, "V2_ROW_FLOAT_BITS_REFUSED")
    bits = int(encoded, 16)
    negative = bool(bits & (1 << (width - 1)))
    magnitude = bits & ((1 << (width - 1)) - 1)
    value = _fraction(magnitude, width)
    if not magnitude:
        return "-0" if negative else "0"
    previous = _fraction(magnitude - 1, width)
    fraction_bits, exponent_bits, bias = (23, 8, 127) if width == 32 else (52, 11, 1023)
    last = (((1 << exponent_bits) - 1) << fraction_bits) - 1
    following = Fraction(1 << (bias + 1), 1) if magnitude == last else _fraction(magnitude + 1, width)
    lower, upper = (previous + value) / 2, (following + value) / 2
    inclusive = magnitude % 2 == 0
    order = _decimal_exponent(value)
    choice = None
    for count in range(1, (9 if width == 32 else 17) + 1):
        guard()
        power = order - count + 1
        scale = Fraction(10 ** power, 1) if power >= 0 else Fraction(1, 10 ** -power)
        scaled = value / scale
        integer, remainder = divmod(scaled.numerator, scaled.denominator)
        if 2 * remainder > scaled.denominator or (2 * remainder == scaled.denominator and integer % 2):
            integer += 1
        candidates = []
        for coefficient in (integer - 1, integer, integer + 1):
            if coefficient <= 0:
                continue
            candidate = coefficient * scale
            fits = lower <= candidate <= upper if inclusive else lower < candidate < upper
            if fits:
                candidates.append((abs(candidate - value), coefficient % 2, coefficient))
        if candidates:
            choice = min(candidates)[2], power
            break
    wire.need(choice is not None, "V2_ROW_FLOAT_DECIMAL_UNAVAILABLE")
    coefficient, power = choice
    while coefficient % 10 == 0:
        coefficient //= 10
        power += 1
    digits = str(coefficient)
    # Only the fixed, exact cutoff constants are converted to native IEEE;
    # source values and decimal candidates always use exact rational math.
    if width == 32:
        low_bits = struct.unpack(">I", struct.pack(">f", 1e-6))[0]
        high_bits = struct.unpack(">I", struct.pack(">f", 1e21))[0]
    else:
        low_bits = struct.unpack(">Q", struct.pack(">d", 1e-6))[0]
        high_bits = struct.unpack(">Q", struct.pack(">d", 1e21))[0]
    scientific = value < _fraction(low_bits, width) or value >= _fraction(high_bits, width)
    if scientific:
        exponent = len(digits) - 1 + power
        result = digits[0] + ("." + digits[1:] if len(digits) > 1 else "")
        result += "e" + ("+" if exponent >= 0 else "-") + str(abs(exponent))
    else:
        point = len(digits) + power
        if point <= 0:
            result = "0." + "0" * -point + digits
        elif point >= len(digits):
            result = digits + "0" * (point - len(digits))
        else:
            result = digits[:point] + "." + digits[point:]
    return ("-" if negative else "") + result


def _month_days(year, month):
    leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    return (31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)[month - 1]


def _utc_time(value):
    wire.text(value)
    match = _TIME.fullmatch(value)
    wire.need(match is not None, "V2_ROW_TIME_SPELLING_REFUSED")
    year, month, day, hour, minute, second = (int(part) for part in match.groups()[:6])
    fraction, zone = match.groups()[6:]
    wire.need(1 <= month <= 12 and 1 <= day <= _month_days(year, month) and
              hour < 24 and minute < 60 and second < 60 and
              (fraction is None or fraction[-1] != "0"), "V2_ROW_TIME_CANONICAL_REFUSED")
    offset = 0
    if zone != "Z":
        offset_hour, offset_minute = int(zone[1:3]), int(zone[4:6])
        # Go Parse's fallback permits hour24; Format preserves +24:MM.
        # Minute60 is not canonical because Format carries it to the hour.
        wire.need(offset_hour <= 24 and offset_minute < 60 and
                  bool(offset_hour or offset_minute), "V2_ROW_TIME_ZONE_REFUSED")
        offset = (offset_hour * 60 + offset_minute) * (1 if zone[0] == "+" else -1)
    carry, minutes = divmod(hour * 60 + minute - offset, 24 * 60)
    day += carry
    while day <= 0:
        month -= 1
        if month == 0:
            month, year = 12, year - 1
        day += _month_days(year, month)
    while day > _month_days(year, month):
        day -= _month_days(year, month)
        month += 1
        if month == 13:
            month, year = 1, year + 1
    year_text = ("-" if year < 0 else "") + str(abs(year)).zfill(4)
    return (f"{year_text}-{month:02d}-{day:02d}T{minutes // 60:02d}:{minutes % 60:02d}:"
            f"{second:02d}{fraction or ''}Z")


def _integer(value, kind):
    signed = kind.startswith("int")
    suffix = kind[3:] if signed else kind[4:]
    width = 64 if not suffix else int(suffix)
    pattern = _SIGNED if signed else wire.UNSIGNED
    wire.need(type(value) is str and len(value) <= 20 and pattern.fullmatch(value) is not None,
              "V2_ROW_INTEGER_SPELLING_REFUSED")
    integer = int(value)
    wire.need(-(1 << (width - 1)) <= integer < (1 << (width - 1)) if signed else
              0 <= integer < (1 << width), "V2_ROW_INTEGER_WIDTH_REFUSED")
    return _Number(value)


def _cell(cell, sql_type, guard):
    wire.fields(cell, ("kind", "value"))
    kind, value = cell["kind"], cell["value"]
    wire.need(type(kind) is str and kind in wire.CELL_KINDS, "V2_ROW_CELL_KIND_REFUSED")
    wire.text(value, empty=True)
    if kind == "sql-null":
        wire.need(value == "", "V2_ROW_NULL_VALUE_REFUSED")
        return None
    if kind == "secret-reference":
        return {"$secret": value}
    if kind in ("string", "bytes", "string-bytes"):
        if kind != "string":
            raw = wire.b64(value)
            if kind == "bytes" and ("BLOB" in sql_type.upper() or "BINARY" in sql_type.upper()):
                return {"$bytes": value}
            wire.need(kind != "string-bytes", "V2_ROW_LOSSY_TEXT_REFUSED")
            value = raw.decode("utf-8", "strict")
        return _decode(wire.text(value, empty=True), guard) if sql_type.upper() == "JSON" else value
    if kind == "bool":
        wire.need(value in ("true", "false"), "V2_ROW_BOOLEAN_SPELLING_REFUSED")
        return value == "true"
    if kind == "time":
        return _utc_time(value)
    if kind in ("float32-bits", "float64-bits"):
        return _Number(_float_json(value, 32 if kind == "float32-bits" else 64, guard))
    return _integer(value, kind)


def validate_row(*, header, record, table, guard):
    """Validate one inserted/updated typed row before structural disk retention.

    This deliberately cannot validate a header/schema/metadata/checkpoint or
    stand in for the complete policy callback. It returns no source values.
    Context must be the exact authenticated header, not an inferred policy.
    """
    wire.need(callable(guard), "V2_ROW_GUARD_REQUIRED")
    try:
        guard()
        wire.need(type(header) is dict and header.get("type") == "header" and
                  header.get("format") == wire.CONTRACT and
                  type(header.get("config_policy")) is dict,
                  "V2_ROW_AUTHENTICATED_HEADER_REQUIRED")
        policy = header["config_policy"]
        wire.need(type(table) is dict and type(table.get("name")) is str and
                  _SQL_NAME.fullmatch(table["name"]) is not None,
                  "V2_ROW_TABLE_NAME_REFUSED")
        columns = table["columns"]
        wire.need(type(columns) is list and 1 <= len(columns) <= 1024,
                  "V2_ROW_COLUMN_CENSUS_REFUSED")
        wire.fields(record, ("type", "op", "key", "cells", "normalized_json"))
        wire.need(record["type"] == "row" and record["op"] in ("insert", "update") and
                  type(record["cells"]) is list and len(record["cells"]) == len(columns),
                  "V2_ROW_CELL_CENSUS_REFUSED")
        raw = wire.b64(record["normalized_json"], nonempty=True)
        normalized = _decode(raw, guard)
        wire.need(type(normalized) is dict, "V2_ROW_NORMALIZED_OBJECT_REQUIRED")
        names = set()
        for column in columns:
            guard()
            wire.fields(column, ("name", "sql_type", "primary_key_ordinal"))
            name = column["name"]
            wire.need(type(name) is str and _SQL_NAME.fullmatch(name) is not None and
                      name not in names, "V2_ROW_COLUMN_NAME_REFUSED")
            wire.text(column["sql_type"])
            names.add(name)
        wire.need(normalized.keys() == names, "V2_ROW_NORMALIZED_COLUMNS_REFUSED")
        family = table["name"]
        key = normalized.get("key")
        declared_reference = None
        if family in ("config", "metadata"):
            setting = key if type(key) is str else ""
            authority = family + "/" + setting
            declaration = policy.get(authority)
            wire.need(declaration is None or declaration in ("public", "secret"),
                      "V2_ROW_CONFIG_POLICY_VALUE_REFUSED")
            if secret_key(setting) or declaration == "secret":
                wire.need(bool(setting), "V2_ROW_SECRET_SETTING_KEY_REFUSED")
                declared_reference = authority
        expected = {}
        for column, cell in zip(columns, record["cells"]):
            guard()
            name = column["name"]
            wire.fields(cell, ("kind", "value"))
            if cell["kind"] == "secret-reference":
                wire.need(name == "value" and declared_reference is not None and
                          cell["value"] == declared_reference,
                          "V2_ROW_SECRET_REFERENCE_CONTEXT_REFUSED")
            if name == "value" and declared_reference is not None:
                wire.need(cell["kind"] == "secret-reference" and cell["value"] == declared_reference,
                          "V2_ROW_SECRET_REFERENCE_REQUIRED")
            expected[name] = _cell(cell, column["sql_type"], guard)
        _row_secrets(family, expected, guard)
        _compare_canonical(expected, raw, guard)
        key_bytes = wire.b64(record["key"], nonempty=True)
        primary = wire.primary_key(table, record["cells"])
        if primary is not None:
            wire.need(primary == key_bytes, "V2_ROW_PRIMARY_KEY_MISMATCH")
        else:
            wire.need(len(key_bytes) == 44 and key_bytes[:4] == b"bag\x00" and
                      wire.bag_key(wire.row_payload(record["cells"], raw),
                                   int.from_bytes(key_bytes[-8:], "big")) == key_bytes,
                      "V2_ROW_BAG_KEY_MISMATCH")
        return {"status": "TYPED_ROW_NORMALIZATION_AND_SECRET_CHECKS_MATCHED_PARTIAL",
                "publication_authorized": False,
                "schema_profile_cp11_classification_and_source_evidence": "PENDING"}
    except wire.Refusal:
        raise
    except (ValueError, UnicodeError, KeyError, TypeError, OverflowError,
            RecursionError, struct.error):
        raise wire.Refusal("V2_ROW_POLICY_FAULT") from None
