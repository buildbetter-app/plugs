"""Partial caller checks of genuine receiver 0ff33149's declared receipts.

AUTHORED_NOT_RUN; no CLI, invocation or complete import validator. Inputs to
these functions must later come from a strict streamed original-stdout/stderr
extractor. That extractor, full receiving/admission/readback checks and
independent accounting category reconstruction are NOT implemented here.
No function here can authorize publication. Source/runtime/pair approval of
the receiver is separate from the exact schema used for this source unit.

Commit proofs are consumed in header/table/end events, so this module never
collects a whole receipt, commit array or table-proof map. It compares every
event with the disk replay and returns bounded summaries. The outer original
receipt must still be retained and bound by its exact file hash/size; events
from another file or a reconstructed document are not original evidence.
"""

import native_delta_wire_v2 as wire


RECEIVER_SOURCE = "0ff33149edcb9e2454fe50d4b5d8213b200335cc"
RECEIVER_TREE = "145f5e6795de203bd168fb7fdf7d1f4b04fd80c2"
ACCOUNTING = "native-delta-decoded-accounting/1"
DEFAULT_LIMIT = 2147483648
NATIVE_RECEIPT = "plug-native-delta-receiving/1"
NATIVE_REFUSAL = "plug-native-delta-refusal/1"
RSS_METHOD = "getrusage(RUSAGE_SELF).ru_maxrss"
RSS_SCOPE = "native-receive process lifetime; excludes child processes"
CATEGORIES = frozenset((
    "head_tar", "head_tar_copies", "header", "schemas", "commit_metadata",
    "decoded_operations", "decoded_baseline_rows", "reconstructed_table_metadata",
    "reconstructed_rows", "image_metadata", "reconstructed_images",
    "aggregate_images", "checkpoints", "commit_proofs", "detached_history_views",
    "detached_history_metadata", "retained_capture_ledger", "offline_batches",
    "history_baseline", "history_gaps", "history_boundaries", "history_envelope",
))
CLI_ORIGINS = frozenset(("default", "explicit flag"))


def _expected_configuration(limit, origin):
    wire.need(wire.uint(limit) > 0 and type(origin) is str and origin in CLI_ORIGINS,
              "V2_RECEIVER_EXPECTED_CONFIGURATION_REFUSED")
    wire.need(origin != "default" or limit == DEFAULT_LIMIT,
              "V2_RECEIVER_DEFAULT_LIMIT_MISMATCH")


def decoded_usage(value, *, expected_limit, expected_origin,
                  expected_categories=None, expected_charges=None):
    """Check a bounded declared usage, and optional independently measured maps.

    Supplying receiver-reported maps as the expected maps is not independent
    recomputation. The integrated caller must construct them from actual
    staged values and the exact receiver counting types/category preimages.
    A missing independent map remains PENDING in the returned partial result.
    """
    _expected_configuration(expected_limit, expected_origin)
    wire.fields(value, ("accounting", "limit_bytes", "limit_origin",
                        "peak_accounted_decoded_bytes", "categories", "charges"))
    wire.need(value["accounting"] == ACCOUNTING and
              wire.uint(value["limit_bytes"]) == expected_limit and
              value["limit_origin"] == expected_origin,
              "V2_RECEIVER_USAGE_CONFIGURATION_MISMATCH")
    peak = wire.uint(value["peak_accounted_decoded_bytes"])
    wire.need(peak <= expected_limit, "V2_RECEIVER_ADMITTED_USAGE_EXCEEDS_LIMIT")
    categories, charges = value["categories"], value["charges"]
    wire.need(type(categories) is dict and type(charges) is dict and
              categories.keys() == charges.keys() and categories.keys() <= CATEGORIES,
              "V2_RECEIVER_USAGE_CATEGORY_SHAPE_REFUSED")
    measured = 0
    for name, size in categories.items():
        measured = wire.add(measured, wire.uint(size))
        wire.need(wire.uint(charges[name]) >= 1, "V2_RECEIVER_CATEGORY_CHARGE_COUNT_REFUSED")
    wire.need(measured == peak, "V2_RECEIVER_CATEGORY_SUM_MISMATCH")
    wire.need((expected_categories is None) == (expected_charges is None),
              "V2_RECEIVER_INDEPENDENT_CHARGE_PAIR_REQUIRED")
    independent = expected_categories is not None
    if independent:
        wire.need(type(expected_categories) is dict and type(expected_charges) is dict and
                  expected_categories.keys() == expected_charges.keys() and
                  expected_categories.keys() <= CATEGORIES,
                  "V2_RECEIVER_EXPECTED_CATEGORY_SHAPE_REFUSED")
        for name in expected_categories:
            wire.uint(expected_categories[name])
            wire.uint(expected_charges[name])
        wire.need(categories == expected_categories and charges == expected_charges,
                  "V2_RECEIVER_INDEPENDENT_CHARGE_MISMATCH")
    return {"accounting": ACCOUNTING, "effective_limit_bytes": expected_limit,
            "limit_origin": expected_origin, "admitted_bytes": peak,
            "peak_accounted_decoded_bytes": peak,
            "categories": {name: wire.uint(size) for name, size in categories.items()},
            "charges": {name: wire.uint(count) for name, count in charges.items()},
            "independent_category_recomputation": "MATCHED" if independent else "PENDING",
            "measurement_domain": "cumulative logical decoded charge; never released"}


def receiver_rss(value):
    """Keep actual receiver lifetime RSS distinct from cumulative logical charge."""
    wire.fields(value, ("status", "method", "process_scope", "platform", "source_units", "peak_bytes"))
    wire.need(value["method"] == RSS_METHOD and value["process_scope"] == RSS_SCOPE and
              value["source_units"] == "KiB" and
              value["status"] in ("MEASURED", "NOT_MEASURED"),
              "V2_RECEIVER_RSS_METHOD_OR_SCOPE_REFUSED")
    peak = wire.uint(value["peak_bytes"])
    # Source has runtime.GOOS here. Do not turn unrecognized future platform
    # text into a public diagnostic or imply measurement on that platform.
    platforms = ("linux", "darwin", "windows", "freebsd", "openbsd", "netbsd",
                 "dragonfly", "solaris", "illumos", "aix", "android", "ios",
                 "plan9", "js", "wasip1")
    wire.need(value["platform"] in platforms, "V2_RECEIVER_RSS_PLATFORM_REFUSED")
    if value["status"] == "MEASURED":
        wire.need(value["platform"] == "linux" and peak % 1024 == 0,
                  "V2_RECEIVER_RSS_UNITS_REFUSED")
    else:
        wire.need(peak == 0, "V2_RECEIVER_UNMEASURED_RSS_NONZERO")
    return dict(value)


def decoded_refusal(value, *, expected_limit, expected_origin,
                    expected_categories=None, expected_charges=None):
    """Validate typed measured refusal; return REFUSED, never a success credit."""
    wire.fields(value, ("format", "refusal", "rss"))
    wire.need(value["format"] == NATIVE_REFUSAL, "V2_RECEIVER_REFUSAL_FORMAT_REFUSED")
    refusal = value["refusal"]
    wire.fields(refusal, ("accounting", "phase", "measured_bytes", "limit_bytes", "overflow",
                          "admitted_bytes", "rejected_charge_bytes", "admitted_usage"))
    wire.need(refusal["accounting"] == ACCOUNTING and type(refusal["phase"]) is str and
              refusal["phase"] in CATEGORIES and
              wire.uint(refusal["limit_bytes"]) == expected_limit and
              type(refusal["overflow"]) is bool, "V2_RECEIVER_REFUSAL_FIELDS_REFUSED")
    usage = decoded_usage(refusal["admitted_usage"], expected_limit=expected_limit,
                          expected_origin=expected_origin, expected_categories=expected_categories,
                          expected_charges=expected_charges)
    admitted = wire.uint(refusal["admitted_bytes"])
    rejected = wire.uint(refusal["rejected_charge_bytes"])
    measured = wire.uint(refusal["measured_bytes"])
    wire.need(admitted == usage["admitted_bytes"], "V2_RECEIVER_REFUSAL_ADMITTED_MISMATCH")
    attempted = admitted + rejected  # Python exact integer; compare before uint64 conversion.
    overflow = attempted > wire.UINT64_MAX
    wire.need(refusal["overflow"] == overflow and
              measured == (wire.UINT64_MAX if overflow else attempted) and
              (overflow or attempted > expected_limit),
              "V2_RECEIVER_REFUSAL_MEASURED_ARITHMETIC_MISMATCH")
    return {"status": "REFUSED", "reason": "NATIVE_DECODED_LIMIT",
            "phase": refusal["phase"], "admitted_usage": usage,
            "rejected_charge_bytes": rejected, "would_retain_measured_bytes": measured,
            "overflow": overflow, "rss": receiver_rss(value["rss"]),
            "publication_authorized": False, "original_stream_binding": "PENDING"}


def success_metadata(metadata, verification, rss, *, replay,
                     expected_limit, expected_origin,
                     expected_categories=None, expected_charges=None):
    """Validate the non-array fields extracted from native_delta/verification.

    metadata is precisely native_delta minus verification and rss;
    verification is precisely verification minus commits. An extractor must
    enforce the original outer/inner closed shapes and emit every commit via
    CommitProofs. This split is an internal streaming API, not new wire JSON.
    """
    wire.need(replay.structural_verified, "V2_RECEIVER_UNVERIFIED_REPLAY")
    wire.fields(metadata, ("format", "decoded_limit_origin"))
    wire.need(metadata["format"] == NATIVE_RECEIPT and
              metadata["decoded_limit_origin"] == expected_origin,
              "V2_RECEIVER_NATIVE_METADATA_MISMATCH")
    wire.fields(verification, ("contract", "totals", "head_root_sha256",
                               "current_root_sha256", "decoded_usage"))
    wire.totals(verification["totals"])
    wire.digest(verification["head_root_sha256"])
    wire.digest(verification["current_root_sha256"])
    wire.need(verification["contract"] == wire.CONTRACT and
              verification["totals"] == replay.counts and
              verification["head_root_sha256"] == replay.head_root and
              verification["current_root_sha256"] == replay.current_root,
              "V2_RECEIVER_REPLAY_TOTALS_OR_ROOTS_MISMATCH")
    usage = decoded_usage(verification["decoded_usage"], expected_limit=expected_limit,
                          expected_origin=expected_origin, expected_categories=expected_categories,
                          expected_charges=expected_charges)
    return {"status": "RECEIVER_METADATA_MATCHED_INTEGRATION_PENDING",
            "decoded_usage": usage, "rss": receiver_rss(rss),
            "publication_authorized": False,
            "commit_proofs": "SEPARATE_STREAM_REQUIRED",
            "original_stream_binding": "PENDING",
            "admission_import_and_reopened_readback": "PENDING"}


class CommitProofs:
    """Constant-memory event comparison with the independently staged states.

    No synthetic/reconstructed input is original evidence. Later extraction
    must bind these events to one complete original receipt and its exact
    declared commit-array length, with no omitted fields or trailing bytes.
    """

    def __init__(self, replay):
        wire.need(replay.structural_verified and replay.db is not None,
                  "V2_RECEIVER_PROOFS_REPLAY_NOT_READY")
        self.replay = replay
        self.commits = self.tables = 0
        self.active = None
        self.finished = False

    def begin(self, record):
        """A NativeDeltaCommitProof minus its streamed tables object."""
        wire.need(not self.finished and self.active is None,
                  "V2_RECEIVER_PROOF_COMMIT_ORDER_REFUSED")
        wire.fields(record, ("sequence", "commit_id", "schema_id", "root_sha256"))
        sequence = wire.uint(record["sequence"])
        wire.text(record["commit_id"])
        wire.digest(record["schema_id"])
        wire.digest(record["root_sha256"])
        wire.need(sequence == wire.add(self.commits, 1), "V2_RECEIVER_PROOF_SEQUENCE_MISMATCH")
        expected = self.replay._one(
            "SELECT c.id, s.schema_id, s.root, c.state_id FROM commits c "
            "JOIN states s ON s.id=c.state_id WHERE c.sequence=? AND s.complete=1",
            (wire.u(sequence),))
        wire.need(expected is not None and expected[:3] ==
                  (record["commit_id"], record["schema_id"], record["root_sha256"]),
                  "V2_RECEIVER_PROOF_COMMIT_MISMATCH")
        cursor = self.replay._execute(
            "SELECT name, rows, sha256 FROM state_tables WHERE state_id=? ORDER BY name",
            (expected[3],))
        self.active = {"cursor": cursor, "next": cursor.fetchone()}

    def table(self, name, digest):
        """One actual Go table digest with exact uppercase Rows/SHA256 names."""
        wire.need(self.active is not None and not self.finished, "V2_RECEIVER_PROOF_TABLE_ORDER_REFUSED")
        encoded_name = wire.text(name)
        wire.fields(digest, ("Rows", "SHA256"))
        rows = wire.uint(digest["Rows"])
        wire.digest(digest["SHA256"])
        expected = self.active["next"]
        wire.need(expected is not None and expected ==
                  (encoded_name, wire.u(rows), digest["SHA256"]),
                  "V2_RECEIVER_PROOF_TABLE_MISMATCH")
        self.tables = wire.add(self.tables, 1)
        self.active["next"] = self.active["cursor"].fetchone()

    def end(self):
        wire.need(self.active is not None and self.active["next"] is None,
                  "V2_RECEIVER_PROOF_TABLES_INCOMPLETE")
        self.active["cursor"].close()
        self.active = None
        self.commits = wire.add(self.commits, 1)

    def finish(self):
        wire.need(not self.finished and self.active is None and
                  self.commits == self.replay.counts["commits"],
                  "V2_RECEIVER_PROOF_COMMIT_COUNT_MISMATCH")
        self.finished = True
        return {"status": "RECEIVER_COMMIT_PROOFS_MATCHED_INTEGRATION_PENDING",
                "commits": self.commits, "commit_tables": self.tables,
                "publication_authorized": False,
                "original_stream_binding": "PENDING"}

    def close(self):
        if self.active is not None:
            self.active["cursor"].close()
            self.active = None
        self.finished = True
