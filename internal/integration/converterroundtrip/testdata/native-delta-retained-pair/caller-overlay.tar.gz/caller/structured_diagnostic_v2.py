"""Project structured diagnostics onto closed public codes and numeric fields.

This projection supplies observations, never publication or private-run approval.
Unknown codes lose their spelling; independently validated fields survive.
"""
import json
import re

FORMAT = 'beads-capture-diagnostic/1'
UNRECOGNIZED = 'UNRECOGNIZED_CODE'
STAGES = ('history-walk', 'schema', 'table-scan', 'row-decode', 'archive-read', 'report')
REASONS = ('ghost_parent', 'missing_root_chunk', 'missing_table_chunk', 'missing_archive_chunk', 'unreadable_schema', 'other', 'inconsistent_store', 'ancestry_unavailable', 'commit_ancestry_cycle', 'commit_ancestry_missing', 'commit_census_limit_or_empty', 'commit_census_unavailable', 'contradictory_boundary_cursor', 'contradictory_physical_ancestry', 'contradictory_physical_census', 'contradictory_presence_probe', 'duplicate_commit', 'duplicate_historical_table', 'head_image_differs_versioned_family', 'head_image_missing_versioned_family', 'head_unavailable', 'historical_image_unavailable', 'historical_schema_unavailable', 'historical_schema_unmappable', 'image_census_limit', 'invalid_ancestry', 'invalid_commit', 'invalid_commit_census', 'invalid_head', 'invalid_image_request', 'invalid_native_history_boundary', 'missing_scoped_reader', 'native_head_image_unavailable', 'native_history_boundary', 'native_history_head_unavailable', 'native_history_reader_unavailable', 'native_image_census_limit', 'native_physical_root_capability_unavailable', 'native_portable_commit_census_mismatch', 'native_table_limit', 'presence_boundary_crosses_present_branch', 'row_limit', 'source_census_changed', 'table_size_limit', 'unauthenticated_history', 'unobserved_parent', 'unreachable_commit_census', 'working_set_not_clean', 'working_set_unavailable')
BOUNDARY_REASONS = ('ghost_parent', 'missing_root_chunk', 'missing_table_chunk', 'missing_archive_chunk', 'unreadable_schema', 'other')
ROW_CLASSES = ('unmeasured', 'empty', 'single', 'series')
# This finite source-derived list is coordinated with the sole reader author.
GO_ERROR_TYPES = ('*main.captureFailure', '*main.unsupportedCaptureSchema', '*plugdump.NativeCommitFailure', 'plugdump.ErrSourceHistoryUnavailable', '*plugdump.ErrSourceHistoryUnavailable', 'plugdump.ErrUnsupportedNativeCommitSchema', '*plugdump.ErrUnsupportedNativeCommitSchema', '*embedded.PhysicalReadError', '*embedded.PhysicalHistoryUnavailable', '*embedded.PhysicalStoreInconsistent', '*embedded.physicalErrorEvidence', '*embedded.physicalCleanupFailure', '*embedded.storedChunkAbsent', '*embedded.physicalRowDecodePanic', '*chunks.MissingChunkError', '*mysql.MySQLError', '*mysql.SQLError', '*errors.Error', '*errors.errorString', '*errors.joinError', '*fmt.wrapError', '*fmt.wrapErrors', '*fs.PathError', '*os.LinkError', '*os.SyscallError', 'syscall.Errno', 'context.deadlineExceededError', 'runtime.errorString', 'runtime.boundsError', '*runtime.TypeAssertionError', '*strconv.NumError', '*json.SyntaxError', '*json.UnmarshalTypeError', '*json.InvalidUnmarshalError', '*json.UnsupportedTypeError', '*json.UnsupportedValueError', '*json.MarshalerError')
PUBLIC_IDENTIFIERS = {'bd_events_journal': ['seq',
                       'ts',
                       'op',
                       'issue_id',
                       'issue_json',
                       'dep_json',
                       'comment_json',
                       'actor'],
 'bd_events_seq': ['id', 'next_seq'],
 'child_counters': ['parent_id', 'last_child'],
 'comments': ['id', 'issue_id', 'author', 'text', 'created_at'],
 'compaction_snapshots': ['id', 'issue_id', 'compaction_level', 'snapshot_json', 'created_at'],
 'config': ['key', 'value'],
 'custom_statuses': ['name', 'category'],
 'custom_types': ['name'],
 'dependencies': ['id',
                  'issue_id',
                  'depends_on_issue_id',
                  'depends_on_wisp_id',
                  'depends_on_external',
                  'type',
                  'created_at',
                  'created_by',
                  'metadata',
                  'thread_id'],
 'dolt_ignore': ['pattern', 'ignored'],
 'dolt_log': ['commit_hash', 'committer', 'email', 'date', 'message'],
 'dolt_nonlocal_tables': ['table_name', 'target_ref', 'ref_table', 'options'],
 'dolt_status': ['table_name', 'staged', 'status'],
 'epoch_minted_addresses': ['address',
                            'store_id',
                            'minted_id',
                            'minted_epoch',
                            'minted_at',
                            'carried_from',
                            'gone_at_epoch'],
 'events': ['id',
            'issue_id',
            'event_type',
            'actor',
            'old_value',
            'new_value',
            'comment',
            'created_at'],
 'federation_peers': ['name',
                      'remote_url',
                      'username',
                      'password_encrypted',
                      'sovereignty',
                      'last_sync',
                      'created_at',
                      'updated_at'],
 'ignored_schema_migrations': ['version', 'applied_at', 'content_hash'],
 'interactions': ['id',
                  'kind',
                  'created_at',
                  'actor',
                  'issue_id',
                  'model',
                  'prompt',
                  'response',
                  'error',
                  'tool_name',
                  'exit_code',
                  'parent_id',
                  'label',
                  'reason',
                  'extra'],
 'issue_counter': ['prefix', 'last_id'],
 'issue_snapshots': ['id',
                     'issue_id',
                     'snapshot_time',
                     'compaction_level',
                     'original_size',
                     'compressed_size',
                     'original_content',
                     'archived_events'],
 'issue_versions': ['issue_id',
                    'revision',
                    'epoch',
                    'durable_state',
                    'change_actor',
                    'change_agent',
                    'change_message',
                    'change_at',
                    'removed_at',
                    'removed_reason',
                    'attribution_status',
                    'removed_restriction'],
 'issues': ['id',
            'content_hash',
            'title',
            'description',
            'design',
            'acceptance_criteria',
            'notes',
            'status',
            'priority',
            'issue_type',
            'assignee',
            'estimated_minutes',
            'created_at',
            'created_by',
            'owner',
            'updated_at',
            'closed_at',
            'closed_by_session',
            'external_ref',
            'spec_id',
            'compaction_level',
            'compacted_at',
            'compacted_at_commit',
            'original_size',
            'sender',
            'ephemeral',
            'wisp_type',
            'pinned',
            'is_template',
            'mol_type',
            'work_type',
            'source_system',
            'metadata',
            'source_repo',
            'close_reason',
            'event_kind',
            'actor',
            'target',
            'payload',
            'await_type',
            'await_id',
            'timeout_ns',
            'waiters',
            'hook_bead',
            'role_bead',
            'agent_state',
            'last_activity',
            'role_type',
            'rig',
            'due_at',
            'defer_until',
            'no_history',
            'started_at',
            'is_blocked',
            'row_lock',
            'storage_class',
            'current_revision',
            'participation_generation'],
 'labels': ['issue_id', 'label'],
 'leases': ['issue_id', 'holder', 'granted_at', 'lease_expires_at', 'heartbeat_at', 'granted_node'],
 'local_metadata': ['key', 'value'],
 'metadata': ['key', 'value'],
 'provenance_events': ['id',
                       'issue_id',
                       'kind',
                       'actor',
                       'ref',
                       'ref_kind',
                       'payload',
                       'source',
                       'occurred_at',
                       'created_at'],
 'repo_mtimes': ['repo_path', 'jsonl_path', 'mtime_ns', 'last_checked'],
 'routes': ['prefix', 'path', 'created_at', 'updated_at'],
 'schema_migrations': ['version', 'content_hash'],
 'store_epoch': ['id', 'epoch', 'bumped_at', 'bumped_reason'],
 'wisp_child_counters': ['parent_id', 'last_child'],
 'wisp_comments': ['id', 'issue_id', 'author', 'text', 'created_at'],
 'wisp_dependencies': ['id',
                       'issue_id',
                       'depends_on_issue_id',
                       'depends_on_wisp_id',
                       'depends_on_external',
                       'type',
                       'created_at',
                       'created_by',
                       'metadata',
                       'thread_id'],
 'wisp_events': ['id',
                 'issue_id',
                 'event_type',
                 'actor',
                 'old_value',
                 'new_value',
                 'comment',
                 'created_at'],
 'wisp_labels': ['issue_id', 'label'],
 'wisps': ['id',
           'content_hash',
           'title',
           'description',
           'design',
           'acceptance_criteria',
           'notes',
           'status',
           'priority',
           'issue_type',
           'assignee',
           'estimated_minutes',
           'created_at',
           'created_by',
           'owner',
           'updated_at',
           'closed_at',
           'closed_by_session',
           'external_ref',
           'spec_id',
           'compaction_level',
           'compacted_at',
           'compacted_at_commit',
           'original_size',
           'sender',
           'ephemeral',
           'wisp_type',
           'pinned',
           'is_template',
           'mol_type',
           'work_type',
           'source_system',
           'metadata',
           'source_repo',
           'close_reason',
           'event_kind',
           'actor',
           'target',
           'payload',
           'await_type',
           'await_id',
           'timeout_ns',
           'waiters',
           'hook_bead',
           'role_bead',
           'agent_state',
           'last_activity',
           'role_type',
           'rig',
           'due_at',
           'defer_until',
           'no_history',
           'started_at',
           'is_blocked',
           'row_lock',
           'storage_class',
           'current_revision',
           'participation_generation']}
FIELDS = frozenset(('format', 'stage', 'schema_migrations', 'go_error_types',
                    'sql_dolt_codes', 'table', 'column', 'innermost_go_error_type',
                    'commit_schema_version', 'commit_ordinal_from_head',
                    'history_boundary_reason', 'verified_commit_count', 'reason_subcode',
                    'unrecognized_go_error_type_count'))
MAX_BYTES = 8 * 1024 * 1024


class Refusal(Exception):
    pass


class NumberToken(str):
    """Keep a number token until its own field is validated."""


def diagnostic_json(data):
    if type(data) not in (str, bytes) or len(data) > MAX_BYTES:
        raise Refusal('CURRENT_DIAGNOSTIC_BYTES_REFUSED')

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise Refusal('DUPLICATE_JSON_KEYS_REFUSED')
            result[key] = value
        return result

    return json.loads(data, parse_int=NumberToken, parse_float=NumberToken,
                      parse_constant=NumberToken, object_pairs_hook=pairs)


def uint(value, *, minimum=0, maximum=2**64-1, nullable=False):
    if value is None:
        return (True, None) if nullable else (False, None)
    if type(value) is NumberToken:
        if len(value) > 20 or re.fullmatch(r'0|[1-9][0-9]*', value) is None:
            return False, None
        value = int(value)
    if type(value) is int and minimum <= value <= maximum:
        return True, value
    return False, None


def project(value):
    if type(value) is not dict or 'format' not in value:
        raise Refusal('CURRENT_DIAGNOSTIC_NOT_OBJECT_OR_FORMAT_MISSING')
    out, unknown, invalid = {}, {}, {}
    discarded = len(set(value) - FIELDS)

    def count(target, name):
        target[name] = target.get(name, 0) + 1

    def code(name, item, allowed, *, nullable=False):
        if item is None and nullable:
            return None
        if type(item) is str and item in allowed:
            return item
        count(unknown, name)
        return UNRECOGNIZED

    def number(name, item, target, *, minimum=0, maximum=2**64-1, nullable=False):
        valid, checked = uint(item, minimum=minimum, maximum=maximum, nullable=nullable)
        if valid:
            target[name.rsplit('.', 1)[-1]] = checked
        else:
            count(invalid, name)

    out['format'] = code('format', value['format'], (FORMAT,))
    if 'stage' in value:
        out['stage'] = code('stage', value['stage'], STAGES)
    if 'schema_migrations' in value:
        schema = value['schema_migrations']
        if type(schema) is dict:
            observed = {}
            discarded += len(set(schema) - {'expected_version', 'found_version', 'row_count_class'})
            for name in ('expected_version', 'found_version'):
                if name in schema:
                    number('schema_migrations.' + name, schema[name], observed, nullable=True)
            if 'row_count_class' in schema:
                observed['row_count_class'] = code('schema_migrations.row_count_class',
                                                  schema['row_count_class'], ROW_CLASSES)
            out['schema_migrations'] = observed
        else:
            count(invalid, 'schema_migrations')
    for name in ('commit_schema_version', 'commit_ordinal_from_head', 'verified_commit_count'):
        if name in value:
            number(name, value[name], out, nullable=True,
                   minimum=1 if name == 'commit_ordinal_from_head' else 0)
    if 'unrecognized_go_error_type_count' in value:
        number('unrecognized_go_error_type_count', value['unrecognized_go_error_type_count'], out)
    for name in ('reason_subcode', 'history_boundary_reason'):
        if name in value:
            out[name] = code(name, value[name], REASONS if name == 'reason_subcode' else BOUNDARY_REASONS,
                             nullable=name == 'reason_subcode')
    if 'table' in value:
        out['table'] = code('table', value['table'], PUBLIC_IDENTIFIERS, nullable=True)
    if 'column' in value:
        table = value.get('table')
        columns = PUBLIC_IDENTIFIERS.get(table, ()) if type(table) is str else ()
        out['column'] = code('column', value['column'], columns)
    if 'innermost_go_error_type' in value:
        out['innermost_go_error_type'] = code('innermost_go_error_type',
                                               value['innermost_go_error_type'], GO_ERROR_TYPES, nullable=True)
    for name in ('go_error_types', 'sql_dolt_codes'):
        if name not in value:
            continue
        items = value[name]
        limit = 128 if name == 'go_error_types' else 65535
        if type(items) is not list:
            count(invalid, name)
            continue
        checked = []
        for item in items:
            if name == 'go_error_types':
                checked.append(code(name, item, GO_ERROR_TYPES))
            else:
                valid, number_value = uint(item, minimum=1, maximum=65535)
                if valid:
                    checked.append(number_value)
                else:
                    count(invalid, name)
        if len(items) > limit:
            count(invalid, name)
        out[name] = checked
    return out, {'unrecognized_code_counts': unknown, 'invalid_field_counts': invalid,
                 'discarded_free_text_fields': discarded}


def safe_stream(data):
    if type(data) not in (bytes, str) or len(data) > MAX_BYTES:
        raise Refusal('CURRENT_DIAGNOSTIC_BYTES_REFUSED')
    reports, withheld, refusals = [], 0, {}
    unknown, invalid, discarded = {}, {}, 0
    for line in data.splitlines():
        if not line.strip():
            continue
        try:
            report, counts = project(diagnostic_json(line))
        except Refusal as failure:
            category = str(failure)
        except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
            category = 'CURRENT_DIAGNOSTIC_INPUT_REFUSED'
        else:
            reports.append(report)
            for name, amount in counts['unrecognized_code_counts'].items():
                unknown[name] = unknown.get(name, 0) + amount
            for name, amount in counts['invalid_field_counts'].items():
                invalid[name] = invalid.get(name, 0) + amount
            discarded += counts['discarded_free_text_fields']
            continue
        withheld += 1
        refusals[category] = refusals.get(category, 0) + 1
    return {'reports': reports, 'nonreport_lines_withheld': withheld, 'refusal_counts': refusals,
            'unrecognized_code_counts': unknown, 'invalid_field_counts': invalid,
            'discarded_free_text_fields': discarded}


def contains_unrecognized(value):
    if type(value) is dict:
        return any(contains_unrecognized(item) for item in value.values())
    if type(value) is list:
        return any(contains_unrecognized(item) for item in value)
    return value == UNRECOGNIZED
