"""Independent schema/row/graph policy integration, AUTHORED_NOT_RUN.

New source above the unchanged reviewed wire/replay/row modules. This is
not a procedure or publication/admission decision. Its mandatory hook checks
every value-bearing record before replay retains it; disk scans then check
every complete state, canonical graph coordinates, current config authority,
and declared-family classification. Portable head/events, inventory/evidence,
receiver category preimages, admission and persistent readback remain separate.
No aggregate native history/parts/evidence ceiling is introduced.
"""

import re
import sqlite3

import native_delta_wire_v2 as wire
import native_delta_replay_v2 as structural
import native_delta_row_policy_v2 as row_policy


PRODUCER_PIN = "4fc110b29f662d8f4015ae286cda162fc3830ac8"
REGISTRY_SHA256 = "900320651fedf60f29686f928c4febba7513f0cb802c8f85399526d058b3aa44"
_SQL_NAME = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]{0,127}\Z")
_COMMIT_ID = re.compile(r"[0-9a-v]{32}\Z")
_PROJECT = re.compile(r"[a-zA-Z][a-zA-Z0-9_-]{0,31}\Z")
_NATURAL = re.compile(r"[0-9]+\Z")
_UNVERSIONED = frozenset((
    "bd_events_journal", "bd_events_seq", "events", "ignored_schema_migrations",
    "leases", "local_metadata", "repo_mtimes", "wisp_child_counters",
    "wisp_comments", "wisp_dependencies", "wisp_events", "wisp_labels", "wisps"))

# BEGIN EXACT SOURCE-VERIFIED COMPARISON REGISTRY
_SURFACES = {'bd_events_journal': ['actor',
                       'comment_json',
                       'dep_json',
                       'issue_id',
                       'issue_json',
                       'op',
                       'seq',
                       'ts'],
 'bd_events_seq': ['id', 'next_seq'],
 'child_counters': ['last_child', 'parent_id'],
 'comments': ['author', 'created_at', 'id', 'issue_id', 'text'],
 'compaction_snapshots': ['compaction_level', 'created_at', 'id', 'issue_id', 'snapshot_json'],
 'config': ['key', 'value'],
 'custom_statuses': ['category', 'name'],
 'custom_types': ['name'],
 'dependencies': ['created_at',
                  'created_by',
                  'depends_on_external',
                  'depends_on_id',
                  'depends_on_issue_id',
                  'depends_on_wisp_id',
                  'id',
                  'issue_id',
                  'metadata',
                  'thread_id',
                  'type'],
 'epoch_minted_addresses': ['address',
                            'carried_from',
                            'gone_at_epoch',
                            'minted_at',
                            'minted_epoch',
                            'minted_id',
                            'store_id'],
 'events': ['actor',
            'comment',
            'created_at',
            'event_type',
            'id',
            'issue_id',
            'new_value',
            'old_value'],
 'federation_peers': ['created_at',
                      'last_sync',
                      'name',
                      'password_encrypted',
                      'remote_url',
                      'sovereignty',
                      'updated_at',
                      'username'],
 'ignored_schema_migrations': ['applied_at', 'content_hash', 'version'],
 'interactions': ['actor',
                  'created_at',
                  'error',
                  'exit_code',
                  'extra',
                  'id',
                  'issue_id',
                  'kind',
                  'label',
                  'model',
                  'parent_id',
                  'prompt',
                  'reason',
                  'response',
                  'tool_name'],
 'issue_counter': ['last_id', 'prefix'],
 'issue_snapshots': ['archived_events',
                     'compaction_level',
                     'compressed_size',
                     'id',
                     'issue_id',
                     'original_content',
                     'original_size',
                     'snapshot_time'],
 'issue_versions': ['attribution_status',
                    'change_actor',
                    'change_agent',
                    'change_at',
                    'change_message',
                    'durable_state',
                    'epoch',
                    'issue_id',
                    'removed_at',
                    'removed_reason',
                    'removed_restriction',
                    'revision'],
 'issues': ['acceptance_criteria',
            'actor',
            'agent_state',
            'assignee',
            'await_id',
            'await_type',
            'close_reason',
            'closed_at',
            'closed_by_session',
            'compacted_at',
            'compacted_at_commit',
            'compaction_level',
            'content_hash',
            'created_at',
            'created_by',
            'crystallizes',
            'current_revision',
            'defer_until',
            'description',
            'design',
            'due_at',
            'ephemeral',
            'estimated_minutes',
            'event_kind',
            'external_ref',
            'heartbeat_at',
            'hook_bead',
            'id',
            'is_blocked',
            'is_template',
            'issue_type',
            'last_activity',
            'lease_expires_at',
            'metadata',
            'mol_type',
            'no_history',
            'notes',
            'original_size',
            'owner',
            'participation_generation',
            'payload',
            'pinned',
            'priority',
            'quality_score',
            'rig',
            'role_bead',
            'role_type',
            'row_lock',
            'sender',
            'source_repo',
            'source_system',
            'spec_id',
            'started_at',
            'status',
            'storage_class',
            'target',
            'timeout_ns',
            'title',
            'updated_at',
            'waiters',
            'wisp_type',
            'work_type'],
 'labels': ['issue_id', 'label'],
 'leases': ['granted_at', 'granted_node', 'heartbeat_at', 'holder', 'issue_id', 'lease_expires_at'],
 'local_metadata': ['key', 'value'],
 'metadata': ['key', 'value'],
 'provenance_events': ['actor',
                       'created_at',
                       'id',
                       'issue_id',
                       'kind',
                       'occurred_at',
                       'payload',
                       'ref',
                       'ref_kind',
                       'source'],
 'repo_mtimes': ['jsonl_path', 'last_checked', 'mtime_ns', 'repo_path'],
 'routes': ['created_at', 'path', 'prefix', 'updated_at'],
 'schema_migrations': ['applied_at', 'content_hash', 'version'],
 'store_epoch': ['bumped_at', 'bumped_reason', 'epoch', 'id'],
 'wisp_child_counters': ['last_child', 'parent_id'],
 'wisp_comments': ['author', 'created_at', 'id', 'issue_id', 'text'],
 'wisp_dependencies': ['created_at',
                       'created_by',
                       'depends_on_external',
                       'depends_on_id',
                       'depends_on_issue_id',
                       'depends_on_wisp_id',
                       'id',
                       'issue_id',
                       'metadata',
                       'thread_id',
                       'type'],
 'wisp_events': ['actor',
                 'comment',
                 'created_at',
                 'event_type',
                 'id',
                 'issue_id',
                 'new_value',
                 'old_value'],
 'wisp_labels': ['issue_id', 'label'],
 'wisps': ['acceptance_criteria',
           'actor',
           'agent_state',
           'assignee',
           'await_id',
           'await_type',
           'close_reason',
           'closed_at',
           'closed_by_session',
           'compacted_at',
           'compacted_at_commit',
           'compaction_level',
           'content_hash',
           'created_at',
           'created_by',
           'crystallizes',
           'current_revision',
           'defer_until',
           'description',
           'design',
           'due_at',
           'ephemeral',
           'estimated_minutes',
           'event_kind',
           'external_ref',
           'heartbeat_at',
           'hook_bead',
           'id',
           'is_blocked',
           'is_template',
           'issue_type',
           'last_activity',
           'lease_expires_at',
           'metadata',
           'mol_type',
           'no_history',
           'notes',
           'original_size',
           'owner',
           'participation_generation',
           'payload',
           'pinned',
           'priority',
           'quality_score',
           'rig',
           'role_bead',
           'role_type',
           'row_lock',
           'sender',
           'source_repo',
           'source_system',
           'spec_id',
           'started_at',
           'status',
           'storage_class',
           'target',
           'timeout_ns',
           'title',
           'updated_at',
           'waiters',
           'wisp_type',
           'work_type']}
_PREFIXES = {'ignored': {'1': 'a73e9a486124f89e90d50f4597fd1d7ad08e5d0d654459ec87b7520b47f1bb5f',
             '10': '59d6644667b7e34f9d23261cb694d461ddd4953969e75519d370b0cce8afd0e8',
             '11': '0efade0ecb620420ee42127d3f67230da108e31f2ff3c4281855a8dc9e187ecd',
             '12': 'e128a1301a2bcb967f684b09318aa5cf7ed9adb5f6dd7d412de3d67d1de2b28d',
             '13': '127a4af7012769e5f016b13b198b7a57ff8386a10f8a68ffb9ff204989564d1b',
             '14': '29ad3654218700481b9541331c714ecbbe96dc81c04dc83fba6bf8d35bed7fa4',
             '15': 'e761d5c3ceb9610edbb2e1d153e82d235cc7d7f0b87f28a45bec43835e6a4e19',
             '16': '31a55421b78d8c90db6cfba5bf8e99e87d6123271575282f761aa077e5d36386',
             '17': '1f031aaf2037280e62cbf604748a4157bf25e3a60b3392af7d74835c5059bdd8',
             '18': '3c2120bf55d15e71a9f96972007c3d914154d17ea37a2b51b44412e3e3df6ef1',
             '19': 'db072d67a403e60d5bcbe924b84e473adb09f2326d36ede82fcdab17bb1e2a87',
             '2': 'c575c6710169f2e697f3aca60f5f698acc8a64af0edb1e2305b9d377fd845f45',
             '20': '9ff476e6c73a3a477aec95143d5cbf180517a9484f647447392576f13181a015',
             '21': '3cfa1e07a3d02eb7f791814d9642a93b9af3bf63728943afa05dcb0e489919c8',
             '22': '3d0adcb9f5833b4ba70fb48f88e1043250796feb7173abe000ea4de85eb8b3a5',
             '23': 'd0edd83ca4cfbc46bd17799c6497a70c8c011d130d08a00c71daf792ee1dcd51',
             '24': '69a96330e00643dfeddc4bf6ae9bf3b743a3cfddd86f16dc7b8912758b1b570d',
             '25': 'c81ca9edc80c25f6ab4f92d05d6ea412a780b108d1ed83745027440e9723dceb',
             '26': 'dc5c1b9a74e42184451796068ecba1ca11d8ebd0fe7e8c4bd4900d0cfee30446',
             '27': '59bf3bea7ab1b7a5be03816dec7f3e57c082d5564e6691b4405d1b73b0ad90c9',
             '28': 'c1b9ef1e7a51de8e62ba01b171f93159b2e89af1b747e5595618e668c239eff0',
             '3': 'f82947deeafe589598e2a1802eddf17712bd322692f924bb5653b0fbd5c46a0d',
             '4': '12e18a8bdd214d6f96625e78998433ccc9c2d0ef4d1a35307f2653e725c800b9',
             '5': '08780b28ddef6c15f5de558ea08d821b52610f810555739ee1d737779986c607',
             '6': '4746f10d7040d0b7a9e127437356de87765d12d2d27ee37c9800191e6b619d14',
             '7': 'c3c8d92846a54183cc99afc09f779f6f5ba8030c16ce46b3ee750314bf134627',
             '8': '51375854ec081d2e0b1434b5ff8b6d87092b891636214ebb9f1dbef22438cc1a',
             '9': '3d1ee4f9dde3342d110474c8090a30c474edafe2290e4372a3fc4607c1fdc030'},
 'main': {'1': '0c9bc4d97e2c5ee5d276c952333b934cd7d7d18210997d6bfd72d17f0fdb14f0',
          '10': 'cb34cbe311fd89a17d72067f449a65089f2fc9a7c4b3774d54448db5ebc3d659',
          '11': 'bde5204466541dddb53a652fe58561c08b6b3c1fa7feb38a0a582d432d76bda6',
          '12': '68e8ef1fc336e8ca6973f6b927b09d3206a7ebd96db9c4cdceab52fb8498c431',
          '13': '7ddb30dabe32a66197de78f62400f41d000cf43d0ba8ba2a3943536504dddcdb',
          '14': '0e17f1cb9fc5ee5a7c43ca8e02b9fd59814f8fd4372f9ffb17b50c34388614ce',
          '15': '6aa04b3f66566b243c9a4fc09136af5c17f0ffe947a489245e3c451b995a59b9',
          '16': '5d556c01404eb06acfb9df2b20fde36a2e91bd8a7d14462acbd3c0ae928ea286',
          '17': '4bab7acbe2d8e441f156cc5912f421dcb214b9b08d7958eacc8e3a7318ab5f57',
          '18': '84dc6a3950a5447e6665e3d98b43f11a7631dc4e53bab1be332d135e51c9511f',
          '19': '3df660feb6b64c84ef74c408fe8f5840a2815936534362ed123122f795a21c26',
          '2': '9ca011fa0b24ddf26f689eebf347cc2f80dc90256b099d91b993ec82c4d74da5',
          '20': 'bca95662441635454b879bb44ca1e607df9c5efd8fd802be3d53a7371a5ced86',
          '21': 'd19284a2be70a448db7746ae009cb264dc86dac0d9094aae9fe80a713a08ee70',
          '22': 'fc1375e64620cd4264516718d8f924d88131881f4c00c51471b7630c11b74a45',
          '23': 'd11cd7cb462239e49c0b2f9b93ac73771106d5450ebc3422bb7737748c6f967b',
          '24': '816da3feeed531ca9787dca8d4b8072dd94b64d573cf4b6751c61f2390c88a68',
          '25': '09782d195f22d620ba41802856f9eb6e1a10f68bc5bcc8f3616624f8c28b576a',
          '26': '33daef6b5a07364fc5f59ab59b0f5c677dcf98d9bd0866c7c3bea874f1f01348',
          '27': 'dd3b58a8bbed4c49e855a6002981a285f10b6094938534dd3da9b121155f24d6',
          '28': '24a816406a6f40c66db98697869d172b2b4366b107788fdd00f44b99abee45c3',
          '29': 'b989fc49ab03e06ff6520f150d6958efdbd3f444b69b824f7b4bb283ca6f2b65',
          '3': '1780f0dc941d97b74af53d5603646d05e83d94eee5a02ac68ccf929200deaec0',
          '30': '8d55135274c1c75e722e802b250911cc574d52a4ba74fbb13edde84f30f9b3a4',
          '31': '2d5cf3a6d4245b48c1b893efcc17b9fa25f1ea807e61290cf54064451fc58d93',
          '32': '42b86d6b7352f7e158532cc67f4afa142dc2503ce9f780733c06fc9da3478751',
          '33': '9256746bb0d6ad9ed9afba0f0501259f0a3599b7d7da507dd7d808a13c688c75',
          '34': '7add95ead971c57618cfbc52e5cb6771d872785bfc035bde12cd27a76358848e',
          '35': 'f917fe319540155572f5c51618cbbe20ec8b9b669d5926d68e3a62629c317c5a',
          '36': 'e55f1870c2bc031c574b495ebca650365a9c8088d7a8968fb86a19cab81267e8',
          '37': '7526beadee13aa7d6ee2175e9a543210b07c1a4426c382f251ebd31eebe32745',
          '38': '002dc637d45840487c35a01ce15cee04872baa45c21f8e20170a4339135a38e7',
          '39': 'db65f241d1e82da41f34b960abc912f78b72e7dc1cb6dd2298974308edf8b768',
          '4': '35ac76b3d0b2d6287cad1329c77c8a0562bb6310ba0ac34ae273d72d4bed0e2a',
          '40': 'c7068d67ad3e2b4852549e04d97f25814121de83db919e220bdcb9bdd9b61e5e',
          '41': 'e84ef393576df31550570fd3217579b1880850c0645b7d2b6ad8cf55a18ac1c0',
          '42': '9d0fbb3d02955d25442c4a628ac518236068a97ecf164edbc814216bd5a55adc',
          '43': '548b8a69ab82179b7ee7ab3cc87ef00b3ae28d5a3a4976f42364f6939e384668',
          '44': '531524854cc0e2361817d1ad94ba9470b0e81e378a5422ffb8bce71f3500adf9',
          '45': '395dcbf186deedb592d8ed144e0b7953455efa0ccf02076d3b63e5e5d05dc241',
          '46': '4d6a5a5fc5e386f2c538b4f3574b82fb2ba025176997953a0a4fbd2a91cddf68',
          '47': '4aff5a7cc2e1e0250ce4cdb911d010c936681871fb627bceee4b2dc4647dd0a1',
          '48': '093c7a41145508879844d16cbe5acfa69baddbb19bf3e05f00bc08720adea657',
          '49': '3359343efb7c28e5803de07e9088670489615d151843d7f23705f3ca8dd6a1e8',
          '5': 'c8cbe4bebbe0f92c8a0ccc2a1a0d11ad442635811c2dab093c34c9341a8499b2',
          '50': '96265ff898753f3bb34549fafa18bbaeb67519705b8cf4e32e67f1058df6841a',
          '51': 'deb741d5ac5fc1e0cd2e60eb47e84f384ed3455b18d3e2f12cb4e935fe461059',
          '52': '60ae32bc26c41da2e743c1172f73930d18482b8a98aea08b9de85f6009f9c01d',
          '53': 'f13909f0db89f48db694a782d1805eee7ee1b2b2e4dcb3d4b12352333cbcb330',
          '54': '2e51058ba15be9d87415949bb03c2c7c2f0e0743c5ae0d3e819b617d95f61680',
          '55': '2237ddbe13f5a783c65da3bb1292d9a5d89a5f22fddb0c33d2db57f1492df22c',
          '56': 'acc28e9b1aa7272c16c86fcb9fd4a2038ae47729a60b53bb75f3a9df05cd3a82',
          '57': 'f86e0f77be2e58affe1c485767b8dd450408d782c0413a41948ca0c0b6d72d06',
          '58': '9c1c6d557a03e71cf6b49123831c9f5b5f910fcea3ca51e982ec4acce04ea6ec',
          '59': 'f0186029a1c87d579b67e0540ec22ad0bd0fc59793b07f7d24a24e122b77c394',
          '6': '435f5ef129dd4999a9b393c98d633038f0e443280a26e63f7d4315bf025dab1f',
          '60': '40419632ba75d92dfcf08e16e77a780f014172a17068f6021937df9086a24588',
          '61': 'd2d65b92789f137da8ee586067c862a9c7744921ccac421e1b793f42050b62a2',
          '62': 'c7de6089997344784a71e7d82ea5e417baaf66320b4533d225a4a6bc3c74222a',
          '63': '1ef173be07ca58d17cb09ba3b3f5ca0c96edfcace8d52ae3adde2fd27e8248bd',
          '64': '25ea9ad8e849dc7e32e7c5850631bedc63a5c5da3bdc58ccb2762fd7a6c758fc',
          '65': 'c7341bb977daff92e073db2579e63058cef88d43f1e09b13fa153a772caac2a6',
          '66': 'a524d42ba0eced9350edbf6402dc2952957ff8f75a896bc8339c4cbc8596c793',
          '67': '3e847922cb99c19d35dfcb7f76ee0aad0c956e7c11dffb575af1c601eadd7b6e',
          '68': '906e5eeda82f31d983b4d85bdec7ff1470c365f2b50605113075689c51eebe94',
          '69': '83eac6ffa400a5bd57c10f15f8f7f6b6cd8b133cba3a498808e7c256de583514',
          '7': 'f92c4d3dd32cae489142de34c4706900736c91cdc53b0d54e87e71656b828dc9',
          '70': 'a1be987f0b89af87e76db6a75f53bf400d1ddca5ff2d096cfe0db985880abfe4',
          '71': '46d95b41a56e14d3675b5d8bc8269e63991501497e7e7e899a821c20ef3534c2',
          '72': '779b66fcf99faf9250eba61bb3ae456fed111742ce71229981c6e09d309f72fa',
          '8': '99db9b4b5a785ddd209dff628364c4c1eff549c3ca5ec48a64c604b15ef95bfb',
          '9': '269ef83f083766b7f2fd2dfd2814ef36a585ae4aa18bcab0468a713d48595e48'}}
# END EXACT SOURCE-VERIFIED COMPARISON REGISTRY


def _name(value):
    wire.need(type(value) is str and _SQL_NAME.fullmatch(value) is not None,
              "V2_POLICY_SQL_NAME_REFUSED")
    return wire.text(value)


def _commit_id(value):
    wire.need(type(value) is str and _COMMIT_ID.fullmatch(value) is not None,
              "V2_POLICY_COMMIT_ID_REFUSED")
    return value


def _natural(value):
    # Match producer natural/strconv.ParseUint without arbitrary integer
    # expansion or a limit on leading zeros in one bounded SQL string.
    if type(value) is row_policy._Number:
        value = value.spelling
    wire.need(type(value) is str and _NATURAL.fullmatch(value) is not None,
              "V2_POLICY_MIGRATION_NATURAL_REFUSED")
    significant = value.lstrip("0") or "0"
    wire.need(len(significant) <= 20, "V2_POLICY_MIGRATION_NATURAL_OVERFLOW")
    return wire.uint(int(significant, 10))


def _ignored(value):
    if type(value) is bool:
        return value
    if type(value) in (int, wire.JSONInteger):
        wire.need(wire.uint(value) in (0, 1), "V2_POLICY_IGNORE_VALUE_REFUSED")
        return value == 1
    wire.need(type(value) is str and value in ("true", "false", "1", "0"),
              "V2_POLICY_IGNORE_VALUE_REFUSED")
    return value in ("true", "1")


def _ignore_row_bytes(value, guard):
    # The closed ignore row has only a string and a bool/int/string flag.
    # Adapt JSONInteger to a lossless token for the independent Go encoder.
    flag = value["ignored"]
    _ignored(flag)
    if type(flag) in (int, wire.JSONInteger):
        flag = row_policy._Number(str(flag))
    return b"".join(row_policy._go_json(
        {"ignored": flag, "pattern": value["pattern"]}, guard)) + b"\n"


def _folded_ascii_equal(pattern, name):
    # For an ASCII SQL name, rune-wise Unicode simple folding is enough.
    # Per-rune comparison deliberately excludes multi-rune full-fold
    # expansions such as sharp-s -> ss and dotted-I -> i + combining dot.
    return len(pattern) == len(name) and all(
        left.casefold() == right.lower() for left, right in zip(pattern, name))


class SemanticPolicy:
    """The actual mandatory StructuralReplay callback; no accept-all branch."""

    def __init__(self, *, guard):
        wire.need(callable(guard), "V2_POLICY_GUARD_REQUIRED")
        self.guard = guard
        self.header = None

    def _header(self, value):
        wire.need(self.header is None, "V2_POLICY_HEADER_REPEATED")
        _commit_id(value["head"])
        wire.text(value["store_id"])
        projects = wire.array(value["projects"])
        wire.need(bool(projects), "V2_POLICY_PROJECTS_REQUIRED")
        previous = None
        for project in projects:
            self.guard()
            wire.need(type(project) is str and _PROJECT.fullmatch(project) is not None and
                      (previous is None or previous < project),
                      "V2_POLICY_PROJECT_ORDER_OR_NAME_REFUSED")
            previous = project
        ignore = value["ignore"]
        wire.need(ignore["columns"] == ["ignored", "pattern"],
                  "V2_POLICY_IGNORE_COLUMNS_REFUSED")
        previous = None
        # This is the inherited per-table bound, not an aggregate wire cap.
        wire.need(len(ignore["rows"]) <= 100000, "V2_POLICY_IGNORE_TABLE_LIMIT_REFUSED")
        for item in ignore["rows"]:
            self.guard()
            wire.fields(item, ("ignored", "pattern"))
            wire.text(item["pattern"], empty=True)
            encoded = _ignore_row_bytes(item, self.guard)
            wire.need(previous is None or previous <= encoded,
                      "V2_POLICY_IGNORE_ROW_ORDER_REFUSED")
            previous = encoded
        for key, setting in value["config_policy"].items():
            self.guard()
            wire.text(key)
            family, separator, name = key.partition("/")
            wire.need(separator == "/" and family in ("config", "metadata") and name != "" and
                      setting in ("public", "secret"), "V2_POLICY_CONFIG_SCOPE_REFUSED")
        coverage = value["history_coverage"]
        if coverage is not None:
            wire.need(coverage["format"] == "beads-native-history-coverage/1" and
                      coverage["status"] == "verified-to-boundary" and
                      coverage["verified_commit_count"] == value["commit_count"] and
                      len(coverage["boundaries"]) > 0,
                      "V2_POLICY_COVERAGE_DESCRIPTOR_REFUSED")
            previous = None
            for boundary in coverage["boundaries"]:
                self.guard()
                ident = _commit_id(boundary["commit_id"])
                wire.need(previous is None or previous < ident,
                          "V2_POLICY_BOUNDARY_ORDER_REFUSED")
                previous = ident
                wire.need(boundary["reason"] != "ghost_parent" or
                          "commit_schema_version" not in boundary,
                          "V2_POLICY_GHOST_SCHEMA_REFUSED")
                children = boundary["child_commit_ids"]
                wire.need(len(children) > 0, "V2_POLICY_BOUNDARY_CHILDREN_REQUIRED")
                last_child = None
                for child in children:
                    self.guard()
                    _commit_id(child)
                    wire.need(last_child is None or last_child < child,
                              "V2_POLICY_BOUNDARY_CHILD_ORDER_REFUSED")
                    last_child = child
            wire.need(coverage["events_attachment"]["member"] == "history/source.json",
                      "V2_POLICY_EVENTS_MEMBER_REFUSED")
        self.header = value

    def _schema(self, value):
        profile = value["profile"]
        wire.need(profile["format"] == "beads-commit-schema/1" and
                  profile["scope"] == "immutable-commit-root",
                  "V2_POLICY_COMMIT_PROFILE_FORMAT_REFUSED")
        for lane, field in (("main", "main_version"), ("ignored", "ignored_version")):
            version = profile[field]
            wire.need(version is None or wire.uint(version) <= len(_PREFIXES[lane]),
                      "V2_POLICY_COMMIT_PROFILE_VERSION_REFUSED")
        # One bounded schema record, not an all-history schema registry.
        names = {}
        for table in value["tables"]:
            self.guard()
            _name(table["name"])
            columns = table["columns"]
            wire.need(1 <= len(columns) <= 1024, "V2_POLICY_COLUMN_CENSUS_REFUSED")
            observed = set()
            for column in columns:
                self.guard()
                _name(column["name"])
                wire.text(column["sql_type"])
                wire.need(column["name"] not in observed, "V2_POLICY_DUPLICATE_COLUMN_REFUSED")
                observed.add(column["name"])
            wire.need(table["name"] not in names, "V2_POLICY_DUPLICATE_TABLE_REFUSED")
            names[table["name"]] = observed
        expected = []
        for family, columns in sorted(_SURFACES.items()):
            self.guard()
            if family not in names:
                expected.append({"family": family, "reason": "absent-by-source-schema"})
            else:
                for column in columns:
                    if column not in names[family]:
                        expected.append({"family": family, "column": column,
                                         "reason": "absent-by-source-schema"})
        wire.need(profile["absences"] == expected, "V2_POLICY_OBSERVED_ABSENCES_MISMATCH")
        main, ignored = profile["main_version"], profile["ignored_version"]
        wire.need((main is None) == ("schema_migrations" not in names) and
                  (ignored is None) == ("ignored_schema_migrations" not in names),
                  "V2_POLICY_CURSOR_PRESENCE_MISMATCH")
        if main is None:
            initial = not names or (len(names) == 1 and
                                   names.get("dolt_ignore") == {"pattern", "ignored"})
            wire.need(ignored is None and initial, "V2_POLICY_NONINITIAL_CURSOR_ABSENCE_REFUSED")

    def __call__(self, *, header, record, table):
        self.guard()
        kind = record["type"]
        if kind == "header":
            wire.need(header is None and table is None, "V2_POLICY_HEADER_CONTEXT_REFUSED")
            self._header(record)
            return
        wire.need(header is self.header and header is not None,
                  "V2_POLICY_AUTHENTICATED_HEADER_REQUIRED")
        if kind == "schema":
            wire.need(table is None, "V2_POLICY_SCHEMA_CONTEXT_REFUSED")
            self._schema(record)
        elif kind == "commit":
            _commit_id(record["commit_id"])
            for parent in record["parents"]:
                self.guard()
                _commit_id(parent)
            row_policy.validate_secret_references(record["metadata"], guard=self.guard)
        elif kind in ("head-checkpoint", "current"):
            wire.need(record["commit_id"] == header["head"], "V2_POLICY_CHECKPOINT_HEAD_REFUSED")
        elif kind == "row":
            row_policy.validate_row(header=header, record=record, table=table, guard=self.guard)
        else:
            raise wire.Refusal("V2_POLICY_UNEXPECTED_CALLBACK_KIND")


class SemanticReplay(structural.StructuralReplay):
    """Guarded disk-backed policy integration; no injected callback bypass.

    The inherited consume authenticates EOF before the policy receipt. Every
    state still has its own cursor/absence check; equal schema IDs do not
    authorize skipping migration-row verification. Graph DFS uses disk stack,
    visited and postorder tables, independently from stored first-parent order.
    """

    def __init__(self, scratch_parent, *, guard):
        self.policy = SemanticPolicy(guard=guard)
        super().__init__(scratch_parent, guard=guard, validate_record=self.policy)
        self.policy_verified = False

    def __enter__(self):
        super().__enter__()
        try:
            statements = (
                "CREATE TABLE policy_nodes(id TEXT PRIMARY KEY, visited INTEGER NOT NULL) WITHOUT ROWID",
                "CREATE TABLE policy_frontier(id TEXT PRIMARY KEY, ordinal BLOB NOT NULL) WITHOUT ROWID",
                "CREATE TABLE policy_stack(depth BLOB PRIMARY KEY, id TEXT NOT NULL, last_parent TEXT) WITHOUT ROWID",
                "CREATE TABLE policy_order(id TEXT PRIMARY KEY, position BLOB UNIQUE NOT NULL) WITHOUT ROWID",
                "CREATE TABLE policy_settings(scope TEXT PRIMARY KEY) WITHOUT ROWID",
                "CREATE TABLE policy_classification(name BLOB PRIMARY KEY, history TEXT NOT NULL) WITHOUT ROWID")
            for statement in statements:
                self.guard()
                self._execute(statement)
            self.db.commit()
            return self
        except BaseException:
            self.close()
            raise

    def _definition(self, schema_id, name):
        result = self._one("SELECT raw FROM definitions WHERE schema_id=? AND name=?",
                           (schema_id, wire.text(name)))
        return None if result is None else wire.strict_json(result[0])

    def _cursor(self, state_id, schema_id, lane, expected):
        family = "schema_migrations" if lane == "main" else "ignored_schema_migrations"
        table = self._definition(schema_id, family)
        if table is None:
            wire.need(expected is None, "V2_POLICY_CURSOR_ABSENT_MISMATCH")
            return
        wire.need(expected is not None and "version" in {c["name"] for c in table["columns"]},
                  "V2_POLICY_CURSOR_VERSION_COLUMN_REQUIRED")
        limit = wire.uint(expected)
        maximum, seen = 0, set()
        for (raw,) in self._iter("SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key",
                                 (state_id, wire.text(family))):
            self.guard()
            value = row_policy._decode(raw, self.guard)
            version = _natural(value.get("version"))
            wire.need(1 <= version <= limit and version not in seen and
                      type(value.get("content_hash")) is str and
                      value["content_hash"] == _PREFIXES[lane].get(str(version)),
                      "V2_POLICY_MIGRATION_PREFIX_REFUSED")
            seen.add(version)  # At most the exact pinned lane length (72/28).
            maximum = max(maximum, version)
        wire.need(maximum == limit and len(seen) == limit,
                  "V2_POLICY_MIGRATION_PREFIX_INCOMPLETE")

    def _profiles(self):
        checked = 0
        for state_id, schema_id, raw, complete in self._iter(
                "SELECT s.id,s.schema_id,c.raw,s.complete FROM states s "
                "JOIN schemas c ON c.id=s.schema_id ORDER BY s.id"):
            self.guard()
            wire.need(complete == 1, "V2_POLICY_INCOMPLETE_STATE_REFUSED")
            schema = wire.strict_json(raw)
            # Recheck one bounded schema at its actual state, including current.
            self.policy._schema(schema)
            profile = schema["profile"]
            self._cursor(state_id, schema_id, "main", profile["main_version"])
            self._cursor(state_id, schema_id, "ignored", profile["ignored_version"])
            # Preserve the old per-table capacity; never sum this into a cap
            # on commits, parts, streamed rows or aggregate history/evidence.
            for (rows,) in self._iter("SELECT rows FROM state_tables WHERE state_id=?", (state_id,)):
                wire.need(int.from_bytes(rows, "big") <= 100000,
                          "V2_POLICY_INHERITED_TABLE_ROW_LIMIT_REFUSED")
            checked = wire.add(checked, 1)
        wire.need(checked == wire.add(self.counts["commits"], 2),
                  "V2_POLICY_STATE_PROFILE_CENSUS_MISMATCH")
        return checked

    def _graph(self):
        self._execute("INSERT INTO policy_nodes SELECT id,0 FROM commits")
        coverage = self.header["history_coverage"]
        boundary_count = 0
        if coverage is not None:
            for boundary in coverage["boundaries"]:
                self.guard()
                ident = boundary["commit_id"]
                wire.need(self._one("SELECT 1 FROM commits WHERE id=?", (ident,)) is None,
                          "V2_POLICY_BOUNDARY_IS_RETAINED_REFUSED")
                self._execute("INSERT INTO policy_nodes VALUES (?,0)", (ident,))
                self._execute("INSERT INTO policy_frontier VALUES (?,?)",
                              (ident, wire.u(boundary["commit_ordinal_from_head"])))
                boundary_count = wire.add(boundary_count, 1)
        for left, right in (("boundaries", "missing_edges"), ("missing_edges", "boundaries")):
            wire.need(self._one("SELECT parent,child FROM " + left +
                                " EXCEPT SELECT parent,child FROM " + right + " LIMIT 1") is None,
                      "V2_POLICY_BOUNDARY_EDGE_CENSUS_MISMATCH")
        head = self.header["head"]
        wire.need(self._one("SELECT 1 FROM commits WHERE id=?", (head,)) is not None,
                  "V2_POLICY_GRAPH_HEAD_MISSING")
        self._execute("UPDATE policy_nodes SET visited=1 WHERE id=?", (head,))
        self._execute("INSERT INTO policy_stack VALUES (?,?,NULL)", (wire.u(1), head))
        position = 0
        while True:
            self.guard()
            frame = self._one("SELECT depth,id,last_parent FROM policy_stack ORDER BY depth DESC LIMIT 1")
            if frame is None:
                break
            depth, ident, last_parent = frame
            if last_parent is None:
                parent = self._one("SELECT parent FROM parents WHERE child=? ORDER BY parent LIMIT 1", (ident,))
            else:
                parent = self._one("SELECT parent FROM parents WHERE child=? AND parent>? ORDER BY parent LIMIT 1",
                                   (ident, last_parent))
            if parent is not None:
                parent = parent[0]
                self._execute("UPDATE policy_stack SET last_parent=? WHERE depth=?", (parent, depth))
                visited = self._one("SELECT visited FROM policy_nodes WHERE id=?", (parent,))
                wire.need(visited is not None and visited[0] != 1,
                          "V2_POLICY_GRAPH_PARENT_OR_CYCLE_REFUSED")
                if visited[0] == 0:
                    self._execute("UPDATE policy_nodes SET visited=1 WHERE id=?", (parent,))
                    next_depth = wire.add(int.from_bytes(depth, "big"), 1)
                    self._execute("INSERT INTO policy_stack VALUES (?,?,NULL)", (wire.u(next_depth), parent))
                continue
            position = wire.add(position, 1)
            self._execute("INSERT INTO policy_order VALUES (?,?)", (ident, wire.u(position)))
            self._execute("UPDATE policy_nodes SET visited=2 WHERE id=?", (ident,))
            self._execute("DELETE FROM policy_stack WHERE depth=?", (depth,))
        expected = wire.add(self.counts["commits"], boundary_count)
        wire.need(position == expected and self._one(
            "SELECT 1 FROM policy_nodes WHERE visited<>2 LIMIT 1") is None,
            "V2_POLICY_GRAPH_UNREACHABLE_NODE_REFUSED")
        sequence = 0
        for (actual,) in self._iter("SELECT c.sequence FROM policy_order o JOIN commits c ON c.id=o.id ORDER BY o.position"):
            sequence = wire.add(sequence, 1)
            wire.need(actual == wire.u(sequence), "V2_POLICY_CANONICAL_COMMIT_ORDER_REFUSED")
        wire.need(sequence == self.counts["commits"], "V2_POLICY_CANONICAL_COMMIT_COUNT_MISMATCH")
        for ordinal, postorder in self._iter(
                "SELECT f.ordinal,o.position FROM policy_frontier f JOIN policy_order o ON o.id=f.id"):
            actual = position - int.from_bytes(postorder, "big") + 1
            wire.need(ordinal == wire.u(actual), "V2_POLICY_BOUNDARY_ORDINAL_MISMATCH")
        if coverage is not None:
            count = self._one("SELECT rows FROM state_tables WHERE state_id=? AND name=?", (b"C", b"events"))
            observed = 0 if count is None else int.from_bytes(count[0], "big")
            wire.need(coverage["events_attachment"]["rows"] == observed,
                      "V2_POLICY_CURRENT_EVENT_COUNT_MISMATCH")
        return boundary_count

    def _current_policy(self):
        declared = self.header["config_policy"]
        for family in ("config", "metadata"):
            for (raw,) in self._iter("SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY key",
                                     (b"C", wire.text(family))):
                value = row_policy._decode(raw, self.guard)
                key = value.get("key")
                wire.need(type(key) is str and key != "", "V2_POLICY_CURRENT_SETTING_KEY_REFUSED")
                scope = family + "/" + key
                setting = declared.get(scope)
                wire.need(setting in ("public", "secret") and
                          (not row_policy.secret_key(key) or setting == "secret"),
                          "V2_POLICY_CURRENT_SETTING_AUTHORITY_MISMATCH")
                if setting == "secret":
                    wire.need(type(value.get("value")) is dict and
                              value["value"] == {"$secret": scope},
                              "V2_POLICY_CURRENT_SETTING_REFERENCE_MISMATCH")
                if self._one("SELECT 1 FROM policy_settings WHERE scope=?", (scope,)) is None:
                    self._execute("INSERT INTO policy_settings VALUES (?)", (scope,))
        actual = self._one("SELECT count(*) FROM policy_settings")[0]
        wire.need(actual == len(declared), "V2_POLICY_UNUSED_SETTING_AUTHORITY_REFUSED")
        return wire.uint(actual)

    def _ignored_family(self, name):
        if name not in _UNVERSIONED:
            return False
        ignore = self.header["ignore"]["rows"]
        for item in ignore:
            self.guard()
            if _folded_ascii_equal(item["pattern"], name):
                return _ignored(item["ignored"])
        canonical = "wisp_%" if name.startswith("wisp_") else name
        matched = False
        for item in ignore:
            self.guard()
            pattern, on = item["pattern"], _ignored(item["ignored"])
            wire.need(on or not any(char in pattern for char in "%*?\\"),
                      "V2_POLICY_AMBIGUOUS_IGNORE_OVERRIDE_REFUSED")
            matched = matched or on and pattern == canonical
        return matched

    def _same_native_table(self, left, right, name):
        # Existing versioned-family rules compare normalized native columns
        # and row multisets. Preserve every typed cell separately in replay;
        # do not strengthen this into physical type/PK equality across states.
        definitions = []
        for state in (left, right):
            value = self._one("SELECT schema_id FROM states WHERE id=?", (state,))
            wire.need(value is not None, "V2_POLICY_COMPARISON_STATE_MISSING")
            definition = self._definition(value[0], name)
            wire.need(definition is not None, "V2_POLICY_COMPARISON_TABLE_MISSING")
            definitions.append(tuple(sorted(c["name"] for c in definition["columns"])))
        wire.need(definitions[0] == definitions[1], "V2_POLICY_VERSIONED_COLUMNS_MISMATCH")
        for a, b in ((left, right), (right, left)):
            wire.need(self._one(
                "SELECT normalized,count(*) FROM state_rows WHERE state_id=? AND name=? GROUP BY normalized "
                "EXCEPT SELECT normalized,count(*) FROM state_rows WHERE state_id=? AND name=? GROUP BY normalized LIMIT 1",
                (a, wire.text(name), b, wire.text(name))) is None,
                "V2_POLICY_VERSIONED_ROWS_OR_MULTIPLICITY_MISMATCH")

    def _classification(self):
        head = self._retained(self.header["head"])[0]
        current_schema = self._one("SELECT schema_id FROM states WHERE id=?", (b"C",))[0]
        current_ignore = self._definition(current_schema, "dolt_ignore")
        if current_ignore is not None:
            wire.need(sorted(c["name"] for c in current_ignore["columns"]) == ["ignored", "pattern"],
                      "V2_POLICY_PHYSICAL_IGNORE_COLUMNS_MISMATCH")
            expected = iter(self.header["ignore"]["rows"])
            for (raw,) in self._iter(
                    "SELECT normalized FROM state_rows WHERE state_id=? AND name=? ORDER BY normalized,key",
                    (b"C", b"dolt_ignore")):
                self.guard()
                item = next(expected, None)
                wire.need(item is not None and raw == _ignore_row_bytes(item, self.guard),
                          "V2_POLICY_PHYSICAL_IGNORE_ROW_MISMATCH")
            wire.need(next(expected, None) is None, "V2_POLICY_PHYSICAL_IGNORE_ROW_COUNT_MISMATCH")
        classified = 0
        # Every current physical table is retained. The known source-family
        # census alone owns versioned/unversioned classification; extra
        # physical tables stay explicit and await portable-source reconciliation.
        extra = 0
        for (raw_name,) in self._iter("SELECT name FROM state_tables WHERE state_id=? ORDER BY name", (b"C",)):
            self.guard()
            name = raw_name.decode("utf-8", "strict")
            if name not in _SURFACES:
                extra = wire.add(extra, 1)
                continue
            present = self._one("SELECT 1 FROM state_tables WHERE state_id=? AND name=?", (head, raw_name))
            if present is not None:
                classification = "versioned"
                self._same_native_table(head, b"C", name)
            else:
                wire.need(self._ignored_family(name), "V2_POLICY_HEAD_MISSING_VERSIONED_FAMILY_REFUSED")
                classification = "unversioned-in-beads-by-design"
            self._execute("INSERT INTO policy_classification VALUES (?,?)", (raw_name, classification))
            classified = wire.add(classified, 1)
        return classified, extra

    def consume(self, capture_set):
        try:
            structural_receipt = super().consume(capture_set)
            self.guard()
            wire.need(self.structural_verified and capture_set.transport_verified,
                      "V2_POLICY_AUTHENTICATED_EOF_REQUIRED")
            states = self._profiles()
            boundaries = self._graph()
            settings = self._current_policy()
            classified, extra = self._classification()
            self.guard()
            self.db.commit()
            self.policy_verified = True
            return {"status": "SEMANTIC_REPLAY_PARTIAL_VERIFIED_INTEGRATION_PENDING",
                    "structural": structural_receipt,
                    "capture_set_sha256": capture_set.root_sha256,
                    "state_profiles_verified": states,
                    "canonical_graph_and_frontier_verified": True,
                    "frontier_nodes": boundaries,
                    "current_setting_authorities_matched": settings,
                    "known_current_families_classified": classified,
                    "extra_current_physical_tables_retained": extra,
                    "row_policy_source_review": "a0f4e13cb94250e52b533450b11310998f2174b0836cf2494658d61aa560cc72",
                    "numeric_and_time_runtime_conformance": "NOT_RUN",
                    "portable_head_events_inventory_and_evidence": "PENDING",
                    "receiver_category_preimages_admission_and_readback": "PENDING",
                    "direct_wait_lifetime_and_cleanup": "PENDING",
                    "publication_authorized": False}
        except wire.Refusal:
            raise
        except (OSError, ValueError, KeyError, TypeError, OverflowError,
                UnicodeError, RecursionError, sqlite3.Error):
            raise wire.Refusal("V2_POLICY_INTEGRATION_FAULT") from None
