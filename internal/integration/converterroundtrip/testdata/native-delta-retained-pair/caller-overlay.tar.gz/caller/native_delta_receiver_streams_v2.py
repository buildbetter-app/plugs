"""Partial extraction of exact receiver stdout/stderr, AUTHORED_NOT_RUN.

Uses the reviewed c6b receiver event/scalar checks without changing them.
There is no CLI, subprocess, import/publication approval or execution proof.
This module never loads a whole receipt, commit list or committed report.
No aggregate original/evidence limit or wire-record-derived proof limit is
introduced. Large skipped JSON values have a disk stack and disk key index.

The success route is specifically runNativeDelta's current receipt shape,
not prepare-request, joined receiving or a future receiver wire revision.
Proof headers precede tables exactly as the actual Go struct serializes
them. Generic committed_report JSON is checked and bound, but its semantic
validation, admission and independent persistent readback remain PENDING.
"""

import codecs
import hashlib
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat

import native_delta_wire_v2 as wire
import native_delta_receiver_checks_v2 as checks


SOURCE_SCHEMA = "ee8c01e9f1315fab51cd4891ab8464cb3af4e84d"
RECEIPT_FORMAT = "plug-native-receiving-receipt/1"
READ_BYTES = 64 << 10
_SPECIAL = re.compile(rb'["\\\x00-\x1f]')
_DIGITS = re.compile(rb"[0-9]+")
_WS = b" \t\r\n"
_DELIMITERS = b" \t\r\n,]}"
_HEX = frozenset(b"0123456789abcdefABCDEF")
_SCRATCH_FILES = frozenset(("keys.sqlite", "keys.sqlite-journal",
                            "keys.sqlite-wal", "keys.sqlite-shm"))


def _identity(info):
    return info.st_dev, info.st_ino


def _signature(info):
    return (_identity(info), info.st_mode, info.st_uid, info.st_gid,
            info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class _DirectoryChain:
    """No-follow openat walk; retain every directory edge for final checks."""

    def __init__(self, path, guard):
        wire.need(callable(guard), "V2_STREAM_GUARD_REQUIRED")
        wire.need(type(path) is str and path.startswith("/") and not path.startswith("//") and
                  str(Path(path)) == path and ".." not in Path(path).parts,
                  "V2_STREAM_CANONICAL_PATH_REQUIRED")
        self.guard = guard
        self.fds = []
        self.edges = []
        try:
            guard()
            self.fds.append(os.open("/", os.O_RDONLY | os.O_DIRECTORY |
                                    os.O_NOFOLLOW | os.O_CLOEXEC))
            for name in Path(path).parts[1:]:
                guard()
                parent = self.fds[-1]
                fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY |
                             os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
                self.fds.append(fd)
                info = os.fstat(fd)
                wire.need(stat.S_ISDIR(info.st_mode), "V2_STREAM_DIRECTORY_REFUSED")
                self.edges.append((parent, name, fd, _identity(info)))
        except BaseException:
            self.close()
            raise

    @property
    def fd(self):
        return self.fds[-1]

    def recheck(self):
        for parent, name, fd, expected in self.edges:
            self.guard()
            current = os.stat(name, dir_fd=parent, follow_symlinks=False)
            wire.need(stat.S_ISDIR(current.st_mode) and
                      _identity(current) == expected == _identity(os.fstat(fd)),
                      "V2_STREAM_DIRECTORY_BINDING_CHANGED")

    def close(self):
        while self.fds:
            os.close(self.fds.pop())


class _Original:
    """Read one explicitly supplied frozen 0444 UID-owned original descriptor."""

    def __init__(self, path, expected, guard):
        wire.fields(expected, ("sha256", "bytes"))
        wire.digest(expected["sha256"])
        self.expected_size = wire.uint(expected["bytes"])
        self.expected_hash = expected["sha256"]
        self.path, self.guard = path, guard
        self.chain = self.fd = None
        self.buffer = b""
        self.index = self.offset = self.read_count = self.linefeeds = 0
        self.sha = hashlib.sha256()
        self.taps = []
        self.eof = self.verified = False
        try:
            wire.need(type(path) is str and str(Path(path)) == path and
                      Path(path).name not in ("", ".", ".."),
                      "V2_STREAM_CANONICAL_PATH_REQUIRED")
            self.chain = _DirectoryChain(str(Path(path).parent), guard)
            guard()
            self.fd = os.open(Path(path).name, os.O_RDONLY | os.O_NOFOLLOW |
                              os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=self.chain.fd)
            self.initial = os.fstat(self.fd)
            wire.need(stat.S_ISREG(self.initial.st_mode) and
                      self.initial.st_uid == os.getuid() and
                      self.initial.st_nlink == 1 and
                      self.initial.st_mode & 0o7777 == 0o444 and
                      self.initial.st_size == self.expected_size,
                      "V2_STREAM_ORIGINAL_OWNER_MODE_SIZE_REFUSED")
        except BaseException:
            self.close()
            raise

    def available(self):
        if self.index == len(self.buffer) and not self.eof:
            self.guard()
            raw = os.read(self.fd, min(READ_BYTES, self.expected_size - self.read_count + 1))
            self.read_count = wire.add(self.read_count, len(raw))
            wire.need(self.read_count <= self.expected_size,
                      "V2_STREAM_ORIGINAL_GREW")
            self.buffer, self.index = raw, 0
            self.eof = not raw
        return self.buffer[self.index:]

    def peek(self):
        raw = self.available()
        return raw[:1]

    def consume(self, size):
        wire.need(type(size) is int and 0 <= size <= len(self.available()),
                  "V2_STREAM_INTERNAL_READ_REFUSED")
        raw = self.buffer[self.index:self.index + size]
        self.index += size
        self.offset = wire.add(self.offset, size)
        self.linefeeds = wire.add(self.linefeeds, raw.count(b"\n"))
        self.sha.update(raw)
        for tap in self.taps:
            tap.update(raw)
        return raw

    def take(self, size):
        out = bytearray()
        while len(out) < size:
            wire.need(bool(self.available()), "V2_STREAM_UNEXPECTED_EOF")
            out.extend(self.consume(min(size - len(out), len(self.available()))))
        return bytes(out)

    def expect(self, raw):
        wire.need(self.take(len(raw)) == raw, "V2_STREAM_JSON_SYNTAX_REFUSED")

    def whitespace(self):
        while self.available():
            raw = self.available()
            size = len(raw) - len(raw.lstrip(_WS))
            if not size:
                return
            self.consume(size)

    def span(self, consume):
        self.whitespace()
        start, sha = self.offset, hashlib.sha256()
        self.taps.append(sha)
        try:
            consume()
        finally:
            self.taps.pop()
        return {"offset_bytes": start, "bytes": self.offset - start,
                "sha256": sha.hexdigest(), "semantic_validation": "PENDING"}

    def finish(self):
        wire.need(not self.available() and self.offset == self.expected_size and
                  self.sha.hexdigest() == self.expected_hash,
                  "V2_STREAM_ORIGINAL_HASH_OR_LENGTH_MISMATCH")
        self.guard()
        current = os.stat(Path(self.path).name, dir_fd=self.chain.fd,
                          follow_symlinks=False)
        wire.need(_signature(current) == _signature(self.initial) ==
                  _signature(os.fstat(self.fd)), "V2_STREAM_ORIGINAL_CHANGED")
        self.chain.recheck()
        self.verified = True
        return {"sha256": self.expected_hash, "bytes": self.offset,
                "frozen_mode": "0444", "binding": "MATCHED_EXACT_FILE"}

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
        if self.chain is not None:
            self.chain.close()
            self.chain = None


class _DiskKeys:
    """Private disk stack/index for skipped JSON; never one Python key set.

    Keys are indexed by SHA256 of their decoded UTF-8. Equal hashes refuse,
    so a hypothetical hash collision conservatively refuses distinct keys;
    it cannot admit an actual duplicate. Nested object/frame state is disk
    backed too, with no recursion or aggregate depth/key-count allocation.
    """

    def __init__(self, parent, guard):
        self.parent_path, self.guard = parent, guard
        self.chain = self.dir_fd = self.db = self.info = self.name = None
        self.serial = 0
        self.guard_failed = False

    def __enter__(self):
        try:
            self.chain = _DirectoryChain(self.parent_path, self.guard)
            parent = os.fstat(self.chain.fd)
            wire.need(parent.st_uid == os.getuid() and not parent.st_mode & 0o022,
                      "V2_STREAM_SCRATCH_PARENT_REFUSED")
            self.name = "receiver-stream-" + secrets.token_hex(16)
            self.guard()
            os.mkdir(self.name, 0o700, dir_fd=self.chain.fd)
            self.info = os.stat(self.name, dir_fd=self.chain.fd, follow_symlinks=False)
            self.dir_fd = os.open(self.name, os.O_RDONLY | os.O_DIRECTORY |
                                  os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.chain.fd)
            opened = os.fstat(self.dir_fd)
            wire.need(_identity(opened) == _identity(self.info) and
                      stat.S_ISDIR(opened.st_mode) and opened.st_uid == os.getuid() and
                      opened.st_mode & 0o7777 == 0o700, "V2_STREAM_SCRATCH_REFUSED")
            self.guard()
            fd = os.open("keys.sqlite", os.O_RDWR | os.O_CREAT | os.O_EXCL |
                         os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=self.dir_fd)
            os.close(fd)
            self.guard()
            self.db = sqlite3.connect(f"/proc/self/fd/{self.dir_fd}/keys.sqlite")
            self.db.set_progress_handler(self._progress, 10000)
            for statement in ("PRAGMA journal_mode=DELETE", "PRAGMA synchronous=FULL",
                              "PRAGMA temp_store=FILE", "PRAGMA cache_size=-8192",
                              "PRAGMA mmap_size=0", "PRAGMA trusted_schema=OFF"):
                self.execute(statement).close()
            self.execute("CREATE TABLE frames (id BLOB PRIMARY KEY, parent BLOB, "
                         "kind TEXT NOT NULL, state TEXT NOT NULL) WITHOUT ROWID").close()
            self.execute("CREATE TABLE object_keys (frame BLOB NOT NULL, digest BLOB NOT NULL, "
                         "PRIMARY KEY(frame, digest)) WITHOUT ROWID").close()
            return self
        except BaseException:
            self.close()
            raise

    def _progress(self):
        try:
            self.guard()
        except BaseException:
            self.guard_failed = True
            return 1
        return 0

    def execute(self, sql, args=()):
        self.guard()
        return self.db.execute(sql, args)

    def push(self, parent, kind):
        self.serial = wire.add(self.serial, 1)
        identifier = wire.u(self.serial)
        self.execute("INSERT INTO frames VALUES (?, ?, ?, 'first')",
                     (identifier, parent, kind)).close()
        return identifier

    def frame(self, identifier):
        cursor = self.execute("SELECT parent, kind, state FROM frames WHERE id=?", (identifier,))
        try:
            result = cursor.fetchone()
        finally:
            cursor.close()
        wire.need(result is not None, "V2_STREAM_FRAME_MISSING")
        return result

    def state(self, identifier, state):
        self.execute("UPDATE frames SET state=? WHERE id=?", (state, identifier)).close()

    def key(self, identifier, digest):
        try:
            self.execute("INSERT INTO object_keys VALUES (?, ?)", (identifier, digest)).close()
        except sqlite3.IntegrityError:
            raise wire.Refusal("V2_STREAM_DUPLICATE_JSON_KEY") from None

    def pop(self, identifier):
        self.execute("DELETE FROM object_keys WHERE frame=?", (identifier,)).close()
        self.execute("DELETE FROM frames WHERE id=?", (identifier,)).close()

    def close(self):
        # STOP/PAUSE leaves owned scratch for separately recorded cleanup;
        # descriptor closure itself is safe, but no chmod/unlink bypasses guard.
        if self.db is not None:
            self.guard()
            self.db.set_progress_handler(None, 0)
            self.db.close()
            self.db = None
        try:
            if self.info is not None and self.dir_fd is None:
                self.guard()
                self.dir_fd = os.open(self.name, os.O_RDONLY | os.O_DIRECTORY |
                                      os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.chain.fd)
            if self.dir_fd is not None:
                self.guard()
                current = os.stat(self.name, dir_fd=self.chain.fd, follow_symlinks=False)
                wire.need(_identity(current) == _identity(self.info) ==
                          _identity(os.fstat(self.dir_fd)), "V2_STREAM_SCRATCH_CHANGED")
                os.fchmod(self.dir_fd, 0o700)
                with os.scandir(self.dir_fd) as entries:
                    for entry in entries:
                        self.guard()
                        wire.need(entry.name in _SCRATCH_FILES,
                                  "V2_STREAM_SCRATCH_UNEXPECTED_FILE")
                        fd = os.open(entry.name, os.O_RDONLY | os.O_NONBLOCK |
                                     os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.dir_fd)
                        try:
                            info = os.fstat(fd)
                            wire.need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
                                      info.st_uid == os.getuid(), "V2_STREAM_SCRATCH_FILE_REFUSED")
                            self.guard()
                            os.fchmod(fd, 0o600)
                        finally:
                            os.close(fd)
                        self.guard()
                        os.unlink(entry.name, dir_fd=self.dir_fd)
                self.guard()
                os.rmdir(self.name, dir_fd=self.chain.fd)
        finally:
            if self.dir_fd is not None:
                os.close(self.dir_fd)
                self.dir_fd = None
            if self.chain is not None:
                self.chain.close()
                self.chain = None

    def __exit__(self, *_):
        self.close()


class _JSON:
    """Chunked strict UTF-8 JSON scanner with finite-schema scalar readers."""

    def __init__(self, original, disk=None):
        self.src, self.disk = original, disk

    def char(self, raw):
        self.src.whitespace()
        self.src.expect(raw)

    def string(self, sink=None):
        self.char(b'"')
        decoder = codecs.getincrementaldecoder("utf-8")("strict")
        decoded = 0

        def emit(raw):
            nonlocal decoded
            decoded = wire.add(decoded, len(raw))
            if sink is not None:
                sink(raw)

        while True:
            raw = self.src.available()
            wire.need(bool(raw), "V2_STREAM_UNTERMINATED_STRING")
            special = _SPECIAL.search(raw)
            size = special.start() if special is not None else len(raw)
            if size:
                emit(decoder.decode(self.src.consume(size), final=False).encode("utf-8", "strict"))
            if special is None:
                continue
            emit(decoder.decode(b"", final=True).encode("utf-8", "strict"))
            decoder.reset()
            marker = self.src.take(1)
            if marker == b'"':
                return decoded
            wire.need(marker == b"\\", "V2_STREAM_STRING_CONTROL_REFUSED")
            escaped = self.src.take(1)
            simple = {b'"': b'"', b"\\": b"\\", b"/": b"/", b"b": b"\b",
                      b"f": b"\f", b"n": b"\n", b"r": b"\r", b"t": b"\t"}
            if escaped in simple:
                emit(simple[escaped])
                continue
            wire.need(escaped == b"u", "V2_STREAM_STRING_ESCAPE_REFUSED")
            digits = self.src.take(4)
            wire.need(all(c in _HEX for c in digits), "V2_STREAM_UNICODE_ESCAPE_REFUSED")
            point = int(digits, 16)
            if 0xD800 <= point <= 0xDBFF:
                self.src.expect(b"\\u")
                digits = self.src.take(4)
                wire.need(all(c in _HEX for c in digits), "V2_STREAM_UNICODE_ESCAPE_REFUSED")
                low = int(digits, 16)
                wire.need(0xDC00 <= low <= 0xDFFF, "V2_STREAM_SURROGATE_REFUSED")
                point = 0x10000 + ((point - 0xD800) << 10) + low - 0xDC00
            wire.need(not 0xD800 <= point <= 0xDFFF, "V2_STREAM_SURROGATE_REFUSED")
            emit(chr(point).encode("utf-8", "strict"))

    def equal_string(self, expected):
        raw, offset = wire.text(expected, empty=True), 0

        def compare(chunk):
            nonlocal offset
            wire.need(raw[offset:offset + len(chunk)] == chunk,
                      "V2_STREAM_EXPECTED_STRING_MISMATCH")
            offset += len(chunk)

        self.string(compare)
        wire.need(offset == len(raw), "V2_STREAM_EXPECTED_STRING_MISMATCH")
        return expected

    def choice(self, choices):
        wire.need(bool(choices), "V2_STREAM_EMPTY_SCHEMA_CHOICE")
        limit = max(len(wire.text(value, empty=True)) for value in choices)
        out = bytearray()

        def retain(chunk):
            wire.need(len(out) + len(chunk) <= limit, "V2_STREAM_CLOSED_STRING_REFUSED")
            out.extend(chunk)

        self.string(retain)
        value = out.decode("utf-8", "strict")
        wire.need(value in choices, "V2_STREAM_CLOSED_STRING_REFUSED")
        return value

    def number(self, uint=False):
        self.src.whitespace()
        out = bytearray()

        def consume(size):
            raw = self.src.consume(size)
            if uint:
                wire.need(len(out) + len(raw) <= 20, "V2_STREAM_UINT64_SPELLING_REFUSED")
                out.extend(raw)

        def digits():
            total = 0
            while self.src.available():
                match = _DIGITS.match(self.src.available())
                if match is None:
                    break
                consume(match.end())
                total = wire.add(total, match.end())
            wire.need(total > 0, "V2_STREAM_JSON_NUMBER_REFUSED")

        if self.src.peek() == b"-":
            wire.need(not uint, "V2_STREAM_UINT64_SPELLING_REFUSED")
            consume(1)
        if self.src.peek() == b"0":
            consume(1)
        else:
            wire.need(self.src.peek() in tuple(bytes((c,)) for c in b"123456789"),
                      "V2_STREAM_JSON_NUMBER_REFUSED")
            digits()
        if self.src.peek() == b".":
            wire.need(not uint, "V2_STREAM_UINT64_SPELLING_REFUSED")
            consume(1)
            digits()
        if self.src.peek() in (b"e", b"E"):
            wire.need(not uint, "V2_STREAM_UINT64_SPELLING_REFUSED")
            consume(1)
            if self.src.peek() in (b"+", b"-"):
                consume(1)
            digits()
        tail = self.src.peek()
        wire.need(not tail or tail in tuple(bytes((c,)) for c in _DELIMITERS),
                  "V2_STREAM_JSON_NUMBER_TRAILER_REFUSED")
        if uint:
            return wire.uint(wire.JSONInteger(out.decode("ascii")))
        return None

    def boolean(self):
        self.src.whitespace()
        if self.src.peek() == b"t":
            self.src.expect(b"true")
            return True
        self.src.expect(b"false")
        return False

    def object(self, required, optional, read):
        """Only bounded schema keys are retained, never arbitrary key names."""
        allowed = frozenset(required) | frozenset(optional)
        seen, result = set(), {}
        self.char(b"{")
        self.src.whitespace()
        if self.src.peek() != b"}":
            while True:
                key = self.choice(allowed)
                wire.need(key not in seen, "V2_STREAM_DUPLICATE_JSON_KEY")
                seen.add(key)
                self.char(b":")
                result[key] = read(key)
                self.src.whitespace()
                if self.src.peek() != b",":
                    break
                self.src.consume(1)
        self.char(b"}")
        wire.need(set(required) <= seen, "V2_STREAM_REQUIRED_FIELD_MISSING")
        return result

    def uint_map(self, keys):
        return self.object((), keys, lambda _: self.number(uint=True))

    def skip(self):
        """Validate one arbitrary JSON value without retaining it in memory."""
        wire.need(self.disk is not None, "V2_STREAM_DISK_INDEX_REQUIRED")

        def value(parent):
            self.src.whitespace()
            token = self.src.peek()
            wire.need(bool(token), "V2_STREAM_UNEXPECTED_EOF")
            if token in (b"{", b"["):
                self.src.consume(1)
                return self.disk.push(parent, "object" if token == b"{" else "array")
            if token == b'"':
                self.string()
            elif token in (b"t", b"f"):
                self.boolean()
            elif token == b"n":
                self.src.expect(b"null")
            else:
                self.number()
            return parent

        current = value(None)
        while current is not None:
            parent, kind, state = self.disk.frame(current)
            self.src.whitespace()
            end = b"}" if kind == "object" else b"]"
            if state == "after":
                if self.src.peek() == end:
                    self.src.consume(1)
                    self.disk.pop(current)
                    current = parent
                    continue
                self.src.expect(b",")
                self.disk.state(current, "required")
                continue
            if state == "first" and self.src.peek() == end:
                self.src.consume(1)
                self.disk.pop(current)
                current = parent
                continue
            if kind == "object":
                sha = hashlib.sha256(b"native-receive-original-object-key/1\0")
                self.string(sha.update)
                self.disk.key(current, sha.digest())
                self.char(b":")
            self.disk.state(current, "after")
            current = value(current)


def _usage(parser):
    def read(name):
        if name == "accounting":
            return parser.equal_string(checks.ACCOUNTING)
        if name == "limit_origin":
            return parser.choice(checks.CLI_ORIGINS)
        if name in ("categories", "charges"):
            return parser.uint_map(checks.CATEGORIES)
        return parser.number(uint=True)

    return parser.object(("accounting", "limit_bytes", "limit_origin",
                          "peak_accounted_decoded_bytes", "categories", "charges"), (), read)


def _rss(parser):
    def read(name):
        if name == "status":
            return parser.choice(("MEASURED", "NOT_MEASURED"))
        if name == "method":
            return parser.equal_string(checks.RSS_METHOD)
        if name == "process_scope":
            return parser.equal_string(checks.RSS_SCOPE)
        if name == "source_units":
            return parser.equal_string("KiB")
        if name == "platform":
            # This source unit targets the actual Linux public-receiving route.
            return parser.equal_string("linux")
        return parser.number(uint=True)

    return parser.object(("status", "method", "process_scope", "platform",
                          "source_units", "peak_bytes"), (), read)


def _commits(parser, proofs):
    parser.char(b"[")
    parser.src.whitespace()
    if parser.src.peek() != b"]":
        while True:
            # This is the actual Go struct order, bound to original stdout.
            # No complete table-proof map or commit array is accumulated.
            parser.char(b"{")
            header = {}
            expected = proofs.replay._one(
                "SELECT c.id, s.schema_id, s.root FROM commits c JOIN states s "
                "ON s.id=c.state_id WHERE c.sequence=? AND s.complete=1",
                (wire.u(wire.add(proofs.commits, 1)),))
            wire.need(expected is not None, "V2_STREAM_UNEXPECTED_COMMIT_PROOF")
            for ordinal, name in enumerate(("sequence", "commit_id", "schema_id", "root_sha256")):
                if ordinal:
                    parser.char(b",")
                parser.equal_string(name)
                parser.char(b":")
                header[name] = (parser.number(uint=True) if ordinal == 0 else
                                parser.equal_string(expected[ordinal - 1]))
            proofs.begin(header)
            parser.char(b",")
            parser.equal_string("tables")
            parser.char(b":")
            parser.char(b"{")
            parser.src.whitespace()
            if parser.src.peek() != b"}":
                while True:
                    expected_table = proofs.active["next"]
                    wire.need(expected_table is not None, "V2_STREAM_UNEXPECTED_TABLE_PROOF")
                    name = expected_table[0].decode("utf-8", "strict")
                    parser.equal_string(name)
                    parser.char(b":")
                    proof = parser.object(("Rows", "SHA256"), (), lambda key:
                        parser.number(uint=True) if key == "Rows" else
                        parser.equal_string(expected_table[2]))
                    proofs.table(name, proof)
                    parser.src.whitespace()
                    if parser.src.peek() != b",":
                        break
                    parser.src.consume(1)
            parser.char(b"}")
            parser.char(b"}")
            proofs.end()
            parser.src.whitespace()
            if parser.src.peek() != b",":
                break
            parser.src.consume(1)
    parser.char(b"]")
    return proofs.finish()


def _native(parser, proofs, replay):
    def verification():
        def read(name):
            if name == "commits":
                result = {}

                def consume():
                    result.update(_commits(parser, proofs))

                span = parser.src.span(consume)
                span["semantic_validation"] = "MATCHED_INDEPENDENT_DISK_REPLAY"
                result["original_json_span"] = span
                return result
            if name == "decoded_usage":
                return _usage(parser)
            if name == "totals":
                return parser.object(wire.TOTAL_FIELDS, (), lambda _: parser.number(uint=True))
            value = {"contract": wire.CONTRACT, "head_root_sha256": replay.head_root,
                     "current_root_sha256": replay.current_root}[name]
            return parser.equal_string(value)

        return parser.object(("contract", "totals", "head_root_sha256", "current_root_sha256",
                              "commits", "decoded_usage"), (), read)

    def read(name):
        if name == "verification":
            return verification()
        if name == "rss":
            return _rss(parser)
        if name == "format":
            return parser.equal_string(checks.NATIVE_RECEIPT)
        return parser.choice(checks.CLI_ORIGINS)

    return parser.object(("format", "verification", "decoded_limit_origin", "rss"), (), read)


def _outer_verification(parser):
    def read(name):
        if name == "archive_blob":
            return parser.boolean()
        if name == "reopen":
            return parser.choice(("driver-reopened", "same-process-memory"))
        return parser.number(uint=True)

    return parser.object(("current_families", "current_rows", "history_images", "history_tables",
                          "history_rows", "archive_blob", "reopen", "opaque_metadata_fields"), (), read)


def _fault():
    # Raw JSON/filesystem/SQLite texts never enter caller diagnostics.
    return wire.Refusal("V2_RECEIVER_ORIGINAL_STREAM_REFUSED")


def extract_success(stdout_path, stdout_binding, stderr_path, stderr_binding, *,
                    scratch_parent, guard, replay, expected_receipt,
                    expected_limit, expected_origin,
                    expected_categories=None, expected_charges=None):
    """Bind an actual default-receive original, not admission or execution proof.

    expected_receipt is independently derived from retained request/policy,
    capture-set and actual ELF inputs, never copied from receiver stdout.
    The caller must separately bind direct wait/exit/lifetime originals.
    """
    required = ("policy_sha256", "binary_sha256", "request_sha256", "archive_sha256",
                "driver", "restore_time")
    wire.fields(expected_receipt, required)
    for name in required[:4]:
        wire.digest(expected_receipt[name])
    wire.need(expected_receipt["driver"] in ("memory", "sqlite", "postgres"),
              "V2_STREAM_EXPECTED_DRIVER_REFUSED")
    wire.text(expected_receipt["restore_time"])
    wire.need(replay.structural_verified, "V2_STREAM_REPLAY_REQUIRED")
    stdout = stderr = proofs = None
    try:
        stdout = _Original(stdout_path, stdout_binding, guard)
        stderr = _Original(stderr_path, stderr_binding, guard)
        wire.need(_identity(stdout.initial) != _identity(stderr.initial),
                  "V2_STREAM_ORIGINALS_ALIAS_REFUSED")
        with _DiskKeys(scratch_parent, guard) as disk:
            parser = _JSON(stdout, disk)
            proofs = checks.CommitProofs(replay)

            def read(name):
                if name == "native_delta":
                    return _native(parser, proofs, replay)
                if name == "committed_report":
                    stdout.whitespace()
                    wire.need(stdout.peek() == b"{", "V2_STREAM_COMMITTED_REPORT_OBJECT_REQUIRED")
                    return stdout.span(parser.skip)
                if name == "verification":
                    return _outer_verification(parser)
                if name == "cross_project_id_collisions":
                    value = parser.number(uint=True)
                    wire.need(value == 0, "V2_STREAM_DELTA_COLLISION_FIELD_MISMATCH")
                    return value
                if name == "format":
                    return parser.equal_string(RECEIPT_FORMAT)
                if name == "history_mode":
                    return parser.equal_string("full")
                return parser.equal_string(expected_receipt[name])

            outer = parser.object(("format", *required, "history_mode", "verification",
                                   "committed_report", "cross_project_id_collisions", "native_delta"), (), read)
            stdout.whitespace()
            stdout_original = stdout.finish()
            # Actual success main emits no stderr; any bytes remain a refusal
            # for this declared extractor instead of being discarded.
            wire.need(stderr.expected_size == 0, "V2_STREAM_SUCCESS_STDERR_NOT_EMPTY")
            stderr_original = stderr.finish()
            native = outer.pop("native_delta")
            verification = native.pop("verification")
            proof_result = verification.pop("commits")
            rss = native.pop("rss")
            metadata = checks.success_metadata(native, verification, rss, replay=replay,
                expected_limit=expected_limit, expected_origin=expected_origin,
                expected_categories=expected_categories, expected_charges=expected_charges)
            proof_result["original_stream_binding"] = "MATCHED_BY_ENCLOSING_RESULT"
            metadata["original_stream_binding"] = "MATCHED_BY_ENCLOSING_RESULT"
            metadata["commit_proofs"] = "MATCHED_BY_ENCLOSING_RESULT"
        return {"status": "ORIGINAL_RECEIVER_STREAMS_MATCHED_INTEGRATION_PENDING",
                "source_schema": SOURCE_SCHEMA, "original_stream_binding": {
                    "status": "MATCHED_EXACT_FILES", "stdout": stdout_original,
                    "stderr": stderr_original}, "outer_fields": outer,
                "commit_proofs": proof_result, "receiver_metadata": metadata,
                "publication_authorized": False, "direct_execution_binding": "PENDING",
                "admission_committed_report_and_reopened_readback": "PENDING"}
    except wire.Refusal:
        raise
    except (OSError, ValueError, KeyError, TypeError, OverflowError,
            RecursionError, sqlite3.Error):
        raise _fault() from None
    finally:
        try:
            if proofs is not None:
                try:
                    proofs.close()
                except (ValueError, sqlite3.Error):
                    raise _fault() from None
        finally:
            for original in (stdout, stderr):
                if original is not None:
                    original.close()


def extract_decoded_refusal(stdout_path, stdout_binding, stderr_path, stderr_binding, *,
                            guard, expected_limit, expected_origin,
                            expected_categories=None, expected_charges=None):
    """Extract only the actual typed-budget stderr prefix and withhold raw tail.

    A matched typed refusal remains REFUSED; stdout must be empty. The human
    suffix is retained by exact span/hash, never returned as diagnostic text.
    Direct child exit/wait and failure cleanup are separate procedure proof.
    """
    stdout = stderr = None
    try:
        stdout = _Original(stdout_path, stdout_binding, guard)
        stderr = _Original(stderr_path, stderr_binding, guard)
        wire.need(_identity(stdout.initial) != _identity(stderr.initial),
                  "V2_STREAM_ORIGINALS_ALIAS_REFUSED")
        wire.need(stdout.expected_size == 0, "V2_STREAM_REFUSAL_STDOUT_NOT_EMPTY")
        stdout_original = stdout.finish()
        parser = _JSON(stderr)

        def refusal():
            def read(name):
                if name == "admitted_usage":
                    return _usage(parser)
                if name == "accounting":
                    return parser.equal_string(checks.ACCOUNTING)
                if name == "phase":
                    return parser.choice(checks.CATEGORIES)
                if name == "overflow":
                    return parser.boolean()
                return parser.number(uint=True)

            return parser.object(("accounting", "phase", "measured_bytes", "limit_bytes",
                                  "overflow", "admitted_bytes", "rejected_charge_bytes",
                                  "admitted_usage"), (), read)

        typed = parser.object(("format", "refusal", "rss"), (), lambda name:
            parser.equal_string(checks.NATIVE_REFUSAL) if name == "format" else
            refusal() if name == "refusal" else _rss(parser))
        # The actual Go encoder writes one JSON line, followed by main's
        # human refusal. Do not accept newline-injected/reformatted prefixes.
        wire.need(stderr.linefeeds == 0, "V2_STREAM_REFUSAL_JSON_MULTILINE_REFUSED")
        stderr.expect(b"\n")
        start, sha = stderr.offset, hashlib.sha256()
        stderr.taps.append(sha)
        last = b""
        try:
            stderr.expect(b"native receiving refused: ")
            while stderr.available():
                raw = stderr.consume(len(stderr.available()))
                last = raw[-1:]
        finally:
            stderr.taps.pop()
        wire.need(last == b"\n", "V2_STREAM_REFUSAL_HUMAN_SUFFIX_REFUSED")
        tail = {"offset_bytes": start, "bytes": stderr.offset - start,
                "sha256": sha.hexdigest(), "raw_text": "WITHHELD"}
        stderr_original = stderr.finish()
        result = checks.decoded_refusal(typed, expected_limit=expected_limit,
            expected_origin=expected_origin, expected_categories=expected_categories,
            expected_charges=expected_charges)
        result["source_schema"] = SOURCE_SCHEMA
        result["original_stream_binding"] = {"status": "MATCHED_EXACT_FILES",
            "stdout": stdout_original, "stderr": stderr_original}
        result["human_suffix"] = tail
        result["direct_execution_and_cleanup_binding"] = "PENDING"
        return result
    except wire.Refusal:
        raise
    except (OSError, ValueError, KeyError, TypeError, OverflowError, RecursionError):
        raise _fault() from None
    finally:
        for original in (stdout, stderr):
            if original is not None:
                original.close()
