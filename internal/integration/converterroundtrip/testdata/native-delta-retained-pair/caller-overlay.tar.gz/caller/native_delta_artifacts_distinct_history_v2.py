"""Reconciled successor of frozen attachment reconciliation, AUTHORED_NOT_RUN.

This checks attachment membership/hashes, source graph/events, family counts
and classifications, and the bounded v2 physical summary against disk replay.
The exact 22:27Z dolt_schemas ruling is applied as inert opaque carriage.
Portable business mapping, external config/sidecars, allocator semantics,
receiver accounting/admission/readback and execution lifetime remain pending.
No historical image arrays or aggregate native wire/evidence cap are used.
Only head.tar retains the existing 128 MiB portable attachment ceiling.
"""

import hashlib
from pathlib import Path
import re
import sqlite3

import native_delta_wire_v2 as wire
import native_delta_row_policy_v2 as row_policy
import native_delta_receiver_streams_v2 as streams
import native_delta_semantic_policy_v2 as semantic


_KINDS = frozenset(("bead", "edge", "comment", "memory", "config", "beads-archive"))
_OCTAL = re.compile(rb"[0-7]+\Z")
_REFERENCE = "9d6fff760b7a314b476539198504d77ce0959656"
_MANIFEST_REQUIRED = frozenset((
    "native_history_contract", "source_family_contract", "source_plane_address_contract",
    "format", "schema", "beads_reference", "store_id", "machine", "main_version",
    "ignored_version", "scope", "history", "projects", "kind_registry", "files",
    "sources", "warnings", "verification"))
_MANIFEST_OPTIONAL = frozenset(("status_category_contract", "source_fields_contract", "ontology"))
_INVENTORY_REQUIRED = frozenset((
    "native_history_contract", "source_family_contract", "source_plane_address_contract",
    "version", "store_id", "machine", "projects", "ontology", "quiesced", "remotes_merged",
    "working_set_clean", "history", "external", "config_policy"))
_INVENTORY_OPTIONAL = frozenset(("status_category_contract",))


def _frozen_bytes(path, binding, limit, guard):
    wire.need(wire.uint(binding["bytes"]) <= limit, "V2_ARTIFACT_FILE_LIMIT_REFUSED")
    original = streams._Original(path, binding, guard)
    try:
        value = bytearray()
        while original.available():
            guard()
            value.extend(original.consume(len(original.available())))
        bound = original.finish()
        return bytes(value), bound
    finally:
        original.close()


def _octal(raw):
    token = raw.rstrip(b"\x00 ").lstrip(b" ")
    wire.need(bool(token) and _OCTAL.fullmatch(token) is not None,
              "V2_ARTIFACT_TAR_NUMBER_REFUSED")
    return int(token, 8)


def _tar(raw, guard):
    # No extraction and no tarfile extension/long-name/PAX interpretation.
    # At most nine known members; payloads remain views into one bounded head.
    wire.need(1024 <= len(raw) <= wire.HEAD_BYTES and len(raw) % 512 == 0,
              "V2_ARTIFACT_TAR_LENGTH_REFUSED")
    members, previous, offset = {}, None, 0
    view = memoryview(raw)
    while offset < len(raw):
        guard()
        header = raw[offset:offset + 512]
        if header == bytes(512):
            wire.need(len(raw) - offset >= 1024, "V2_ARTIFACT_TAR_END_REFUSED")
            for start in range(offset, len(raw), wire.READ_BYTES):
                guard()
                wire.need(not any(view[start:start + wire.READ_BYTES]),
                          "V2_ARTIFACT_TAR_TRAILING_DATA_REFUSED")
            return members
        wire.need(len(header) == 512 and header[257:263] == b"ustar\x00" and
                  header[263:265] == b"00" and header[156:157] == b"0" and
                  not any(header[157:257]) and not any(header[265:329]) and
                  not any(header[345:512]), "V2_ARTIFACT_TAR_HEADER_REFUSED")
        wire.need(_octal(header[100:108]) == 0o600 and
                  _octal(header[108:116]) == _octal(header[116:124]) == 0 and
                  _octal(header[136:148]) == 0,
                  "V2_ARTIFACT_TAR_MODE_OR_OWNER_REFUSED")
        for device in (header[329:337], header[337:345]):
            wire.need(not any(device) or _octal(device) == 0,
                      "V2_ARTIFACT_TAR_DEVICE_REFUSED")
        checksum = sum(header[:148]) + 8 * 32 + sum(header[156:])
        wire.need(_octal(header[148:156]) == checksum, "V2_ARTIFACT_TAR_CHECKSUM_REFUSED")
        name_raw = header[:100].split(b"\x00", 1)[0]
        wire.need(header[:100] == name_raw + bytes(100 - len(name_raw)),
                  "V2_ARTIFACT_TAR_NAME_PADDING_REFUSED")
        name = name_raw.decode("ascii", "strict")
        allowed = name in ("manifest.json", "config/sources.json", "history/source.json") or (
            name.startswith("records/") and name.endswith(".ndjson") and name[8:-7] in _KINDS)
        wire.need(allowed and name not in members, "V2_ARTIFACT_TAR_MEMBER_REFUSED")
        wire.need((not members and name == "manifest.json") or (
            bool(members) and name != "manifest.json" and
            (previous is None or previous < name)), "V2_ARTIFACT_TAR_MEMBER_ORDER_REFUSED")
        if members:
            previous = name
        size = _octal(header[124:136])
        begin = wire.add(offset, 512)
        end = wire.add(begin, size)
        padded = wire.add(end, (-size) % 512)
        wire.need(size <= wire.HEAD_BYTES and padded <= len(raw),
                  "V2_ARTIFACT_TAR_MEMBER_LENGTH_REFUSED")
        wire.need(not any(view[end:padded]), "V2_ARTIFACT_TAR_MEMBER_PADDING_REFUSED")
        members[name] = view[begin:end]
        offset = padded
    raise wire.Refusal("V2_ARTIFACT_TAR_END_MISSING")


def _canonical_digest(value, guard):
    total, sha = 0, hashlib.sha256()
    for part in row_policy._go_json(value, guard):
        guard()
        total = wire.add(total, len(part))
        sha.update(part)
    return sha.digest(), total


class _Member:
    """Finite in-memory head member with the reviewed chunked JSON interface.

    This is an attachment view, not a frozen-original substitute. The entire
    head descriptor/hash/membership has to be verified by the public API first.
    Only a per-commit/event slice is decoded; native state stays in replay DB.
    """

    def __init__(self, raw, guard):
        self.raw, self.guard, self.offset = raw, guard, 0

    def available(self):
        self.guard()
        return bytes(self.raw[self.offset:self.offset + (64 << 10)])

    def peek(self):
        return self.available()[:1]

    def consume(self, count):
        wire.need(type(count) is int and 0 <= count <= len(self.available()),
                  "V2_ARTIFACT_MEMBER_READ_REFUSED")
        value = bytes(self.raw[self.offset:self.offset + count])
        self.offset += count
        return value

    def take(self, count):
        out = bytearray()
        while len(out) < count:
            available = len(self.available())
            wire.need(available > 0, "V2_ARTIFACT_MEMBER_UNEXPECTED_EOF")
            out.extend(self.consume(min(available, count - len(out))))
        return bytes(out)

    def expect(self, raw):
        wire.need(self.take(len(raw)) == raw, "V2_ARTIFACT_MEMBER_SYNTAX_REFUSED")

    def whitespace(self):
        while True:
            raw = self.available()
            count = len(raw) - len(raw.lstrip(b" \t\r\n"))
            if not count:
                return
            self.consume(count)


def _value(parser):
    parser.src.whitespace()
    start = parser.src.offset
    parser.skip()
    return row_policy._decode(bytes(parser.src.raw[start:parser.src.offset]), parser.src.guard)


def _array(parser, read):
    parser.char(b"[")
    parser.src.whitespace()
    count = 0
    if parser.src.peek() != b"]":
        while True:
            parser.src.guard()
            read(count)
            count = wire.add(count, 1)
            parser.src.whitespace()
            if parser.src.peek() != b",":
                break
            parser.src.consume(1)
    parser.char(b"]")
    return count


def _source_history(raw, replay, scratch_parent, guard):
    member = _Member(raw, guard)
    with streams._DiskKeys(scratch_parent, guard) as disk:
        parser = streams._JSON(member, disk)
        replay._execute("CREATE TABLE artifact_events(id BLOB PRIMARY KEY,normalized BLOB NOT NULL) WITHOUT ROWID")

        def commit(index):
            source = _value(parser)
            wire.fields(source, ("id", "parents", "metadata"))
            sequence = wire.add(index, 1)
            actual = replay._one("SELECT c.id,s.raw FROM commits c JOIN states s ON s.id=c.state_id WHERE c.sequence=?",
                                 (wire.u(sequence),))
            wire.need(actual is not None and source["id"] == actual[0],
                      "V2_ARTIFACT_SOURCE_COMMIT_ID_OR_ORDER_MISMATCH")
            parents = wire.array(source["parents"])
            for parent in parents:
                semantic._commit_id(parent)
            wire.need(len(set(parents)) == len(parents), "V2_ARTIFACT_SOURCE_DUPLICATE_PARENT")
            expected = iter(sorted(parents))
            for (parent,) in replay._iter("SELECT parent FROM parents WHERE child=? ORDER BY parent", (actual[0],)):
                wire.need(next(expected, None) == parent, "V2_ARTIFACT_SOURCE_PARENT_SET_MISMATCH")
            wire.need(next(expected, None) is None, "V2_ARTIFACT_SOURCE_PARENT_COUNT_MISMATCH")
            opening = row_policy._decode(actual[1], guard)
            wire.need(type(source["metadata"]) is dict, "V2_ARTIFACT_SOURCE_METADATA_REFUSED")
            row_policy.validate_secret_references(source["metadata"], guard=guard)
            wire.need(_canonical_digest(source["metadata"], guard) ==
                      _canonical_digest(opening["metadata"], guard),
                      "V2_ARTIFACT_SOURCE_METADATA_MISMATCH")

        last_event = None

        def event(_):
            nonlocal last_event
            source = _value(parser)
            wire.need(type(source) is dict and source.keys() == set(semantic._SURFACES["events"]),
                      "V2_ARTIFACT_SOURCE_EVENT_COLUMNS_REFUSED")
            identity = source.get("id")
            if type(identity) is row_policy._Number:
                identity = identity.spelling
            ident = wire.text(identity)
            wire.need(last_event is None or last_event < ident,
                      "V2_ARTIFACT_SOURCE_EVENT_ORDER_OR_DUPLICATE_REFUSED")
            last_event = ident
            row_policy.validate_secret_references(source, guard=guard)
            encoded = b"".join(row_policy._go_json(source, guard)) + b"\n"
            replay._execute("INSERT INTO artifact_events VALUES (?,?)", (ident, encoded))

        def source_range():
            def field(name):
                if name == "status":
                    parser.equal_string("unverified")
                elif name == "reason":
                    # D2 explicitly uses native-delta even when a CP11 frontier
                    # is attached. It does not revive v1's portable range claim.
                    parser.equal_string("native-delta")
                elif name == "complete":
                    wire.need(parser.boolean() is False, "V2_ARTIFACT_PORTABLE_COMPLETENESS_REFUSED")
                elif name in ("first", "head"):
                    wire.need(parser.number(uint=True) == 0, "V2_ARTIFACT_PORTABLE_RANGE_REFUSED")
                else:
                    parser.char(b"[")
                    parser.char(b"]")
                return None
            return parser.object(("status", "reason", "complete", "first", "head", "baseline",
                                  "baseline_events", "gaps", "frames"), (), field)

        def field(name):
            if name == "format":
                parser.equal_string("beads-dolt-images/1")
                return None
            if name == "commits":
                return _array(parser, commit)
            if name == "events":
                return _array(parser, event)
            return source_range()

        result = parser.object(("format", "commits", "events", "range"), (), field)
        member.whitespace()
        wire.need(member.offset == len(raw), "V2_ARTIFACT_SOURCE_TRAILING_BYTES_REFUSED")
        wire.need(result["commits"] == replay.counts["commits"],
                  "V2_ARTIFACT_SOURCE_COMMIT_COUNT_MISMATCH")
        # Compare multisets in both directions, even though valid event IDs
        # must also be unique. No data-bearing mismatch text is returned.
        wire.need(replay._one(
            "SELECT normalized,count(*) FROM artifact_events GROUP BY normalized EXCEPT "
            "SELECT normalized,count(*) FROM state_rows WHERE state_id=? AND name=? GROUP BY normalized LIMIT 1",
            (b"C", b"events")) is None, "V2_ARTIFACT_CURRENT_EVENTS_MISMATCH")
        wire.need(replay._one(
            "SELECT normalized,count(*) FROM state_rows WHERE state_id=? AND name=? GROUP BY normalized EXCEPT "
            "SELECT normalized,count(*) FROM artifact_events GROUP BY normalized LIMIT 1",
            (b"C", b"events")) is None, "V2_ARTIFACT_CURRENT_EVENTS_MISMATCH")
        coverage = replay.header["history_coverage"]
        if coverage is not None:
            attachment = coverage["events_attachment"]
            wire.need(attachment["member"] == "history/source.json" and
                      attachment["sha256"] == hashlib.sha256(raw).hexdigest() and
                      attachment["rows"] == result["events"],
                      "V2_ARTIFACT_COVERAGE_ATTACHMENT_MISMATCH")
        return {"commits": result["commits"], "events": result["events"],
                "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
                "portable_replay": "UNVERIFIED_NATIVE_DELTA_RANGE"}


def _prefixes(projects):
    wire.need(type(projects) is list and bool(projects), "V2_ARTIFACT_PROJECTS_REQUIRED")
    result = []
    for project in projects:
        wire.need(type(project) is dict and type(project.get("prefix")) is str,
                  "V2_ARTIFACT_PROJECT_SHAPE_REFUSED")
        prefix = project["prefix"]
        wire.need(semantic._PROJECT.fullmatch(prefix) is not None,
                  "V2_ARTIFACT_PROJECT_PREFIX_REFUSED")
        result.append(prefix)
    wire.need(len(set(result)) == len(result), "V2_ARTIFACT_PROJECT_DUPLICATE_REFUSED")
    return sorted(result)



def _history_marker(replay):
    # Business version/snapshot availability is independent of native commit
    # graph availability. Missing historical-business families count as zero.
    rows = 0
    for name in (b"issue_versions", b"issue_snapshots", b"compaction_snapshots"):
        replay.guard()
        found = replay._one("SELECT rows FROM state_tables WHERE state_id=? AND name=?", (b"C", name))
        if found is not None:
            rows = wire.add(rows, wire.uint(int.from_bytes(found[0], "big")))
    return "available-unverified" if rows else "unavailable"


def _manifest(members, replay, guard):
    wire.need(set(("manifest.json", "config/sources.json", "history/source.json")) <= members.keys(),
              "V2_ARTIFACT_REQUIRED_HEAD_MEMBERS_MISSING")
    value = wire.strict_json(bytes(members["manifest.json"]))
    wire.fields(value, _MANIFEST_REQUIRED, _MANIFEST_OPTIONAL)
    wire.need(value["format"] == "plug-dump/1" and wire.uint(value["schema"]) == 1 and
              value["beads_reference"] == _REFERENCE and value["native_history_contract"] == wire.CONTRACT and
              value["source_family_contract"] == "beads-source-families/1" and
              value["source_plane_address_contract"] == "beads-source-planes/1" and
              value["scope"] == "offline-head-and-source-archives" and
              value["history"] == "available-unverified" and
              value["store_id"] == replay.header["store_id"] and
              _prefixes(value["projects"]) == replay.header["projects"],
              "V2_ARTIFACT_MANIFEST_IDENTITY_OR_CONTRACT_REFUSED")
    wire.text(value["machine"])
    if "source_fields_contract" in value:
        wire.need(value["source_fields_contract"] == "beads-issues-source-fields/1",
                  "V2_ARTIFACT_SOURCE_FIELDS_MARKER_REFUSED")
    if "status_category_contract" in value:
        wire.need(value["status_category_contract"] == "beads-status-categories/1",
                  "V2_ARTIFACT_STATUS_MARKER_REFUSED")
    wire.need(type(value["verification"]) is dict and bool(value["verification"]) and
              type(value["warnings"]) is list and bool(value["warnings"]),
              "V2_ARTIFACT_INCOMPLETE_DISCLOSURES_REQUIRED")
    files = value["files"]
    wire.need(type(files) is dict and files.keys() == members.keys() - {"manifest.json"},
              "V2_ARTIFACT_MEMBER_MANIFEST_CENSUS_MISMATCH")
    for name, description in files.items():
        guard()
        wire.fields(description, ("sha256", "size"))
        wire.need(wire.uint(description["size"]) == len(members[name]) and
                  description["sha256"] == hashlib.sha256(members[name]).hexdigest(),
                  "V2_ARTIFACT_MEMBER_MANIFEST_HASH_MISMATCH")
    registered, previous = set(), None
    for kind in wire.array(value["kind_registry"]):
        guard()
        wire.fields(kind, ("name", "version", "file", "count"))
        name, version = kind["name"], wire.uint(kind["version"])
        wire.need(type(name) is str and name in _KINDS and (previous is None or previous < name) and
                  (version == 1 or name == "edge" and version in (2, 3)) and
                  kind["file"] == "records/" + name + ".ndjson" and
                  wire.uint(kind["count"]) > 0 and kind["file"] in members,
                  "V2_ARTIFACT_KIND_REGISTRY_REFUSED")
        previous = name
        raw = members[kind["file"]]
        wire.need(len(raw) > 0 and raw[-1] == 10, "V2_ARTIFACT_RECORD_TERMINATOR_REFUSED")
        # Lines are counted incrementally. Full portable record/business
        # mapping validation remains explicit pending work, not inferred.
        count = 0
        for start in range(0, len(raw), wire.READ_BYTES):
            guard()
            count = wire.add(count, bytes(raw[start:start + wire.READ_BYTES]).count(b"\n"))
        wire.need(count == kind["count"], "V2_ARTIFACT_RECORD_COUNT_MISMATCH")
        registered.add(kind["file"])
    wire.need(registered == {name for name in members if name.startswith("records/")},
              "V2_ARTIFACT_UNREGISTERED_RECORD_MEMBER_REFUSED")
    current_schema = replay._one("SELECT c.raw FROM schemas c JOIN states s ON s.schema_id=c.id WHERE s.id=?", (b"C",))
    wire.need(current_schema is not None, "V2_ARTIFACT_CURRENT_SCHEMA_MISSING")
    profile = wire.strict_json(current_schema[0])["profile"]
    wire.need((wire.uint(value["main_version"]), wire.uint(value["ignored_version"])) in ((66, 26), (72, 28)) and
              profile["main_version"] == value["main_version"] and
              profile["ignored_version"] == value["ignored_version"],
              "V2_ARTIFACT_MANIFEST_CURRENT_CURSOR_MISMATCH")
    replay._execute("CREATE TABLE artifact_families(name BLOB PRIMARY KEY) WITHOUT ROWID")
    count = 0
    for source in wire.array(value["sources"]):
        guard()
        wire.fields(source, ("family", "rows", "action", "reason"), ("history",))
        family = source["family"]
        wire.text(family)
        wire.uint(source["rows"])
        wire.text(source["action"])
        wire.text(source["reason"])
        if family not in semantic._SURFACES:
            wire.need("history" not in source, "V2_ARTIFACT_EXTERNAL_HISTORY_CLASSIFICATION_REFUSED")
            continue
        name = wire.text(family)
        actual = replay._one("SELECT t.rows,c.history FROM state_tables t JOIN policy_classification c "
                             "ON c.name=t.name WHERE t.state_id=? AND t.name=?", (b"C", name))
        wire.need(actual is not None and source["rows"] == int.from_bytes(actual[0], "big") and
                  source.get("history") == actual[1],
                  "V2_ARTIFACT_SOURCE_FAMILY_CLASSIFICATION_OR_COUNT_MISMATCH")
        if actual[1] == "unversioned-in-beads-by-design":
            wire.need("unversioned in Beads by design" in source["reason"],
                      "V2_ARTIFACT_UNVERSIONED_LABEL_MISSING")
        wire.need(replay._one("SELECT 1 FROM artifact_families WHERE name=?", (name,)) is None,
                  "V2_ARTIFACT_SOURCE_FAMILY_DUPLICATE_REFUSED")
        replay._execute("INSERT INTO artifact_families VALUES (?)", (name,))
        count = wire.add(count, 1)
    wire.need(replay._one("SELECT name FROM policy_classification EXCEPT SELECT name FROM artifact_families LIMIT 1") is None,
              "V2_ARTIFACT_SOURCE_FAMILY_CENSUS_INCOMPLETE")
    for name, rows in replay._iter("SELECT name,rows FROM state_tables WHERE state_id=?", (b"C",)):
        decoded = name.decode("utf-8", "strict")
        if decoded not in semantic._SURFACES:
            wire.need(decoded in ("dolt_ignore", "dolt_nonlocal_tables", "dolt_schemas"),
                      "V2_ARTIFACT_UNMAPPED_CURRENT_PHYSICAL_FAMILY_REFUSED")
    return value, count



def _opaque_families(replay, guard):
    """Count inert native rows from the authenticated disk states.

    Never parse SQL definitions or create/run a view or trigger. The replay
    retains every typed row payload, key and exact normalized byte sequence;
    this function references its independently verified table commitments.
    Proof rows remain on disk, including explicit absence in each state.
    """
    replay._execute("CREATE TABLE artifact_opaque_states("
                    "state_id BLOB PRIMARY KEY, present INTEGER NOT NULL, rows BLOB, "
                    "table_schema_id TEXT, sha256 TEXT) WITHOUT ROWID")
    states, present_states, retained_commits, retained_rows = 0, 0, 0, 0
    proof = wire.domain_hash("caller-native-opaque-family-states/1")
    proof.update(wire.s("dolt_schemas"))
    for state_id, kind, schema_id, root, complete in replay._iter(
            "SELECT id,kind,schema_id,root,complete FROM states ORDER BY id"):
        guard()
        wire.need(complete == 1, "V2_ARTIFACT_OPAQUE_INCOMPLETE_STATE_REFUSED")
        for name, count in replay._iter(
                "SELECT name,rows FROM state_tables WHERE state_id=? ORDER BY name", (state_id,)):
            guard()
            family = name.decode("utf-8", "strict")
            if family not in semantic._SURFACES:
                wire.need(family in ("dolt_ignore", "dolt_nonlocal_tables", "dolt_schemas"),
                          "V2_ARTIFACT_UNMAPPED_PHYSICAL_STATE_FAMILY_REFUSED")
        table = replay._one("SELECT rows,table_schema_id,sha256 FROM state_tables "
                            "WHERE state_id=? AND name=?", (state_id, b"dolt_schemas"))
        proof.update(wire.b(state_id))
        proof.update(wire.s(kind))
        proof.update(wire.s(schema_id))
        proof.update(wire.s(root))
        if table is None:
            proof.update(b"\x00")
            replay._execute("INSERT INTO artifact_opaque_states VALUES (?,0,NULL,NULL,NULL)", (state_id,))
        else:
            rows, table_schema_id, sha256 = table
            count = wire.uint(int.from_bytes(rows, "big"))
            actual = replay._one("SELECT count(*) FROM state_rows WHERE state_id=? AND name=?",
                                 (state_id, b"dolt_schemas"))[0]
            wire.need(actual == count, "V2_ARTIFACT_OPAQUE_ROW_CENSUS_MISMATCH")
            wire.digest(table_schema_id)
            wire.digest(sha256)
            proof.update(b"\x01" + wire.u(count))
            proof.update(wire.s(table_schema_id))
            proof.update(wire.s(sha256))
            replay._execute("INSERT INTO artifact_opaque_states VALUES (?,1,?,?,?)",
                            (state_id, rows, table_schema_id, sha256))
            present_states = wire.add(present_states, 1)
            if kind == "commit":
                retained_commits = wire.add(retained_commits, 1)
                retained_rows = wire.add(retained_rows, count)
        states = wire.add(states, 1)
    wire.need(states == wire.add(replay.counts["commits"], 2),
              "V2_ARTIFACT_OPAQUE_STATE_CENSUS_MISMATCH")
    head = replay._retained(replay.header["head"])[0]
    head_present = replay._one("SELECT present FROM artifact_opaque_states WHERE state_id=?", (head,))
    current = replay._one("SELECT present,rows FROM artifact_opaque_states WHERE state_id=?", (b"C",))
    wire.need(head_present is not None and current is not None and head_present[0] == current[0],
              "V2_ARTIFACT_OPAQUE_HEAD_CURRENT_PRESENCE_MISMATCH")
    if current[0]:
        # Same versioned normalized image rule as the known native families;
        # each state's original physical cells and key layout remain retained.
        replay._same_native_table(head, b"C", "dolt_schemas")
    return {"family": "dolt_schemas", "policy": "opaque-native-inert",
            "current_present": bool(current[0]),
            "current_rows": int.from_bytes(current[1], "big") if current[0] else 0,
            "retained_commit_images_with_family": retained_commits,
            "retained_commit_row_occurrences": retained_rows,
            "states_inspected": states, "states_with_family": present_states,
            "state_proof_sha256": proof.hexdigest(),
            "state_proof_domain": "caller-native-opaque-family-states/1",
            "state_proof_rows": "artifact_opaque_states",
            "view_trigger_execution": "NONE",
            "receiver_import_report_family_counts": "PENDING",
            "reverse_undo_persistence": "PENDING"}


def _inventory(raw, manifest, replay):
    value = wire.strict_json(raw)
    wire.fields(value, _INVENTORY_REQUIRED, _INVENTORY_OPTIONAL)
    wire.need(value["version"] == "beads-inventory/1" and
              value["native_history_contract"] == wire.CONTRACT and
              value["source_family_contract"] == manifest["source_family_contract"] and
              value["source_plane_address_contract"] == manifest["source_plane_address_contract"] and
              value["store_id"] == manifest["store_id"] == replay.header["store_id"] and
              value["machine"] == manifest["machine"] and
              _prefixes(value["projects"]) == replay.header["projects"] and
              value["config_policy"] == replay.header["config_policy"] and
              value["quiesced"] is True and value["remotes_merged"] is True and
              value["working_set_clean"] is True and
              value["history"] == _history_marker(replay) and
              value.get("status_category_contract") == manifest.get("status_category_contract"),
              "V2_ARTIFACT_INVENTORY_IDENTITY_POLICY_OR_DECLARATION_MISMATCH")
    # These booleans remain operator declarations. No writer exclusion or
    # source-handle lifetime is inferred from their presence or truth value.
    return value


def _evidence(raw, capture_set, replay, expected_database):
    value = wire.strict_json(raw)
    wire.fields(value, ("format", "capture_set_sha256", "store_id", "projects", "sql_defaults",
                        "working", "totals", "head_root_sha256", "current_root_sha256"))
    wire.need(value["format"] == wire.EVIDENCE_FORMAT and
              value["capture_set_sha256"] == capture_set.root_sha256 and
              value["store_id"] == replay.header["store_id"] and
              value["projects"] == replay.header["projects"] and value["sql_defaults"] == "not-captured" and
              wire.totals(value["totals"]) == replay.counts == capture_set.root["totals"] and
              value["head_root_sha256"] == replay.head_root and
              value["current_root_sha256"] == replay.current_root,
              "V2_ARTIFACT_PHYSICAL_SUMMARY_BINDING_MISMATCH")
    working = value["working"]
    wire.fields(working, ("format", "database", "head_commit_id", "working_root_hash", "read_only_scope", "complete"))
    wire.need(working["format"] == "beads-physical-working-root/1" and
              working["database"] == expected_database and
              working["head_commit_id"] == replay.header["head"] and
              working["read_only_scope"] is True and working["complete"] is True,
              "V2_ARTIFACT_WORKING_IDENTITY_MISMATCH")
    semantic._commit_id(working["working_root_hash"])
    return value


def bind_artifacts(capture_set, replay, *, head_path, head_binding, inventory_path, inventory_binding,
                   evidence_path, evidence_binding, expected_database, scratch_parent, guard):
    """Match frozen originals; return a partial receipt with publication false."""
    try:
        guard()
        wire.need(type(replay) is semantic.SemanticReplay and replay.policy_verified and
                  replay.structural_verified and capture_set.transport_verified and
                  capture_set.root_fd is not None, "V2_ARTIFACT_AUTHENTICATED_POLICY_REPLAY_REQUIRED")
        wire.text(expected_database)
        directory = Path(capture_set.directory)
        wire.need(head_path == str(directory / "head.tar") and
                  inventory_path == str(directory.parent / "inventory.json") and
                  evidence_path == str(directory.parent / "physical-evidence.json"),
                  "V2_ARTIFACT_FIXED_SIBLING_PATHS_REQUIRED")
        wire.need(head_binding == {"sha256": capture_set.root["head_archive"]["sha256"],
                                  "bytes": capture_set.root["head_archive"]["size"]},
                  "V2_ARTIFACT_HEAD_ROOT_BINDING_MISMATCH")
        head, head_original = _frozen_bytes(head_path, head_binding, wire.HEAD_BYTES, guard)
        members = _tar(head, guard)
        manifest, family_count = _manifest(members, replay, guard)
        opaque = _opaque_families(replay, guard)
        history = _source_history(members["history/source.json"], replay, scratch_parent, guard)
        inventory_raw, inventory_original = _frozen_bytes(inventory_path, inventory_binding, 4 << 20, guard)
        _inventory(inventory_raw, manifest, replay)
        # This is a bound on ONE finite summary record, not aggregate v2
        # detail evidence. Actual detail remains in unbounded-total parts.
        evidence_raw, evidence_original = _frozen_bytes(evidence_path, evidence_binding, wire.RECORD_BYTES, guard)
        _evidence(evidence_raw, capture_set, replay, expected_database)
        guard()
        capture_set._root_stable()
        replay.db.commit()
        return {"status": "HEAD_SOURCE_AND_PHYSICAL_SUMMARY_MATCHED_PARTIAL",
                "capture_set_sha256": capture_set.root_sha256,
                "head_original": head_original, "inventory_original": inventory_original,
                "evidence_original": evidence_original,
                "portable_graph_events": history, "current_source_families": family_count,
                "opaque_native_family_counts": {"dolt_schemas": opaque},
                "operator_capture_declarations": "PRESENT_TRUE_NOT_INDEPENDENT_WRITER_OR_LIFETIME_PROOF",
                "portable_business_mapping_and_verification_claims": "PENDING",
                "external_config_sidecars_ontology_and_project_allocators": "PENDING",
                "receiver_categories_admission_committed_report_and_persistent_readback": "PENDING",
                "direct_wait_lifetime_and_cleanup": "PENDING",
                "publication_authorized": False}
    except wire.Refusal:
        raise
    except (OSError, ValueError, KeyError, TypeError, OverflowError, UnicodeError,
            RecursionError, sqlite3.Error):
        raise wire.Refusal("V2_ARTIFACT_INTEGRATION_FAULT") from None
