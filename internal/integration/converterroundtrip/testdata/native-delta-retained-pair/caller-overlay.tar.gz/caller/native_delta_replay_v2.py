"""Disk-backed STRUCTURAL replay above unchanged caller wire 4879fb5b.

AUTHORED_NOT_RUN. This source is a separate partial unit, with no CLI. It
does not supply a policy implementation, portable-head/evidence/source
reconciliation, receiver accounting/import validation, or procedure pins.
Its receipt expressly cannot authorize publication. A policy callback is
mandatory BEFORE retaining header/schema/metadata/row values; supplying a
callback is not itself evidence of policy correctness or qualification.

Each immutable state is staged on disk, including actual first-parent
copies. SQLite page caching is bounded and temporary sorting uses disk;
Python never accumulates all commits, tables, rows or part receipts. The
only decoded objects are a bounded wire record, the active schema/table,
and a constant number of bounded rows. No aggregate wire/history cap is
introduced. Disk/resource failures refuse rather than truncate.

The context creates one private scratch child of an explicit caller-owned
parent. That child is deleted only within the guard. STOP/PAUSE preserves
scratch rather than bypassing the guard to remove it. Later procedure
integration must retain terminal cleanup receipts using its owned lifetime.
"""

import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import stat

import native_delta_wire_v2 as wire


WIRE_SHA256 = "4879fb5bf0f5315155b20a75069b2dca63de7b42afcfd97ed16dc0407516448e"
STATUS = "STRUCTURAL_REPLAY_VERIFIED_INTEGRATION_PENDING"
_FILES = frozenset(("replay.sqlite", "replay.sqlite-journal",
                    "replay.sqlite-wal", "replay.sqlite-shm"))


def _times(left, right):
    result = wire.uint(left) * wire.uint(right)
    wire.need(result <= wire.UINT64_MAX, "V2_COUNTER_OVERFLOW")
    return result


def _same_object(left, right):
    return (left.st_dev, left.st_ino, left.st_uid) == (
        right.st_dev, right.st_ino, right.st_uid)


def _json_storage(value):
    """Private schema definitions contain only strings and uint64/nulls."""
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _go_string(value):
    """encoding/json string spelling; no float or generic-object encoder."""
    wire.text(value, empty=True)
    return (json.dumps(value, ensure_ascii=False)
            .replace("&", "\\u0026").replace("<", "\\u003c")
            .replace(">", "\\u003e").replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029").encode("utf-8"))


def _profile_size(profile):
    """Count b1 NativeCommitSchemaProfile struct bytes, without a frame."""
    size = len(b'{"format":') + len(_go_string(profile["format"]))
    size = wire.add(size, len(b',"scope":') + len(_go_string(profile["scope"])))
    for name in ("main_version", "ignored_version"):
        value = profile[name]
        token = b"null" if value is None else str(wire.uint(value)).encode("ascii")
        size = wire.add(size, len(b',"') + len(name) + len(b'":') + len(token))
    size = wire.add(size, len(b',"absences":['))
    for index, absence in enumerate(profile["absences"]):
        size = wire.add(size, (1 if index else 0) + len(b'{"family":') +
                        len(_go_string(absence["family"])))
        if "column" in absence:
            size = wire.add(size, len(b',"column":') + len(_go_string(absence["column"])))
        size = wire.add(size, len(b',"reason":') + len(_go_string(absence["reason"])) + 1)
    return wire.add(size, len(b"]}"))


class StructuralReplay:
    """One guarded, owned disk stage; consume only an opened CaptureSet.

    validate_record is a REQUIRED independent semantic/policy hook:
        validate_record(header=header_or_None, record=record, table=schema_or_None)
    It must refuse typed/normalized/secret/profile/metadata violations before
    return. This file supplies NO accept-all default or implementation of
    that hook. The later integrated adapter still must verify the exact hook
    source, reconcile current/versioned classification and bind all external
    receipts. Even with a hook, this unit's result remains partial.
    """

    def __init__(self, scratch_parent, *, guard, validate_record):
        wire.need(callable(guard) and callable(validate_record), "V2_REPLAY_HOOK_REQUIRED")
        self.parent_path = Path(scratch_parent)
        self.guard = guard
        self.validate_record = validate_record
        self.parent_fd = self.dir_fd = self.db = None
        self.name = None
        self.directory_info = None
        self.started = self.structural_verified = False
        self.header = self.state = self.table = None
        self.phase = "header"
        self.counts = {name: 0 for name in wire.TOTAL_FIELDS}
        self.head_root = self.current_root = None
        self._guard_failed = False

    def __enter__(self):
        try:
            self.guard()
            wire.need(self.parent_path.is_absolute() and
                      self.parent_path.resolve(strict=True) == self.parent_path,
                      "V2_REPLAY_PARENT_CANONICAL_REQUIRED")
            self.parent_fd = os.open(self.parent_path, os.O_RDONLY | os.O_DIRECTORY |
                                     os.O_NOFOLLOW | os.O_CLOEXEC)
            parent_info = os.fstat(self.parent_fd)
            wire.need(parent_info.st_uid == os.getuid() and
                      not parent_info.st_mode & 0o022,
                      "V2_REPLAY_PARENT_OWNER_MODE_REFUSED")
            self.name = "native-replay-" + secrets.token_hex(16)
            self.guard()
            os.mkdir(self.name, 0o700, dir_fd=self.parent_fd)
            self.directory_info = os.stat(self.name, dir_fd=self.parent_fd, follow_symlinks=False)
            self.dir_fd = os.open(self.name, os.O_RDONLY | os.O_DIRECTORY |
                                  os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.parent_fd)
            wire.need(_same_object(os.fstat(self.dir_fd), self.directory_info) and
                      self.directory_info.st_uid == os.getuid() and
                      stat.S_ISDIR(self.directory_info.st_mode) and
                      self.directory_info.st_mode & 0o777 == 0o700,
                      "V2_REPLAY_SCRATCH_OWNER_MODE_REFUSED")
            self.guard()
            fd = os.open("replay.sqlite", os.O_RDWR | os.O_CREAT | os.O_EXCL |
                         os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=self.dir_fd)
            os.close(fd)
            # The directory descriptor pins the private child. No record may
            # supply a database, table name, SQL fragment or filesystem path.
            self.guard()
            self.db = sqlite3.connect(f"/proc/self/fd/{self.dir_fd}/replay.sqlite")
            self.db.set_progress_handler(self._progress, 10000)
            self._execute("PRAGMA journal_mode=DELETE")
            self._execute("PRAGMA synchronous=FULL")
            self._execute("PRAGMA temp_store=FILE")
            self._execute("PRAGMA cache_size=-8192")
            self._execute("PRAGMA mmap_size=0")
            self._execute("PRAGMA trusted_schema=OFF")
            self.guard()
            self.db.executescript("""
                CREATE TABLE schemas (
                    id TEXT PRIMARY KEY, raw BLOB NOT NULL
                ) WITHOUT ROWID;
                CREATE TABLE definitions (
                    schema_id TEXT NOT NULL, name BLOB NOT NULL,
                    table_schema_id TEXT NOT NULL, raw BLOB NOT NULL,
                    PRIMARY KEY(schema_id, name)
                ) WITHOUT ROWID;
                CREATE TABLE states (
                    id BLOB PRIMARY KEY, kind TEXT NOT NULL, schema_id TEXT NOT NULL,
                    root TEXT, raw BLOB NOT NULL, complete INTEGER NOT NULL DEFAULT 0
                ) WITHOUT ROWID;
                CREATE TABLE commits (
                    id TEXT PRIMARY KEY, sequence BLOB UNIQUE NOT NULL,
                    state_id BLOB UNIQUE NOT NULL
                ) WITHOUT ROWID;
                CREATE TABLE parents (
                    child TEXT NOT NULL, parent TEXT NOT NULL, ordinal BLOB NOT NULL,
                    PRIMARY KEY(child, parent), UNIQUE(child, ordinal)
                ) WITHOUT ROWID;
                CREATE INDEX parent_lookup ON parents(parent, child);
                CREATE TABLE boundaries (
                    parent TEXT NOT NULL, child TEXT NOT NULL,
                    PRIMARY KEY(parent, child)
                ) WITHOUT ROWID;
                CREATE TABLE missing_edges (
                    parent TEXT NOT NULL, child TEXT NOT NULL,
                    PRIMARY KEY(parent, child)
                ) WITHOUT ROWID;
                CREATE TABLE state_tables (
                    state_id BLOB NOT NULL, name BLOB NOT NULL,
                    table_schema_id TEXT NOT NULL, rows BLOB, sha256 TEXT,
                    PRIMARY KEY(state_id, name)
                ) WITHOUT ROWID;
                CREATE TABLE state_rows (
                    state_id BLOB NOT NULL, name BLOB NOT NULL, key BLOB NOT NULL,
                    payload BLOB NOT NULL, normalized BLOB NOT NULL,
                    PRIMARY KEY(state_id, name, key)
                ) WITHOUT ROWID;
            """)
            self.guard()
            self.db.commit()
            return self
        except (OSError, ValueError, sqlite3.Error):
            self.close()
            raise wire.Refusal("V2_REPLAY_STAGE_OPEN_REFUSED") from None
        except BaseException:
            self.close()
            raise

    def _progress(self):
        try:
            self.guard()
        except BaseException:
            self._guard_failed = True
            return 1
        return 0

    def _execute(self, sql, args=()):
        self.guard()
        try:
            return self.db.execute(sql, args)
        except sqlite3.Error:
            code = "V2_REPLAY_GUARD_REFUSED" if self._guard_failed else "V2_REPLAY_STORAGE_REFUSED"
            raise wire.Refusal(code) from None

    def _one(self, sql, args=()):
        cursor = self._execute(sql, args)
        try:
            return cursor.fetchone()
        finally:
            cursor.close()

    def _iter(self, sql, args=()):
        cursor = self._execute(sql, args)
        try:
            while True:
                self.guard()
                item = cursor.fetchone()
                if item is None:
                    break
                yield item
        finally:
            cursor.close()

    def _approve(self, record, table=None):
        self.guard()
        try:
            self.validate_record(header=self.header, record=record, table=table)
        except wire.Refusal:
            raise
        except Exception:
            raise wire.Refusal("V2_REPLAY_POLICY_HOOK_FAULT") from None

    def _increment(self, name, amount=1):
        self.counts[name] = wire.add(self.counts[name], amount)

    def _header(self, record, raw):
        wire.need(self.phase == "header" and wire.uint(record["commit_count"]) > 0,
                  "V2_REPLAY_HEADER_ORDER_REFUSED")
        self._approve(record)
        coverage = record["history_coverage"]
        if coverage is not None:
            wire.need(coverage["verified_commit_count"] == record["commit_count"],
                      "V2_REPLAY_COVERAGE_COUNT_MISMATCH")
            for boundary in coverage["boundaries"]:
                for child in boundary["child_commit_ids"]:
                    wire.need(not self._one("SELECT 1 FROM boundaries WHERE parent=? AND child=?",
                                            (boundary["commit_id"], child)),
                              "V2_REPLAY_DUPLICATE_BOUNDARY_EDGE")
                    self._execute("INSERT INTO boundaries VALUES (?, ?)",
                                  (boundary["commit_id"], child))
        self.header = record
        self.phase = "commits"

    def _schema(self, record, raw):
        wire.need(self.state is None and self.phase in ("commits", "head-checkpoint", "current"),
                  "V2_REPLAY_SCHEMA_ORDER_REFUSED")
        self._approve(record)
        wire.need(not self._one("SELECT 1 FROM schemas WHERE id=?", (record["schema_id"],)),
                  "V2_REPLAY_REPEATED_SCHEMA_REFUSED")
        self._execute("INSERT INTO schemas VALUES (?, ?)", (record["schema_id"], raw))
        for table in record["tables"]:
            self._execute("INSERT INTO definitions VALUES (?, ?, ?, ?)",
                          (record["schema_id"], wire.text(table["name"]),
                           wire.table_schema_id(table), _json_storage(table)))
        self._increment("schemas")

    def _retained(self, commit_id):
        return self._one("SELECT c.state_id, s.complete FROM commits c "
                         "JOIN states s ON s.id=c.state_id WHERE c.id=?", (commit_id,))

    def _begin_state(self, record, raw, kind, base=None):
        wire.need(self.state is None and self.table is None and
                  self._one("SELECT 1 FROM schemas WHERE id=?", (record["schema_id"],)),
                  "V2_REPLAY_STATE_OR_SCHEMA_REFUSED")
        state_id = b"K" + wire.text(record["commit_id"]) if kind == "commit" else (
            b"H" if kind == "head-checkpoint" else b"C")
        self._execute("INSERT INTO states(id, kind, schema_id, raw) VALUES (?, ?, ?, ?)",
                      (state_id, kind, record["schema_id"], raw))
        union = self._execute(
            "SELECT name FROM definitions WHERE schema_id=? "
            "UNION SELECT name FROM state_tables WHERE state_id=? ORDER BY name",
            (record["schema_id"], base))
        self.state = {"id": state_id, "record": record, "kind": kind,
                      "base": base, "union": union, "next": union.fetchone()}

    def _commit(self, record, raw):
        wire.need(self.phase == "commits" and self.state is None and
                  record["sequence"] == wire.add(self.counts["commits"], 1) and
                  record["sequence"] <= self.header["commit_count"],
                  "V2_REPLAY_COMMIT_SEQUENCE_REFUSED")
        parents = record["parents"]
        first = parents[0] if parents else None
        wire.need(record["first_parent"] == first and record["commit_id"] not in parents and
                  len(set(parents)) == len(parents), "V2_REPLAY_ORDERED_PARENTS_REFUSED")
        wire.need(self._retained(record["commit_id"]) is None, "V2_REPLAY_REPEATED_COMMIT_REFUSED")
        self._approve(record)
        base = None
        for ordinal, parent in enumerate(parents):
            retained = self._retained(parent)
            if retained is not None:
                wire.need(retained[1] == 1, "V2_REPLAY_PARENT_NOT_COMPLETE")
                if ordinal == 0:
                    base = retained[0]
            else:
                wire.need(self._one("SELECT 1 FROM boundaries WHERE parent=? AND child=?",
                                    (parent, record["commit_id"])),
                          "V2_REPLAY_UNJUSTIFIED_MISSING_PARENT")
                self._execute("INSERT INTO missing_edges VALUES (?, ?)",
                              (parent, record["commit_id"]))
            self._execute("INSERT INTO parents VALUES (?, ?, ?)",
                          (record["commit_id"], parent, wire.u(ordinal)))
        expected_mode = "delta" if base is not None else "snapshot"
        expected_base = first if base is not None else None
        wire.need(record["mode"] == expected_mode and record["base_commit"] == expected_base,
                  "V2_REPLAY_CANONICAL_COMMIT_MODE_REFUSED")
        self._begin_state(record, raw, "commit", base)
        self._execute("INSERT INTO commits VALUES (?, ?, ?)",
                      (record["commit_id"], wire.u(record["sequence"]), self.state["id"]))

    def _checkpoint(self, record, raw):
        wire.need(self.state is None and record["type"] == self.phase and
                  self.counts["commits"] == self.header["commit_count"] and
                  record["commit_id"] == self.header["head"],
                  "V2_REPLAY_CHECKPOINT_ORDER_REFUSED")
        head = self._retained(self.header["head"])
        wire.need(head is not None and head[1] == 1, "V2_REPLAY_HEAD_NOT_RETAINED")
        self._approve(record)
        self._begin_state(record, raw, record["type"])

    def _name(self, record):
        wire.need(self.state is not None and self.table is None and
                  self.state["next"] == (wire.text(record["name"]),),
                  "V2_REPLAY_TABLE_UNION_ORDER_REFUSED")
        return wire.text(record["name"])

    def _advance(self):
        self.state["next"] = self.state["union"].fetchone()

    def _table(self, record, raw):
        name = self._name(record)
        definition = self._one("SELECT table_schema_id, raw FROM definitions "
                               "WHERE schema_id=? AND name=?",
                               (self.state["record"]["schema_id"], name))
        wire.need(definition is not None and record["table_schema_id"] == definition[0],
                  "V2_REPLAY_TABLE_DEFINITION_MISMATCH")
        previous = self._one("SELECT table_schema_id FROM state_tables WHERE state_id=? AND name=?",
                             (self.state["base"], name))
        delta = previous is not None and previous[0] == definition[0]
        wire.need(record["mode"] == ("delta" if delta else "replace"),
                  "V2_REPLAY_CANONICAL_TABLE_MODE_REFUSED")
        table = wire.strict_json(definition[1])
        self._execute("INSERT INTO state_tables(state_id, name, table_schema_id) VALUES (?, ?, ?)",
                      (self.state["id"], name, definition[0]))
        if delta:
            self._execute("INSERT INTO state_rows SELECT ?, name, key, payload, normalized "
                          "FROM state_rows WHERE state_id=? AND name=?",
                          (self.state["id"], self.state["base"], name))
        self.table = {"record": record, "name": name, "definition": table,
                      "operations": 0, "previous_key": None,
                      "keyless": not any(c["primary_key_ordinal"] is not None
                                         for c in table["columns"])}

    def _drop(self, record, raw):
        name = self._name(record)
        wire.need(self.state["kind"] == "commit" and self.state["base"] is not None and
                  not self._one("SELECT 1 FROM definitions WHERE schema_id=? AND name=?",
                                (self.state["record"]["schema_id"], name)),
                  "V2_REPLAY_DROP_PRESENT_OR_SNAPSHOT_REFUSED")
        previous = self._one("SELECT table_schema_id FROM state_tables WHERE state_id=? AND name=?",
                             (self.state["base"], name))
        wire.need(previous is not None and previous[0] == record["previous_table_schema_id"],
                  "V2_REPLAY_DROP_SCHEMA_MISMATCH")
        self._advance()

    def _row(self, record, raw):
        wire.need(self.table is not None, "V2_REPLAY_ROW_OUTSIDE_TABLE")
        table = self.table
        key = wire.b64(record["key"], nonempty=True)
        wire.need(table["previous_key"] is None or table["previous_key"] < key,
                  "V2_REPLAY_OPERATION_KEY_ORDER_REFUSED")
        location = (self.state["id"], table["name"], key)
        op = record["op"]
        if op == "delete":
            wire.need(table["record"]["mode"] == "delta" and
                      self._one("SELECT 1 FROM state_rows WHERE state_id=? AND name=? AND key=?",
                                location), "V2_REPLAY_DELETE_PRECONDITION_REFUSED")
            self._execute("DELETE FROM state_rows WHERE state_id=? AND name=? AND key=?", location)
        else:
            normalized = wire.b64(record["normalized_json"], nonempty=True)
            row = wire.strict_json(normalized)
            wire.need(type(row) is dict and row.keys() ==
                      {column["name"] for column in table["definition"]["columns"]},
                      "V2_REPLAY_NORMALIZED_COLUMNS_MISMATCH")
            payload = wire.row_payload(record["cells"], normalized)
            canonical = wire.primary_key(table["definition"], record["cells"])
            if canonical is None:
                wire.need(len(key) == 44 and key[:4] == b"bag\x00" and
                          wire.bag_key(payload, int.from_bytes(key[-8:], "big")) == key and
                          op == "insert", "V2_REPLAY_KEYLESS_KEY_OR_UPDATE_REFUSED")
            else:
                wire.need(key == canonical, "V2_REPLAY_PRIMARY_KEY_MISMATCH")
            old = self._one("SELECT payload FROM state_rows WHERE state_id=? AND name=? AND key=?",
                            location)
            wire.need((op == "insert" and old is None) or
                      (op == "update" and table["record"]["mode"] == "delta" and
                       old is not None and old[0] != payload),
                      "V2_REPLAY_ROW_PRECONDITION_REFUSED")
            # The required policy hook sees actual schema and authenticated
            # header context before any row value is retained on disk.
            self._approve(record, table["definition"])
            if op == "insert":
                self._execute("INSERT INTO state_rows VALUES (?, ?, ?, ?, ?)",
                              (*location, payload, normalized))
            else:
                self._execute("UPDATE state_rows SET payload=?, normalized=? "
                              "WHERE state_id=? AND name=? AND key=?", (payload, normalized, *location))
        table["operations"] = wire.add(table["operations"], 1)
        table["previous_key"] = key

    def _table_rows(self):
        previous_group = previous_payload = None
        occurrence = 0
        for key, payload in self._iter("SELECT key, payload FROM state_rows "
                                       "WHERE state_id=? AND name=? ORDER BY key",
                                       (self.state["id"], self.table["name"])):
            if self.table["keyless"]:
                wire.need(len(key) == 44 and key[:4] == b"bag\x00" and
                          hashlib.sha256(payload).digest() == key[4:36],
                          "V2_REPLAY_KEYLESS_CONTENT_MISMATCH")
                group = key[4:36]
                if group != previous_group:
                    occurrence = 0
                    previous_payload = payload
                wire.need(payload == previous_payload and
                          int.from_bytes(key[-8:], "big") == occurrence,
                          "V2_REPLAY_KEYLESS_MULTIPLICITY_REFUSED")
                previous_group = group
                occurrence = wire.add(occurrence, 1)
            yield key, payload

    def _end_table(self, record, raw):
        wire.need(self.table is not None, "V2_REPLAY_END_TABLE_OUTSIDE_TABLE")
        actual = self._one("SELECT count(*) FROM state_rows WHERE state_id=? AND name=?",
                           (self.state["id"], self.table["name"]))[0]
        opening = self.table["record"]
        wire.need(record["rows"] == opening["expected_rows"] == actual and
                  record["row_operations"] == self.table["operations"],
                  "V2_REPLAY_TABLE_COUNT_MISMATCH")
        digest = wire.table_hash(self.table["definition"], actual, self._table_rows())
        wire.need(digest == record["sha256"] == opening["expected_sha256"],
                  "V2_REPLAY_TABLE_HASH_MISMATCH")
        self._execute("UPDATE state_tables SET rows=?, sha256=? WHERE state_id=? AND name=?",
                      (wire.u(actual), digest, self.state["id"], self.table["name"]))
        self._increment("table_transactions")
        self._increment("row_operations", self.table["operations"])
        self._increment("reconstructed_rows", actual)
        self._increment("reconstructed_cells", _times(actual, len(self.table["definition"]["columns"])))
        self.table = None
        self._advance()

    def _state_tables(self, state_id):
        for name, digest, rows in self._iter("SELECT name, sha256, rows FROM state_tables "
                                            "WHERE state_id=? ORDER BY name", (state_id,)):
            wire.need(digest is not None and rows is not None, "V2_REPLAY_INCOMPLETE_TABLE")
            yield name.decode("utf-8"), digest, int.from_bytes(rows, "big")

    def _legacy_image_size(self):
        # NativeHistoryImage's b1 struct order/omission and NativeTable's exact
        # columns/rows framing. Normalized row bytes are retained verbatim.
        # Canonical Go row spelling/coherence is a required policy-hook check;
        # this structural count alone does not prove that pending check.
        opening = self.state["record"]
        raw_schema = self._one("SELECT raw FROM schemas WHERE id=?", (opening["schema_id"],))[0]
        profile = wire.strict_json(raw_schema)["profile"]
        size = wire.add(len(b'{"schema_profile":'), _profile_size(profile))
        size = wire.add(size, len(b',"sequence":') + len(str(wire.uint(opening["sequence"]))))
        size = wire.add(size, len(b',"commit_id":') + len(_go_string(opening["commit_id"])))
        size = wire.add(size, len(b',"tables":{'))
        table_index = 0
        for name, raw_definition in self._iter(
                "SELECT d.name, d.raw FROM definitions d JOIN state_tables t "
                "ON d.name=t.name WHERE d.schema_id=? AND t.state_id=? ORDER BY d.name",
                (opening["schema_id"], self.state["id"])):
            definition = wire.strict_json(raw_definition)
            size = wire.add(size, (1 if table_index else 0) +
                            len(_go_string(name.decode("utf-8"))) + len(b':{"columns":['))
            # Column ordering does not affect byte count; every name is
            # included exactly once, with the same Go string spelling.
            for index, column in enumerate(definition["columns"]):
                size = wire.add(size, (1 if index else 0) + len(_go_string(column["name"])))
            size = wire.add(size, len(b'],"rows":['))
            row_index = 0
            for length, in self._iter("SELECT length(normalized) FROM state_rows "
                                      "WHERE state_id=? AND name=? ORDER BY key",
                                      (self.state["id"], name)):
                # Each Go marshal(Row) is newline terminated; embedding it
                # in the legacy image omits precisely that one newline.
                wire.need(length >= 3, "V2_REPLAY_NORMALIZED_LENGTH_REFUSED")
                size = wire.add(size, (1 if row_index else 0) + length - 1)
                row_index = wire.add(row_index, 1)
            size = wire.add(size, len(b"]}"))
            table_index = wire.add(table_index, 1)
        return wire.add(size, len(b"}}\n"))

    def _equal_head(self):
        head_id = self._retained(self.header["head"])[0]
        schema = self._one("SELECT schema_id FROM states WHERE id=?", (head_id,))[0]
        root = self._one("SELECT root FROM states WHERE id=?", (head_id,))[0]
        wire.need(schema == self.state["record"]["schema_id"] and
                  root == self.state["record"]["expected_root_sha256"],
                  "V2_REPLAY_HEAD_SCHEMA_MISMATCH")
        # Compare exact row payloads/cells/normalized bytes as well as roots.
        # EXCEPT uses disk-backed SQLite temporary storage, not Python sets.
        for left, right in ((head_id, self.state["id"]), (self.state["id"], head_id)):
            wire.need(self._one(
                "SELECT name, table_schema_id, rows, sha256 FROM state_tables WHERE state_id=? "
                "EXCEPT SELECT name, table_schema_id, rows, sha256 FROM state_tables WHERE state_id=? "
                "LIMIT 1", (left, right)) is None, "V2_REPLAY_HEAD_TABLES_MISMATCH")
            wire.need(self._one(
                "SELECT name, key, payload, normalized FROM state_rows WHERE state_id=? "
                "EXCEPT SELECT name, key, payload, normalized FROM state_rows WHERE state_id=? "
                "LIMIT 1", (left, right)) is None, "V2_REPLAY_HEAD_ROWS_MISMATCH")

    def _end_state(self, record, raw):
        wire.need(self.state is not None and self.table is None and self.state["next"] is None,
                  "V2_REPLAY_STATE_INCOMPLETE")
        state = self.state
        opening, kind = state["record"], state["kind"]
        expected_type = "end_commit" if kind == "commit" else "end_" + kind
        wire.need(record["type"] == expected_type, "V2_REPLAY_STATE_END_KIND_REFUSED")
        if kind == "commit":
            wire.need(record["sequence"] == opening["sequence"] and
                      record["commit_id"] == opening["commit_id"],
                      "V2_REPLAY_COMMIT_END_ID_MISMATCH")
        count = self._one("SELECT count(*) FROM state_tables WHERE state_id=?", (state["id"],))[0]
        root = wire.state_hash(self._state_tables(state["id"]))
        wire.need(record["table_count"] == count and
                  root == record["root_sha256"] == opening["expected_root_sha256"],
                  "V2_REPLAY_STATE_ROOT_OR_COUNT_MISMATCH")
        if kind == "commit":
            self._increment("full_image_bytes", self._legacy_image_size())
            self._increment("commits")
            if self.counts["commits"] == self.header["commit_count"]:
                self.phase = "head-checkpoint"
        elif kind == "head-checkpoint":
            self._equal_head()
            self.head_root, self.phase = root, "current"
        else:
            self.current_root, self.phase = root, "end"
        self._execute("UPDATE states SET root=?, complete=1 WHERE id=?", (root, state["id"]))
        state["union"].close()
        self.state = None
        self.guard()
        self.db.commit()

    def _end(self, record, raw):
        wire.need(self.phase == "end" and self.state is None and self.table is None and
                  record["totals"] == self.counts and
                  record["head_root_sha256"] == self.head_root and
                  record["current_root_sha256"] == self.current_root,
                  "V2_REPLAY_END_TOTALS_OR_ROOTS_MISMATCH")
        # A parent declared absent cannot occur later in the retained graph.
        wire.need(self._one("SELECT 1 FROM missing_edges m JOIN commits c ON c.id=m.parent LIMIT 1")
                  is None, "V2_REPLAY_PARENT_AFTER_CHILD_REFUSED")
        wire.need(self._one("SELECT 1 FROM schemas s WHERE NOT EXISTS "
                            "(SELECT 1 FROM states t WHERE t.schema_id=s.id) LIMIT 1") is None,
                  "V2_REPLAY_UNUSED_SCHEMA_REFUSED")
        # No disconnected retained commits. Recursive UNION deduplicates on
        # disk; the parent-before-child invariant has already excluded cycles.
        reachable = self._one(
            "WITH RECURSIVE reachable(id) AS (SELECT ? UNION "
            "SELECT p.parent FROM parents p JOIN reachable r ON p.child=r.id "
            "JOIN commits c ON c.id=p.parent) SELECT count(*) FROM reachable",
            (self.header["head"],))[0]
        wire.need(reachable == self.counts["commits"], "V2_REPLAY_DISCONNECTED_COMMITS_REFUSED")
        self.phase = "eof"

    def consume(self, capture_set):
        """Exhaust authenticated transport. Return a bounded PARTIAL receipt."""
        wire.need(self.db is not None and not self.started and
                  isinstance(capture_set, wire.CaptureSet) and capture_set.root_fd is not None,
                  "V2_REPLAY_NOT_READY_OR_ALREADY_CONSUMED")
        self.started = True
        handlers = {"header": self._header, "schema": self._schema,
                    "commit": self._commit, "head-checkpoint": self._checkpoint,
                    "current": self._checkpoint, "table": self._table,
                    "drop_table": self._drop, "row": self._row,
                    "end_table": self._end_table, "end_commit": self._end_state,
                    "end_head-checkpoint": self._end_state, "end_current": self._end_state,
                    "end": self._end}
        try:
            for record, raw in capture_set.records():
                self.guard()
                wire.need(self.phase != "eof", "V2_REPLAY_RECORD_AFTER_END_REFUSED")
                handlers[record["type"]](record, raw)
            wire.need(capture_set.transport_verified and self.phase == "eof" and
                      self.counts == capture_set.root["totals"], "V2_REPLAY_TRANSPORT_NOT_COMPLETE")
            self.structural_verified = True
            return {"status": STATUS, "contract": wire.CONTRACT,
                    "capture_set_sha256": capture_set.root_sha256,
                    "totals": dict(self.counts), "head_root_sha256": self.head_root,
                    "current_root_sha256": self.current_root,
                    "transport_verified": True, "publication_authorized": False,
                    "policy_implementation": "PENDING_EXACT_SOURCE_REVIEW",
                    "head_source_evidence_reconciliation": "PENDING",
                    "receiver_accounting_and_import": "NOT_RUN"}
        except wire.Refusal:
            raise
        except (OSError, ValueError, KeyError, TypeError, OverflowError,
                RecursionError, sqlite3.Error):
            raise wire.Refusal("V2_REPLAY_PROCEDURE_FAULT") from None

    def close(self):
        # Owned-path write restoration/removal is inside the same guard.
        # Guard failure leaves the owned scratch available for the caller's
        # separately recorded terminal retention/manual-cleanup path.
        if self.parent_fd is None and self.dir_fd is None and self.db is None:
            return
        if self.db is not None:
            self.guard()
            self.db.set_progress_handler(None, 0)
            self.db.close()
            self.db = None
        try:
            if self.dir_fd is None and self.directory_info is not None:
                self.guard()
                self.dir_fd = os.open(self.name, os.O_RDONLY | os.O_DIRECTORY |
                                      os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=self.parent_fd)
            if self.dir_fd is not None:
                self.guard()
                current = os.stat(self.name, dir_fd=self.parent_fd, follow_symlinks=False)
                wire.need(_same_object(current, self.directory_info) and
                          _same_object(os.fstat(self.dir_fd), self.directory_info),
                          "V2_REPLAY_SCRATCH_CHANGED")
                os.fchmod(self.dir_fd, 0o700)
                with os.scandir(self.dir_fd) as entries:
                    for entry in entries:
                        self.guard()
                        wire.need(entry.name in _FILES, "V2_REPLAY_UNEXPECTED_SCRATCH_ENTRY")
                        fd = os.open(entry.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC |
                                     os.O_NONBLOCK, dir_fd=self.dir_fd)
                        try:
                            info = os.fstat(fd)
                            wire.need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
                                      info.st_uid == os.getuid(), "V2_REPLAY_SCRATCH_FILE_REFUSED")
                            self.guard()
                            os.fchmod(fd, 0o600)
                        finally:
                            os.close(fd)
                        self.guard()
                        os.unlink(entry.name, dir_fd=self.dir_fd)
                self.guard()
                os.rmdir(self.name, dir_fd=self.parent_fd)
        finally:
            for name in ("dir_fd", "parent_fd"):
                fd = getattr(self, name)
                if fd is not None:
                    os.close(fd)
                    setattr(self, name, None)

    def __exit__(self, *_):
        self.close()
