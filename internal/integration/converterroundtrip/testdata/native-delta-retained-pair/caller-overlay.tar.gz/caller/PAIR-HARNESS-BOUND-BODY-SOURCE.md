# Retained pair harness body-encoding and typed-wire successor

AUTHORED_NOT_RUN. This separately named successor resolves the two concrete
PH-D934-F1/F2 expected-body findings and selects the separately supplied de5
reconstruction counter correction. Originald934 and its immutable source
NOT_PASS notea087 remain unchanged; original960 and its historical bounded
review are qualified by the exact-type integer blocker. No pair ran.

The source_identity envelope now emits store_id then project, matching the
actual pinned26e SourceIdentity struct. It continues escaping each string
with the reviewed exact Go encoder. Rows within each NativeTable body now
use disk ORDER BY normalized,key rather than physical key order. The replay's
normalized bytes are canonical Go Row JSON plus one common newline, so this
matches receiver reconstruction's canonical JSON byte sorting. Equal rows
retain multiplicity; key is a deterministic tie break only. Current lease
filtering keeps this order. All original physical typed cells/keys and table
hash calculations remain unchanged. The fixed genuine1a75 config/commit2
order witness in reviewer notea087/1fd4 is acknowledged without executing it.

The selected module name changes from original960 to de5f7593, whose sole
line permits int or wire.JSONInteger through unchanged wire.uint. This fixes
wire-decoder sequence/schema versions reaching the size counter as subclass
values. Row _Number spelling, bool handling, category sites, uint bounds and
one-pass scope are preserved. No receiver production defect is inferred.

The Go persistent inspector3641a787 stays byte-exact, including its complete
bytes.Equal checks and preservation of the original SQLite target. Stable
output paths, all original producer1a75/receiver26e/ELF19bd/setf356 pins,
constructor/default arguments, direct waits, inherited environment and stream
proof extraction remain parent-exact. Full fourteen-category counter source
scope remains partial; eight other categories and operation multiplicity are
pending. No current whole result is a prerequisite for this source correction.

Compose the new small overlay with unchanged base transportd879a0b2 at a fresh
owned root, and use the new manifest hash/size with:
python3 BUNDLE/caller/native_delta_pair_harness_bound_body_v2.py --bundle ABS_ROOT --manifest-sha256 HASH --manifest-bytes N --output ABS_ABSENT_OWNED_DIR

The original PAIR-HARNESS-SOURCE.md remains inherited scope; this additive
scope replaces its helper-selection and key-order statements. Existing ordinary
remote test/data integration remains036-owned, under the existing authorization.
This source delivery adds no gate, worker, collector, ACK or procedure dispatch.
All original overlays/sources/receipts remain preserved. Full business mapping,
numeric/time conformance, actual import/persistent inspection, final procedure
and both1200 cases remain pending; all publication_authorized fields stay false.
Private HARD_DISABLED, item4 PAUSED, c75 STOP_ALL and both R5 NOT_PASS persist.

Validation: standard-library AST parsing, exact three-site source comparison,
Git-object source/hash checks and deterministic transport composition/readback.
No supplied module/function, SQL, fixture, compiler, test, product or ELF was
executed. No collector query, retry, new worker, repository edit or commit.
