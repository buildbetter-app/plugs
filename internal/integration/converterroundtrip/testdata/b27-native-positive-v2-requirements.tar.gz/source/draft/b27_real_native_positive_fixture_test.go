package main_test

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/steveyegge/beads/internal/captureclock"
	"github.com/steveyegge/beads/internal/plugdump"
	"github.com/steveyegge/beads/internal/storage/physicalcapture"
)

// B27's CLI positives use unchanged bd commands. The three declared SQL-only
// families are separately synthetic row-preservation inputs under ROOT16:05.
// The typed physical oracle below is retained from producer 99021f543, before any capture
// runs; it never derives expected cells from the producer or consumer output.
// SQL routes/interactions and legacy issue_snapshots have no native CLI writer.
// No other SQL fixture insert, external summarizer or product/receiver edit is allowed.
func TestB27RealNativePositiveCapture(t *testing.T) {
	// ROOTa3a6d1d6 pins the already-exported landed program. A source-built
	// capture from this child is deliberately never a fallback for this input.
	captureBinary := b27LandedCaptureBinary(t)
	for _, project := range []string{"b27-review", "b27-delivery"} {
		t.Run(project, func(t *testing.T) {
			f := newNativeFixtureForProject(t, project)
			base := os.Getenv("TEST_UNDECLARED_OUTPUTS_DIR")
			if base == "" {
				t.Fatal("canonical artifact directory required")
			}
			r := &b27RealNativeFixture{nativeFixture: f, output: filepath.Join(base, project), captureBinary: captureBinary, milestones: map[string]b27RealNativeMilestone{}}
			r.mkdir(r.output)
			r.populate(project)
			r.pack()
		})
	}
}

const b27LandedCaptureSHA256 = "8ce67aacbad497a4e3acdffa7773b7186faaa7c1efc7a65166fc478f05d16c1e"

func b27LandedCaptureBinary(t *testing.T) string {
	t.Helper()
	path := os.Getenv("B27_LANDED_CAPTURE_BINARY")
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		t.Fatal("B27 requires an explicitly supplied absolute landed85609 capture ELF path")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal("read explicitly supplied landed85609 capture ELF", err)
	}
	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() || info.Mode().Perm()&0111 == 0 || len(data) != 117101352 || fmt.Sprintf("%x", sha256.Sum256(data)) != b27LandedCaptureSHA256 {
		t.Fatal("supplied capture ELF differs from landed85609/export43145983627 pin", err)
	}
	return path
}

type b27RealNativeMilestone struct {
	Head   string                          `json:"commit_id"`
	Tables map[string]plugdump.NativeTable `json:"tables"`
}
type b27RealNativeFixture struct {
	*nativeFixture
	output        string
	captureBinary string
	command       int
	milestones    map[string]b27RealNativeMilestone
}

func (r *b27RealNativeFixture) mkdir(path string) {
	r.t.Helper()
	if err := os.MkdirAll(path, 0700); err != nil {
		r.t.Fatal(err)
	}
}

func (r *b27RealNativeFixture) write(name string, value any) {
	r.t.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		r.t.Fatal(err)
	}
	r.writeBytes(name, append(data, '\n'))
}

func (r *b27RealNativeFixture) writeBytes(name string, data []byte) {
	r.t.Helper()
	path := filepath.Join(r.output, name)
	r.mkdir(filepath.Dir(path))
	if err := os.WriteFile(path, data, 0600); err != nil {
		r.t.Fatal(err)
	}
}

// Retain actual argv, environment selection, stdout, stderr and exit separately.
// Existing nativeFixture/create/step/SQL helpers remain byte-for-byte unchanged.
func (r *b27RealNativeFixture) commandResult(wantSuccess bool, args ...string) []byte {
	return r.recordCommand(r.bd, r.work, r.env, wantSuccess, args...)
}

func (r *b27RealNativeFixture) recordCommand(binary, cwd string, env []string, wantSuccess bool, args ...string) []byte {
	r.t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, args...)
	cmd.Dir, cmd.Env = cwd, env
	var stdout, stderr bytes.Buffer
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	err := cmd.Run()
	exit := 0
	if err != nil {
		exit = -1
		if status, ok := err.(*exec.ExitError); ok {
			exit = status.ExitCode()
		}
	}
	r.command++
	name := fmt.Sprintf("commands/%03d", r.command)
	r.writeBytes(name+".stdout", stdout.Bytes())
	r.writeBytes(name+".stderr", stderr.Bytes())
	selected := map[string]string{}
	for _, entry := range env {
		key, value, _ := strings.Cut(entry, "=")
		switch key {
		case captureclock.FileEnv, captureclock.PublicEnv, "BEADS_DIR", "BEADS_DOLT_DATA_DIR", "BEADS_DOLT_SERVER_HOST", "BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_AUTO_START", "BD_DISABLE_METRICS", "BD_DISABLE_EVENT_FLUSH", "BD_EVENTS_JOURNAL", "TZ", "PATH", "PLUG_PUBLIC_BUNDLE", "B27_LANDED_CAPTURE_BINARY":
			selected[key] = value
		}
	}
	if selected[captureclock.PublicEnv] == "1" {
		data, err := os.ReadFile(selected[captureclock.FileEnv])
		if err != nil {
			r.t.Fatal(err)
		}
		r.writeBytes(name+".clock.json", data)
	}
	r.write(name+".json", map[string]any{"executable": binary, "argv": args, "cwd": cwd, "exit": exit, "selected_public_environment": selected})
	r.t.Logf("RICH_NATIVE_COMMAND index=%d argv=%q exit=%d stdout=%s stderr=%s", r.command, args, exit, stdout.Bytes(), stderr.Bytes())
	if (err == nil) != wantSuccess {
		r.t.Fatalf("actual native command success=%t wanted=%t: %v", err == nil, wantSuccess, err)
	}
	return stdout.Bytes()
}

func (r *b27RealNativeFixture) rawTables() map[string]plugdump.NativeTable {
	r.t.Helper()
	ctx := context.Background()
	source := plugdump.SQLSource{DB: r.db}
	names, err := source.Tables(ctx)
	if err != nil {
		r.t.Fatal(err)
	}
	result := map[string]plugdump.NativeTable{}
	for _, name := range names {
		table, err := source.ReadTable(ctx, name)
		if err != nil {
			r.t.Fatal(err)
		}
		result[name] = canonicalPhysicalCaptureTable(table)
	}
	return result
}

func (r *b27RealNativeFixture) milestone(name string) {
	r.t.Helper()
	log, err := (plugdump.SQLSource{DB: r.db}).ReadSourceCommits(context.Background())
	if err != nil || !log.Clean {
		r.t.Fatalf("actual native milestone %s: clean=%t error=%v", name, log.Clean, err)
	}
	point := b27RealNativeMilestone{Head: log.Head, Tables: r.rawTables()}
	r.milestones[name] = point
	r.write("milestones/"+name+".json", point)
}

func (r *b27RealNativeFixture) populate(project string) {
	r.t.Helper()
	r.write("scope.json", map[string]any{"format": "b27-real-native-positives/2", "scope": "genuine CLI positives plus separately synthetic row preservation", "private": "HARD_DISABLED", "official_actions": 0, "source_built_reference_not_admitted_bundle": true, "SQL_fixture_writes": []string{"routes", "interactions", "issue_snapshots"}, "oracle_origin": "99021f543e57d57b27d7a8d0d6263eafa4d2b4cf"})
	for _, item := range []struct{ name, path string }{{"bd", r.bd}, {"companion", r.companion}} {
		data, err := os.ReadFile(item.path)
		if err != nil {
			r.t.Fatal(err)
		}
		r.write("binaries/"+item.name+".json", map[string]any{"path": item.path, "sha256": fmt.Sprintf("%x", sha256.Sum256(data)), "bytes": len(data)})
	}
	t0 := time.Date(2026, 11, 12, 12, 0, 0, 0, time.UTC)
	step := func(name string, n int) {
		now := t0.Add(time.Duration(n) * time.Second)
		r.step(name, now, now.Add(10*time.Second))
		r.sqlClock(now.Add(10 * time.Second))
	}
	step("b27-native-config", 0)
	r.commandResult(true, "--help")
	r.commandResult(true, "audit", "--help")
	r.commandResult(true, "provenance", "--help")
	r.commandResult(true, "compact", "--help")
	r.commandResult(false, "route", "--help")
	r.commandResult(false, "snapshot", "--help")
	r.commandResult(true, "config", "set", "types.custom", "b27_kind,unused_b27_kind", "--json")
	r.commandResult(true, "config", "set", "status.custom", "b27_ready:active,b27_review:wip,b27_done:done,b27_frozen:frozen", "--json")
	r.commandResult(true, "config", "set", "custom.b27_public", "literal 雪 /~ and spaces", "--json")
	r.commandResult(true, "config", "set", "no-push", "true", "--json")
	r.commandResult(true, "config", "set", "audit.enabled", "true", "--json")
	r.commandResult(true, "config", "get", "custom.b27_public", "--json")
	r.milestone("configured")
	create := func(title string, args ...string) string {
		var row struct {
			ID string `json:"id"`
		}
		if err := json.Unmarshal(r.commandResult(true, append([]string{"create", title, "--json"}, args...)...), &row); err != nil || row.ID == "" {
			r.t.Fatal("real native create identity", err)
		}
		return row.ID
	}
	step("b27-native-relations", 1)
	parent := create("B27 public parent 雪", "--id", project+"-a1b", "--type", "b27_kind", "--status", "b27_ready", "--description", "description α\nsecond line", "--design", "design β", "--notes", "notes γ", "--acceptance", "acceptance δ", "--labels", "alpha,shared", "--metadata", `{"nullable":null,"integer":9007199254740993,"nested":{"literal.dot/~":"雪"},"boolean":false}`)
	child := create("B27 public durable child", "--parent", parent, "--no-inherit-labels", "--labels", "child")
	peer := create("B27 public relation peer", "--id", project+"-c2d", "--status", "b27_review", "--labels", "shared")
	active := create("B27 public active parent", "--id", project+"-e4f", "--ephemeral", "--labels", "active")
	activeChild := create("B27 public active child", "--parent", active, "--ephemeral")
	closed := create("B27 public stays closed", "--id", project+"-f5a", "--description", "public close content", "--notes", "public close note")
	if parent != project+"-a1b" || child != parent+".1" || active != project+"-e4f" || activeChild != active+".1" {
		r.t.Fatal("independent native IDs/counters differ")
	}
	r.commandResult(true, "comments", "add", parent, "durable comment 雪\nexact", "--author", "b27-public", "--json")
	r.commandResult(true, "comments", "add", active, "active comment λ\nexact", "--author", "b27-public", "--json")
	r.commandResult(true, "dep", "add", peer, parent, "--type", "related", "--json")
	r.commandResult(true, "dep", "add", activeChild, peer, "--type", "related", "--json")
	r.milestone("relational")
	step("b27-native-provenance", 2)
	provArgs := []string{"provenance", "record", "--issue", closed, "--kind", "commit", "--source", "b27-public-native", "--actor", "public-fixture", "--ref", "0123456789abcdef0123456789abcdef01234567", "--ref-kind", "git-sha", "--at", "2026-11-12T12:00:02Z", "--payload", `{"public":true,"literal":"雪","n":9007199254740993}`, "--json"}
	var recorded struct {
		ID       string `json:"id"`
		Inserted bool   `json:"inserted"`
	}
	if err := json.Unmarshal(r.commandResult(true, provArgs...), &recorded); err != nil || recorded.ID == "" || !recorded.Inserted {
		r.t.Fatal("real provenance append", err)
	}
	beforeDuplicate := r.rawTables()
	var duplicate struct {
		ID       string `json:"id"`
		Inserted bool   `json:"inserted"`
	}
	if err := json.Unmarshal(r.commandResult(true, provArgs...), &duplicate); err != nil || duplicate.ID != recorded.ID || duplicate.Inserted || !equalPhysicalCaptureJSON(beforeDuplicate, r.rawTables()) {
		r.t.Fatal("native provenance idempotency differs", err)
	}
	r.commandResult(true, "provenance", "log", closed, "--json")
	r.commandResult(true, "provenance", "by-ref", "0123456789abcdef0123456789abcdef01234567", "--json")
	r.milestone("provenance")
	step("b27-native-current-close", 3)
	const closeReason = "B27 native current close 雪\nexact reason"
	r.commandResult(true, "close", closed, "--reason", closeReason, "--json")
	r.commandResult(true, "show", closed, "--json")
	r.milestone("closed-current")
	step("b27-native-audit-sidecar", 4)
	auditPath := filepath.Join(r.work, ".beads", "interactions.jsonl")
	auditBefore, err := os.ReadFile(auditPath)
	if err != nil {
		r.t.Fatal(err)
	}
	r.writeBytes("audit-before-explicit.jsonl", auditBefore)
	var audit struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(r.commandResult(true, "audit", "record", "--kind", "tool_call", "--issue-id", closed, "--tool-name", "public-b27-control", "--exit-code", "0", "--json"), &audit); err != nil || audit.ID == "" {
		r.t.Fatal("native JSONL audit not emitted", err)
	}
	var auditLabel struct {
		ID       string `json:"id"`
		ParentID string `json:"parent_id"`
		Label    string `json:"label"`
	}
	if err := json.Unmarshal(r.commandResult(true, "audit", "label", audit.ID, "--label", "good", "--reason", "public independent native control", "--json"), &auditLabel); err != nil || auditLabel.ID == "" || auditLabel.ParentID != audit.ID || auditLabel.Label != "good" {
		r.t.Fatal("native label append identity differs", err)
	}
	auditBytes, err := os.ReadFile(auditPath)
	if err != nil {
		r.t.Fatal(err)
	}
	r.writeBytes("audit-original.jsonl", auditBytes)
	// Close already appends its status-change entry. Preserve that exact
	// prefix and require precisely the two later explicit CLI appends.
	if !bytes.HasPrefix(auditBytes, auditBefore) {
		r.t.Fatal("native audit append changed original prefix")
	}
	decodeAudit := func(data []byte) []map[string]any {
		decoder := json.NewDecoder(bytes.NewReader(data))
		decoder.UseNumber()
		var rows []map[string]any
		for {
			var row map[string]any
			err := decoder.Decode(&row)
			if err == io.EOF {
				return rows
			}
			if err != nil {
				r.t.Fatal(err)
			}
			rows = append(rows, row)
		}
	}
	auditPrefix := decodeAudit(auditBefore)
	closeEntries := 0
	for _, entry := range auditPrefix {
		extra, _ := entry["extra"].(map[string]any)
		if entry["kind"] == "field_change" && entry["issue_id"] == closed && extra["field"] == "status" && extra["old_value"] == "open" && extra["new_value"] == "closed" && extra["reason"] == closeReason {
			closeEntries++
		}
	}
	if closeEntries != 1 {
		r.t.Fatal("native close audit status/reason entry differs", closeEntries)
	}
	auditAppends := decodeAudit(auditBytes[len(auditBefore):])
	if len(auditAppends) != 2 || auditAppends[0]["id"] != audit.ID || auditAppends[0]["kind"] != "tool_call" || auditAppends[0]["issue_id"] != closed || auditAppends[0]["tool_name"] != "public-b27-control" || fmt.Sprint(auditAppends[0]["exit_code"]) != "0" || auditAppends[1]["id"] != auditLabel.ID || auditAppends[1]["kind"] != "label" || auditAppends[1]["parent_id"] != audit.ID || auditAppends[1]["label"] != "good" || auditAppends[1]["reason"] != "public independent native control" {
		r.t.Fatal("native JSONL readback differs")
	}
	auditEntries := append(auditPrefix, auditAppends...)
	r.write("audit-append-conservation.json", map[string]any{"original_prefix_bytes": len(auditBefore), "original_prefix_sha256": fmt.Sprintf("%x", sha256.Sum256(auditBefore)), "prefix_byte_exact": true, "explicit_appended_entries": 2, "close_status_entries": closeEntries, "all_entries": len(auditEntries)})
	r.milestone("cli-only-before-synthetic")
	r.seedDeclaredPublicRows(project, closed)
	r.milestone("final")
	current := r.rawTables()
	closedCount, provCount := 0, 0
	for _, row := range current["issues"].Rows {
		if row["id"] == closed {
			closedCount++
			if row["status"] != "closed" || row["close_reason"] != closeReason || row["closed_at"] == nil {
				r.t.Fatal("independent current native close fields differ")
			}
		}
	}
	for _, row := range current["provenance_events"].Rows {
		if row["id"] == recorded.ID {
			provCount++
			if row["issue_id"] != closed || row["kind"] != "commit" || row["source"] != "b27-public-native" || row["ref"] != "0123456789abcdef0123456789abcdef01234567" {
				r.t.Fatal("independent native provenance SQL fields differ")
			}
		}
	}
	if closedCount != 1 || provCount != 1 {
		r.t.Fatal("required current close/provenance missing")
	}
	for _, family := range []string{"issues", "dependencies", "labels", "comments", "events", "child_counters", "wisps", "wisp_dependencies", "wisp_labels", "wisp_comments", "wisp_events", "wisp_child_counters", "provenance_events", "config"} {
		if len(current[family].Rows) == 0 {
			r.t.Fatal("required real native current family empty", family)
		}
	}
	for family, parentID := range map[string]string{"child_counters": parent, "wisp_child_counters": active} {
		found := 0
		for _, row := range current[family].Rows {
			if row["parent_id"] == parentID {
				found++
				if fmt.Sprint(row["last_child"]) != "1" {
					r.t.Fatal("independent original SQL counter differs", family)
				}
			}
		}
		if found != 1 {
			r.t.Fatal("independent SQL parent counter multiplicity differs", family)
		}
	}
	r.write("independent-expectations.json", map[string]any{"project": project, "parent": parent, "child": child, "active_parent": active, "active_child": activeChild, "parent_counter": 1, "active_parent_counter": 1, "closed_id": closed, "close_reason": closeReason, "closed_status": "closed", "provenance_id": recorded.ID, "provenance_ref": "0123456789abcdef0123456789abcdef01234567", "audit_entry_id": audit.ID, "audit_entries": auditEntries, "expected_source": "literal CLI inputs and independent SQL/physical reads, never reconstructed output"})
	r.write("named-differences.json", map[string]any{"format": "b27-native-named-differences/2", "code": "NAMED_DIFFERENCE(native_rows_without_cli_writer)", "accepted_text": "routes, interactions and issue_snapshots rows cannot be produced by the native CLI in a hermetic test; snapshots additionally require an external summarizer.", "authority": "ROOT2d9746af; escalations2026-11-12T16:05Z", "synthetic_tables": []string{"routes", "interactions", "issue_snapshots"}, "qualification": "row preservation, not native CLI behavior", "compaction_snapshots": "no external summarization; no synthetic permission for this separate family"})
	r.capture(project)
}

func (r *b27RealNativeFixture) seedDeclaredPublicRows(project, closed string) {
	r.t.Helper()
	before := r.rawTables()
	for _, family := range []string{"routes", "interactions", "issue_snapshots"} {
		if len(before[family].Rows) != 0 {
			r.t.Fatal("CLI-only source unexpectedly populated SQL-only family", family)
		}
	}
	stamp := "2026-11-12 12:00:05"
	routePrefix := project + "-route"
	interactionID := project + "-sql-int"
	seedHash := fmt.Sprintf("%x", sha256.Sum256([]byte(project+"/synthetic-issue-snapshot")))
	snapshotID := seedHash[:8] + "-" + seedHash[8:12] + "-" + seedHash[12:16] + "-" + seedHash[16:20] + "-" + seedHash[20:32]
	content := "synthetic original content 雪\nexact source text"
	type statement struct {
		Table string `json:"table"`
		SQL   string `json:"sql"`
		Args  []any  `json:"args"`
	}
	statements := []statement{
		{"routes", "INSERT INTO routes(prefix,path,created_at,updated_at) VALUES (?,?,?,?)", []any{routePrefix, "/public/disposable/" + project + "/雪", stamp, stamp}},
		{"interactions", "INSERT INTO interactions(id,kind,created_at,actor,issue_id,model,prompt,response,error,tool_name,exit_code,parent_id,label,reason,extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", []any{interactionID, "tool_call", stamp, "public-sql-seed", closed, nil, "synthetic prompt 雪\nexact", "synthetic response λ\nexact", nil, "public-synthetic", -7, nil, "row-preservation-only", "SQL-synthetic; no native CLI emitter", `{"synthetic_sql_seed":true,"integer":17,"literal":"雪","nullable":null}`}},
		{"issue_snapshots", "INSERT INTO issue_snapshots(id,issue_id,snapshot_time,compaction_level,original_size,compressed_size,original_content,archived_events) VALUES (?,?,?,?,?,?,?,?)", []any{snapshotID, closed, stamp, 1, len(content), 0, content, nil}},
	}
	r.write("synthetic-sql-seed/declared-inputs.json", map[string]any{"format": "b27-declared-synthetic-native-rows/1", "authority": "ROOT2d9746af; escalations2026-11-12T16:05Z", "origin": "SQL-synthetic in disposable PUBLIC native store", "qualified_as": "row preservation, not native CLI behavior", "no_other_families_authorized": true, "statements": statements, "all_values_declared": true, "no_CLI_receipt_for_SQL_seed": true})
	r.write("synthetic-sql-seed/before.json", before)
	tx, err := r.db.BeginTx(context.Background(), nil)
	if err != nil {
		r.t.Fatal(err)
	}
	defer func() { _ = tx.Rollback() }() // An error never leaves an uncommitted seed behind.
	for _, item := range statements {
		result, err := tx.ExecContext(context.Background(), item.SQL, item.Args...)
		if err != nil {
			r.t.Fatal("public declared SQL-only row seed", item.Table, err)
		}
		count, err := result.RowsAffected()
		if err != nil || count != 1 {
			r.t.Fatal("declared synthetic row count", item.Table, count, err)
		}
	}
	if err := tx.Commit(); err != nil {
		r.t.Fatal(err)
	}
	after := r.rawTables()
	seeded := map[string]bool{"routes": true, "interactions": true, "issue_snapshots": true}
	for family, table := range before {
		if seeded[family] {
			if len(after[family].Rows) != 1 {
				r.t.Fatal("synthetic SQL row multiplicity", family)
			}
			continue
		}
		if !equalPhysicalCaptureJSON(table, after[family]) {
			r.t.Fatal("synthetic seed changed an unpermitted family", family)
		}
	}
	if len(before) != len(after) {
		r.t.Fatal("synthetic seed changed native table schema set")
	}
	if row := after["routes"].Rows[0]; row["prefix"] != routePrefix || row["path"] != "/public/disposable/"+project+"/雪" {
		r.t.Fatal("synthetic route source readback differs")
	}
	if row := after["interactions"].Rows[0]; row["id"] != interactionID || row["issue_id"] != closed || fmt.Sprint(row["exit_code"]) != "-7" || row["model"] != nil || row["error"] != nil || row["parent_id"] != nil {
		r.t.Fatal("synthetic interaction original fields/types differ")
	}
	if row := after["issue_snapshots"].Rows[0]; row["id"] != snapshotID || row["issue_id"] != closed || row["original_content"] != content || row["archived_events"] != nil || fmt.Sprint(row["original_size"]) != fmt.Sprint(len(content)) {
		r.t.Fatal("synthetic snapshot original fields/types differ")
	}
	r.write("synthetic-sql-seed/readback.json", map[string]any{"all_original_tables": after, "only_changed_families": []string{"routes", "interactions", "issue_snapshots"}, "row_count_each": 1, "lexical_and_SQL_type_oracle": "later independent typed-current.json/physical-current-schema.json/typed-history; captured before producer execution", "native_cli_behavior_credit": false})
	// Only the normal CLI commits these declared public rows to real Dolt
	// history. This receipt is a commit receipt, not a CLI row-emission claim.
	r.commandResult(true, "dolt", "commit", "--message", "B27 declared SQL-synthetic row-preservation inputs")
	r.write("synthetic-sql-seed/origin.json", map[string]any{"tables": []string{"routes", "interactions", "issue_snapshots"}, "disposable_public": true, "origin": "synthetic SQL", "row_preservation_only": true, "route_execution": false, "interaction_execution": false, "compaction_execution": false})
}

func (r *b27RealNativeFixture) pack() {
	files := fingerprintPublicCapture(r.t, r.output, "")
	// Export the ELF separately. The released input itself contains only the
	// actual native capture, independent physical oracle and command originals.
	delete(files, "native-physical-capture")
	r.write("INNER-HASHES.json", files)
	names := []string{"INNER-HASHES.json"}
	for name := range files {
		names = append(names, name)
	}
	sort.Strings(names)
	path := filepath.Join(filepath.Dir(r.output), filepath.Base(r.output)+"-real-native-input.tar.gz")
	file, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		r.t.Fatal(err)
	}
	zip := gzip.NewWriter(file)
	writer := tar.NewWriter(zip)
	for _, name := range names {
		data, err := os.ReadFile(filepath.Join(r.output, name))
		if err != nil {
			r.t.Fatal(err)
		}
		if err := writer.WriteHeader(&tar.Header{Name: "native-source/" + filepath.ToSlash(name), Mode: 0600, Size: int64(len(data)), Typeflag: tar.TypeReg}); err != nil {
			r.t.Fatal(err)
		}
		if _, err := writer.Write(data); err != nil {
			r.t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		r.t.Fatal(err)
	}
	if err := zip.Close(); err != nil {
		r.t.Fatal(err)
	}
	if err := file.Close(); err != nil {
		r.t.Fatal(err)
	}
	data, err := os.ReadFile(path)
	if err != nil || len(data) > 20*1024*1024 {
		r.t.Fatal("released public input exceeds 20MiB", err)
	}
	r.t.Logf("B27_REAL_NATIVE_INPUT path=%s sha256=%x bytes=%d members=%d", path, sha256.Sum256(data), len(data), len(names))
}

func (r *b27RealNativeFixture) capture(project string) {
	r.t.Helper()
	source := plugdump.SQLSource{DB: r.db}
	log, err := source.ReadSourceCommits(context.Background())
	if err != nil || !log.Clean {
		r.t.Fatalf("source graph before capture: %+v %v", log, err)
	}
	current := r.rawTables()
	r.write("raw-current.json", current)
	r.write("source-commits.json", log)
	dataDir := ""
	for _, entry := range r.env {
		if value, ok := strings.CutPrefix(entry, "BEADS_DOLT_DATA_DIR="); ok {
			dataDir = value
		}
	}
	if dataDir == "" {
		r.t.Fatal("exact native data directory missing")
	}
	copyDir := privateDir(r.t)
	before := fingerprintPublicCapture(r.t, filepath.Join(dataDir, "capture"), filepath.Join(copyDir, "capture"))
	if !reflect.DeepEqual(before, fingerprintPublicCapture(r.t, filepath.Join(dataDir, "capture"), "")) || !reflect.DeepEqual(before, fingerprintPublicCapture(r.t, filepath.Join(copyDir, "capture"), "")) {
		r.t.Fatal("quiescent native source/copy fingerprint differs")
	}
	workspace := privateDir(r.t)
	beadsDir := filepath.Join(workspace, ".beads")
	beadsBefore := fingerprintPublicCapture(r.t, filepath.Join(r.work, ".beads"), beadsDir)
	if !reflect.DeepEqual(beadsBefore, fingerprintPublicCapture(r.t, filepath.Join(r.work, ".beads"), "")) || !reflect.DeepEqual(beadsBefore, fingerprintPublicCapture(r.t, beadsDir, "")) {
		r.t.Fatal("quiescent native workspace/copy fingerprint differs")
	}
	r.write("source-files.json", map[string]any{"database": before, "beads": beadsBefore})
	db, closeDriver, err := physicalcapture.Open(copyDir, "capture")
	if err != nil {
		r.t.Fatal(err)
	}
	conn, err := db.Conn(context.Background())
	if err != nil {
		r.t.Fatal(err)
	}
	working, err := physicalcapture.ReadWorkingRoot(context.Background(), conn, log.Head)
	if err != nil || !working.ReadOnlyScope || !working.Complete || working.HeadCommitID != log.Head {
		r.t.Fatalf("independent typed current-root observation: %+v %v", working, err)
	}
	typed, err := physicalcapture.EvidenceTables(working.Tables)
	if err != nil {
		r.t.Fatal(err)
	}
	r.write("typed-current.json", typed)
	currentSchema := map[string][]physicalcapture.Column{}
	for _, table := range working.Tables {
		currentSchema[table.Name] = table.Columns
	}
	r.write("physical-current-schema.json", currentSchema)
	r.write("physical-current-identity.json", map[string]any{"format": working.Format, "database": working.Database, "head_commit_id": working.HeadCommitID, "working_root_hash": working.WorkingRootHash, "read_only_scope": working.ReadOnlyScope, "complete": working.Complete})
	history, err := physicalcapture.ReadHistory(context.Background(), conn, log.Head)
	if err != nil || !history.ReadOnlyScope || len(history.Boundaries) != 0 {
		r.t.Fatalf("independent physical graph: %+v %v", history, err)
	}
	r.write("physical-history.json", history)
	policy := map[string]string{}
	for _, family := range []string{"config", "metadata"} {
		for _, row := range current[family].Rows {
			policy[family+"/"+fmt.Sprint(row["key"])] = "public"
		}
	}
	storeID := fmt.Sprintf("native/%x", sha256.Sum256([]byte(filepath.Join(copyDir, "capture"))))
	oracle := b27RealNativeOracle{fixture: r, project: project, storeID: storeID, policy: policy}
	byID := map[string]physicalcapture.HistoryCommit{}
	for _, commit := range history.Commits {
		byID[commit.ID] = commit
	}
	ordered := []string{}
	seen := map[string]bool{}
	var visit func(string)
	visit = func(id string) {
		if seen[id] {
			return
		}
		commit, ok := byID[id]
		if !ok {
			r.t.Fatal("independent physical parent missing")
		}
		parents := append([]string{}, commit.Parents...)
		sort.Strings(parents)
		for _, parent := range parents {
			visit(parent)
		}
		seen[id] = true
		ordered = append(ordered, id)
	}
	visit(log.Head)
	if len(ordered) != len(history.Commits) {
		r.t.Fatal("independent physical graph contains unreachable commits")
	}
	var head physicalcapture.Image
	for i, id := range ordered {
		image, err := physicalcapture.ReadCommit(context.Background(), conn, id)
		if err != nil || !image.ReadOnlyScope || image.CommitID != id {
			r.t.Fatalf("independent immutable source image: %v", err)
		}
		tables, err := physicalcapture.EvidenceTables(image.Tables)
		if err != nil {
			r.t.Fatal(err)
		}
		r.write("typed-history/"+id+".json", physicalcapture.EvidenceImage{CommitID: id, ReadOnlyScope: true, Tables: tables})
		schema := map[string][]physicalcapture.Column{}
		for _, table := range image.Tables {
			schema[table.Name] = table.Columns
		}
		r.write("typed-history/"+id+".schema.json", map[string]any{"commit_id": image.CommitID, "read_only_scope": image.ReadOnlyScope, "tables": schema})
		oracle.state("commit", uint64(i+1), id, image.Tables, nil)
		if id == log.Head {
			head = image
		}
	}
	headRoot := oracle.state("head-checkpoint", 0, log.Head, head.Tables, nil)
	currentRoot := oracle.state("current", 0, log.Head, working.Tables, head.Tables)
	r.writeBytes("oracle/tables.ndjson", oracle.tables.Bytes())
	r.writeBytes("oracle/states.ndjson", oracle.states.Bytes())
	for _, closer := range []func() error{conn.Close, db.Close, closeDriver} {
		if err := closer(); err != nil {
			r.t.Fatal(err)
		}
	}
	binary := r.captureBinary
	binaryBytes, err := os.ReadFile(binary)
	if err != nil {
		r.t.Fatal(err)
	}
	binaryInfo, err := os.Stat(binary)
	if err != nil {
		r.t.Fatal(err)
	}
	if len(binaryBytes) != 117101352 || fmt.Sprintf("%x", sha256.Sum256(binaryBytes)) != b27LandedCaptureSHA256 {
		r.t.Fatal("landed capture executable changed after initial pin verification")
	}
	r.write("binary.json", map[string]any{"path": binary, "sha256": fmt.Sprintf("%x", sha256.Sum256(binaryBytes)), "bytes": len(binaryBytes), "mode": fmt.Sprintf("%04o", binaryInfo.Mode().Perm()), "source_commit": "85609b64d846cfb48eb9b3a6cdef8c4edc964935", "source_tree": "1c3e8d956fe943b508c7244c1b5551bc16555892", "export_run": "43145983627", "export_review_seal_sha256": "84a145ec4870d089191afef2d1a853507d9aa28d7a2309cd7c378750869093fa", "root_authority": "ROOTa3a6d1d6", "source_built_capture_used": false})
	if project == "b27-review" {
		r.writeBytes("native-physical-capture", binaryBytes)
	}
	output := privateDir(r.t)
	toolFixture := *r.nativeFixture
	toolFixture.work, toolFixture.env = workspace, nil
	for _, entry := range r.env {
		key, _, _ := strings.Cut(entry, "=")
		if key != captureclock.FileEnv && key != captureclock.PublicEnv && key != "BEADS_DIR" && key != "BEADS_DOLT_DATA_DIR" {
			toolFixture.env = append(toolFixture.env, entry)
		}
	}
	toolFixture.env = append(toolFixture.env, "BEADS_DIR="+beadsDir, "BEADS_DOLT_DATA_DIR="+copyDir)
	argv := []string{"--disposable", "--data-dir", copyDir, "--database", "capture", "--beads-dir", beadsDir, "--output-dir", output, "--native-delta"}
	r.write("capture-command.json", map[string]any{"executable": binary, "argv": argv, "cwd": workspace, "BEADS_DIR": beadsDir})
	r.recordCommand(binary, workspace, toolFixture.env, true, argv...)
	fingerprintPublicCapture(r.t, output, filepath.Join(r.output, "capture"))
	setBytes, err := os.ReadFile(filepath.Join(output, "capture-set", "capture-set.json"))
	if err != nil {
		r.t.Fatal(err)
	}
	var set plugdump.NativeCaptureSet
	if err := json.Unmarshal(setBytes, &set); err != nil || set.Head != log.Head || set.StoreID != storeID || !reflect.DeepEqual(set.Projects, []string{project}) || set.Totals.Commits != uint64(len(history.Commits)) {
		r.t.Fatalf("actual producer set identity/graph: %+v %v", set, err)
	}
	evidenceBytes, err := os.ReadFile(filepath.Join(output, "physical-evidence.json"))
	if err != nil {
		r.t.Fatal(err)
	}
	var producedEvidence plugdump.NativeDeltaEvidence
	if err := json.Unmarshal(evidenceBytes, &producedEvidence); err != nil || producedEvidence.HeadRootSHA256 != headRoot || producedEvidence.CurrentRootSHA256 != currentRoot || producedEvidence.CaptureSetSHA256 != fmt.Sprintf("%x", sha256.Sum256(setBytes)) {
		r.t.Fatalf("producer differs from independently observed physical roots: %+v %v", producedEvidence, err)
	}
	headBytes, err := os.ReadFile(filepath.Join(output, "capture-set", "head.tar"))
	if err != nil || set.HeadArchive.SHA256 != fmt.Sprintf("%x", sha256.Sum256(headBytes)) || set.HeadArchive.Size != int64(len(headBytes)) {
		r.t.Fatal("published head bytes differ from root commitment", err)
	}
	manifest, err := plugdump.ValidateNativeDeltaHead(bytes.NewReader(headBytes))
	if err != nil || manifest.StoreID != storeID {
		r.t.Fatal("native delta head validation", err)
	}
	invBytes, err := os.ReadFile(filepath.Join(output, "inventory.json"))
	if err != nil {
		r.t.Fatal(err)
	}
	inventory, err := plugdump.ReadInventory(bytes.NewReader(invBytes))
	if err != nil || len(inventory.Projects) != 1 || inventory.Projects[0].Prefix != project || !reflect.DeepEqual(inventory.ConfigPolicy, policy) {
		r.t.Fatalf("actual separate native source identity: %+v %v", inventory.Projects, err)
	}
	if !equalPhysicalCaptureJSON(current, r.rawTables()) {
		r.t.Fatal("capture changed original native rows")
	}
	r.write("identity.json", map[string]any{"store_id": set.StoreID, "project": project, "source_head": log.Head, "projects": inventory.Projects, "capture_set_sha256": fmt.Sprintf("%x", sha256.Sum256(setBytes)), "milestones": r.milestones})
	census := map[string]any{}
	for family, table := range current {
		census[family] = map[string]any{"present": true, "rows": len(table.Rows), "columns": table.Columns}
	}
	files := map[string]any{}
	for _, name := range []string{"routes.jsonl", "interactions.jsonl", "issues.jsonl", "config.yaml", "metadata.json"} {
		data, err := os.ReadFile(filepath.Join(r.work, ".beads", name))
		if os.IsNotExist(err) {
			files[name] = map[string]any{"present": false, "disposition": "source-observed absence; not a zero-row SQL alias"}
			continue
		}
		if err != nil {
			r.t.Fatal(err)
		}
		r.writeBytes("filesystem/"+name, data)
		files[name] = map[string]any{"present": true, "bytes": len(data), "sha256": fmt.Sprintf("%x", sha256.Sum256(data))}
	}
	r.write("census.json", map[string]any{"sql": census, "filesystem": files, "native_dispositions": manifest.Sources, "contract": plugdump.SourceFamilyContract, "source_sql_synthetic_tables": []string{"routes", "interactions", "issue_snapshots"}, "source_cli_positive_families": []string{"issues/close", "provenance_events", "relations", "config", "audit-jsonl"}, "consumer_disposition": "receiver/card-owned; native retention is not consumer runtime credit"})
	finalLog, err := source.ReadSourceCommits(context.Background())
	if err != nil || !reflect.DeepEqual(log, finalLog) {
		r.t.Fatal("capture changed original native history", err)
	}
	r.write("conservation.json", map[string]any{"before": log, "after": finalLog, "SQL_tables_equal": true, "independent_head_root": headRoot, "independent_current_root": currentRoot})
	r.t.Logf("PUBLIC_NATIVE_RICH_RELATIONS_CAPTURE project=%s store_id=%s source_head=%s immutable_images=%d current_families=%d", project, set.StoreID, log.Head, len(history.Commits), len(current))
}

// The oracle consumes original detached cells, before either producer format.
// Framing below is independently implemented from native_delta_wire.go's v2
// contract. No producer mapper, reconstructed table or receiver supplies a value.
type b27RealNativeOracle struct {
	fixture          *b27RealNativeFixture
	project, storeID string
	policy           map[string]string
	tables, states   bytes.Buffer
}

func (o *b27RealNativeOracle) state(kind string, sequence uint64, commitID string, tables, head []physicalcapture.Table) string {
	o.fixture.t.Helper()
	digests := map[string]plugdump.NativeDeltaTableDigest{}
	headNames := map[string]bool{}
	for _, table := range head {
		headNames[table.Name] = true
	}
	ordered := append([]physicalcapture.Table{}, tables...)
	sort.Slice(ordered, func(i, j int) bool { return ordered[i].Name < ordered[j].Name })
	for _, table := range ordered {
		history := "retained-native-commit"
		if kind == "current" && !headNames[table.Name] {
			history = plugdump.FamilyUnversioned
		}
		schema := plugdump.NativeDeltaTableSchema{Name: table.Name, Columns: []plugdump.NativeDeltaColumn{}}
		columns := []string{}
		for _, column := range table.Columns {
			columns = append(columns, column.Name)
			schema.Columns = append(schema.Columns, plugdump.NativeDeltaColumn{Name: column.Name, SQLType: column.DatabaseTypeName, PrimaryKeyOrdinal: column.PrimaryKeyOrdinal})
		}
		evidence, err := physicalcapture.EvidenceTables([]physicalcapture.Table{table})
		if err != nil {
			o.fixture.t.Fatal(err)
		}
		normalized := []plugdump.Row{}
		physicalRows := []plugdump.NativeDeltaRow{}
		multiplicities := map[string]uint64{}
		for rowIndex, values := range table.Rows {
			row := plugdump.Row{}
			for i, value := range values {
				row[table.Columns[i].Name] = o.value(value, table.Columns[i].DatabaseTypeName)
			}
			cells := make([]plugdump.NativeDeltaCell, len(values))
			for i, value := range evidence[0].Rows[rowIndex] {
				cells[i] = plugdump.NativeDeltaCell{Kind: value.Kind, Value: value.Value}
			}
			normalBytes, err := json.Marshal(row)
			if err != nil {
				o.fixture.t.Fatal(err)
			}
			// Physical v2 row payload binds plugdump's newline-terminated
			// normalized record, unlike the no-LF .table.json envelope.
			normalBytes = append(normalBytes, '\n')
			key := o.primaryKey(schema, cells)
			if key == nil {
				payload := b27RealRowPayload(cells, normalBytes)
				group := fmt.Sprintf("%x", sha256.Sum256(payload))
				var encoded bytes.Buffer
				encoded.WriteString("bag\x00")
				digest := sha256.Sum256(payload)
				encoded.Write(digest[:])
				b27RealU(&encoded, multiplicities[group])
				key = encoded.Bytes()
				multiplicities[group]++
			}
			physicalRows = append(physicalRows, plugdump.NativeDeltaRow{Key: base64.StdEncoding.EncodeToString(key), Cells: cells, NormalizedJSON: base64.StdEncoding.EncodeToString(normalBytes)})
			normalized = append(normalized, row)
		}
		sort.Slice(physicalRows, func(i, j int) bool {
			a, _ := base64.StdEncoding.DecodeString(physicalRows[i].Key)
			b, _ := base64.StdEncoding.DecodeString(physicalRows[j].Key)
			return bytes.Compare(a, b) < 0
		})
		physicalHash := o.tableHash(schema, physicalRows)
		digests[table.Name] = plugdump.NativeDeltaTableDigest{Rows: uint64(len(table.Rows)), SHA256: physicalHash}
		sort.Strings(columns)
		// The b1c source NativeTable contract (native_history.go:167) sorts
		// normalized row JSON. PK/bag order above is a distinct physical order.
		sort.Slice(normalized, func(i, j int) bool {
			a, _ := json.Marshal(normalized[i])
			b, _ := json.Marshal(normalized[j])
			return bytes.Compare(a, b) < 0
		})
		envelope := struct {
			SourceIdentity struct {
				StoreID string `json:"store_id"`
				Project string `json:"project"`
			} `json:"source_identity"`
			Table   string         `json:"table"`
			History string         `json:"history"`
			Columns []string       `json:"columns"`
			Rows    []plugdump.Row `json:"rows"`
		}{Table: table.Name, History: history, Columns: columns, Rows: normalized}
		envelope.SourceIdentity.StoreID, envelope.SourceIdentity.Project = o.storeID, o.project
		data, err := json.Marshal(envelope)
		if err != nil {
			o.fixture.t.Fatal(err)
		}
		hash := fmt.Sprintf("%x", sha256.Sum256(data))
		name := hash + ".table.json"
		o.fixture.writeBytes("oracle/"+name, data)
		entry := map[string]any{"kind": kind, "sequence": sequence, "commit_id": commitID, "family": table.Name, "history": history, "file": name, "sha256": hash, "bytes": len(data), "source_rows": len(table.Rows), "imported_rows": len(table.Rows), "schema_id": b27RealSchemaID(schema), "physical_sha256": physicalHash, "config_policy": o.policy}
		if err := json.NewEncoder(&o.tables).Encode(entry); err != nil {
			o.fixture.t.Fatal(err)
		}
	}
	var rootBytes bytes.Buffer
	for _, table := range ordered {
		digest := digests[table.Name]
		b27RealB(&rootBytes, []byte(table.Name))
		raw, err := hex.DecodeString(digest.SHA256)
		if err != nil {
			o.fixture.t.Fatal(err)
		}
		rootBytes.Write(raw)
		b27RealU(&rootBytes, digest.Rows)
	}
	root := b27RealDigest("beads-native-commit/2", rootBytes.Bytes())
	if err := json.NewEncoder(&o.states).Encode(map[string]any{"kind": kind, "sequence": sequence, "commit_id": commitID, "table_count": len(tables), "physical_root_sha256": root}); err != nil {
		o.fixture.t.Fatal(err)
	}
	return root
}

func b27RealU(out *bytes.Buffer, value uint64) {
	var encoded [8]byte
	binary.BigEndian.PutUint64(encoded[:], value)
	out.Write(encoded[:])
}

func b27RealB(out *bytes.Buffer, value []byte) {
	b27RealU(out, uint64(len(value)))
	out.Write(value)
}

func b27RealDigest(domain string, data []byte) string {
	h := sha256.New()
	_, _ = h.Write([]byte(domain + "\x00"))
	_, _ = h.Write(data)
	return hex.EncodeToString(h.Sum(nil))
}

func b27RealSchemaID(schema plugdump.NativeDeltaTableSchema) string {
	var out bytes.Buffer
	b27RealB(&out, []byte(schema.Name))
	b27RealU(&out, uint64(len(schema.Columns)))
	for _, column := range schema.Columns {
		b27RealB(&out, []byte(column.Name))
		b27RealB(&out, []byte(column.SQLType))
		if column.PrimaryKeyOrdinal == nil {
			out.WriteByte(0)
		} else {
			out.WriteByte(1)
			b27RealU(&out, *column.PrimaryKeyOrdinal)
		}
	}
	return b27RealDigest("beads-native-table-schema/2", out.Bytes())
}

func b27RealRowPayload(cells []plugdump.NativeDeltaCell, normalized []byte) []byte {
	var out bytes.Buffer
	b27RealU(&out, uint64(len(cells)))
	for _, cell := range cells {
		b27RealB(&out, []byte(cell.Kind))
		b27RealB(&out, []byte(cell.Value))
	}
	b27RealB(&out, normalized)
	return out.Bytes()
}

func (o *b27RealNativeOracle) primaryKey(schema plugdump.NativeDeltaTableSchema, cells []plugdump.NativeDeltaCell) []byte {
	o.fixture.t.Helper()
	keys := map[uint64]plugdump.NativeDeltaCell{}
	for i, column := range schema.Columns {
		if column.PrimaryKeyOrdinal != nil {
			if _, duplicate := keys[*column.PrimaryKeyOrdinal]; duplicate {
				o.fixture.t.Fatal("duplicate physical PK ordinal")
			}
			keys[*column.PrimaryKeyOrdinal] = cells[i]
		}
	}
	if len(keys) == 0 {
		return nil
	}
	var out bytes.Buffer
	out.WriteString("pk\x00")
	b27RealU(&out, uint64(len(keys)))
	for i := uint64(0); i < uint64(len(keys)); i++ {
		cell, present := keys[i]
		if !present || cell.Kind == "sql-null" {
			o.fixture.t.Fatal("invalid physical PK value/ordinal")
		}
		b27RealB(&out, []byte(cell.Kind))
		b27RealB(&out, []byte(cell.Value))
	}
	return out.Bytes()
}

func (o *b27RealNativeOracle) tableHash(schema plugdump.NativeDeltaTableSchema, rows []plugdump.NativeDeltaRow) string {
	o.fixture.t.Helper()
	var out bytes.Buffer
	id, err := hex.DecodeString(b27RealSchemaID(schema))
	if err != nil {
		o.fixture.t.Fatal(err)
	}
	out.Write(id)
	b27RealU(&out, uint64(len(rows)))
	var previous []byte
	for _, row := range rows {
		key, err := base64.StdEncoding.DecodeString(row.Key)
		if err != nil || len(key) == 0 || previous != nil && bytes.Compare(previous, key) >= 0 {
			o.fixture.t.Fatal("unordered physical PK/bag keys")
		}
		normal, err := base64.StdEncoding.DecodeString(row.NormalizedJSON)
		if err != nil {
			o.fixture.t.Fatal(err)
		}
		b27RealB(&out, key)
		b27RealB(&out, b27RealRowPayload(row.Cells, normal))
		previous = key
	}
	return b27RealDigest("beads-native-table/2", out.Bytes())
}

func (o *b27RealNativeOracle) value(value any, sqlType string) any {
	o.fixture.t.Helper()
	if value == nil {
		return nil
	}
	if stamp, ok := value.(time.Time); ok {
		return stamp.UTC().Format(time.RFC3339Nano)
	}
	if raw, ok := value.([]byte); ok {
		upper := strings.ToUpper(sqlType)
		if strings.Contains(upper, "BLOB") || strings.Contains(upper, "BINARY") {
			return map[string]string{"$bytes": base64.StdEncoding.EncodeToString(raw)}
		}
		if !utf8.Valid(raw) {
			o.fixture.t.Fatal("source text contains invalid UTF-8")
		}
		value = string(raw)
	}
	if text, ok := value.(string); ok && strings.EqualFold(sqlType, "JSON") {
		var result any
		decoder := json.NewDecoder(strings.NewReader(text))
		decoder.UseNumber()
		if err := decoder.Decode(&result); err != nil {
			o.fixture.t.Fatal(err)
		}
		return result
	}
	return value
}
