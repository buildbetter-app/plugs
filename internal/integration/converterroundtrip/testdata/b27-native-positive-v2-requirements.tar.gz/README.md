# B27 independent typed requirements and producer input port v2

Done = B27 preserves genuine CLI close rows and separately declared synthetic
route/interaction/issue-snapshot rows on memory, SQLite and PostgreSQL, proven
by a frozen exact source/schema/PK/row/value/capture/request tuple and actual
import, readback, export and physical SQL reopen assertions; source capability
or synthetic-row preservation does not prove CLI emission.

Scope = sole producer 2f, B27 consumer assertions and independent typed
expectations, existing public capture/receiver ports, two distinct public
projects. This finite handoff freezes requirements only and assigns no gate.

The packet contains six complete synthetic row expectations (three per
project), complete source-derived seed-schema requirements, genuine CLI row
projections, independently authored source milestone predicates, exact CLI
request requirements and strict three-engine acceptance. All were authored
from pinned source declarations, not producer or consumer outputs. Native
minted IDs, store IDs, clocks and complete physical images remain explicitly
unbound until independently observed original inputs arrive.

The root ruling is preserved exactly:

> routes, interactions and issue_snapshots rows cannot be produced by the native CLI in a hermetic test; snapshots additionally require an external summarizer.

Only those three tables may be SQL seeded in disposable public native stores.
Their qualification is **row preservation, not native CLI behavior**.
No external summarization is permitted in any test. compaction_snapshots has
no SQL seed permission and remains a named missing-input difference.

The authenticated producer draft is NOT_COMMITTED / NOT_DISPATCHED.
Complete positive inputs remain WAIT / NOT_PRODUCED. The local landed
capture ELF pin is 8ce67aacbad497a4e3acdffa7773b7186faaa7c1efc7a65166fc478f05d16c1e (117101352 bytes), from Beads85609b64d
and export43145983627. Its existing local path has been hash-checked; remote
availability and the actual capture tuple remain WAIT. There is no
source-built fallback and no equivalence with the separate admitted-c8eb
tuple requested for B19/B26.

Start with READINESS.json, INPUT-PORT.json and the two project expectation
directories. EXPECTED-SEED-SCHEMAS.json binds the three seeded tables to the
exact source capsule; final original physical column order/schema/digests
must still be supplied. CLI-REQUESTS.json identifies source additions absent
from the draft. A native second child is a source append control, while the
Plug public append preservation vector is separately required in
THREE-ENGINE-ACCEPTANCE.json. The portable pre-Merge refusal and two-project
Full route remain separate WAIT dependencies.

SCHEMA-SOURCE-INDEX.json records byte-identical schema blobs at capability
bf2ccefe and draft base8ab0efb9. SOURCE-BINDINGS.json records all exact inputs.
SHA256SUMS is filename-bearing; FREEZE.json seals its complete membership.
Receipt files for S1 delivery are kept alongside this directory, not added
to the sealed packet.

The accepted consumer125b0866 and its closed source review remain untouched;
986 admitted members, 999 testdata paths, 28 inherited duplicate registrations,
historical6d8f UNAPPLIED, c5 focusRED and sole whole43101691311 pending remain
literal. No product/native/SQL/build/test, CI query, collector, gate,
publication or direct peer/reviewer wake occurred. This packet does not
qualify focus, whole, native, history, hosted, admission, full-card or FullS1.
