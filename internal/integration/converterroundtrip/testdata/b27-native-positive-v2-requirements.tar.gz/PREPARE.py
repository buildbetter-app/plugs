import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

# Metadata and authored expectations only. No product, native CLI, SQL, build,
# test, CI query, gate, or collector is invoked by this packet writer.
ROOT = Path('/tmp/plug-swarm/reports/b27-real-native-positives-2f-20261112')
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT = ROOT / ('consumer-typed-requirements-v2-' + STAMP)
OUT.mkdir(mode=0o755)
PRODUCER = '/tmp/plug-swarm/work/b27-real-native-positives-2f-20261112'
CONSUMER = '/tmp/plug-swarm/work/b27-native-interchange-author-20261111'
CAPABILITY = 'bf2ccefe527f65855e92b9aa0b53dc640d23c02b'
BASE = '8ab0efb90f45ff88a073f11331a99760659d46db'
ACCEPTED = '125b0866113fb35292ced9bc6656576544a4c285'
AT = datetime.datetime.now(datetime.timezone.utc).isoformat()
PROJECTS = ['b27-review', 'b27-delivery']
NATIVE_TEXT = ('routes, interactions and issue_snapshots rows cannot be produced '
               'by the native CLI in a hermetic test; snapshots additionally '
               'require an external summarizer.')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git', '-C', repo, *args])

def put(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return {'path': name, 'bytes': len(data), 'sha256': digest(data)}

def doc(name, value):
    return put(name, (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())

def lines(name, values):
    return put(name, b''.join((json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode() for v in values))

def authenticate(path, expected, size=None):
    p = Path(path)
    assert p.name != 'poll.log' and '.artifact' not in p.parts
    data = p.read_bytes()
    assert digest(data) == expected, (str(path), digest(data))
    assert size is None or len(data) == size, str(path)
    return data

def bound_source(repo_path):
    data = git(PRODUCER, 'show', CAPABILITY + ':' + repo_path)
    base = git(PRODUCER, 'show', BASE + ':' + repo_path)
    rec = put('source/schema/' + repo_path.rsplit('/', 1)[-1], data)
    rec.update(repo_path=repo_path,
               capability_git_blob=git(PRODUCER, 'rev-parse', CAPABILITY + ':' + repo_path).decode().strip(),
               draft_base_git_blob=git(PRODUCER, 'rev-parse', BASE + ':' + repo_path).decode().strip(),
               identical_at_capability_and_draft_base=data == base)
    assert data == base, repo_path
    return rec

v1 = ROOT / 'consumer-contract-b27-20261112T162446Z'
v1freeze = authenticate(v1 / 'FREEZE.json', 'c47bf9c7b07d9ac505ae4ef380592bfbf7b08154a1431b842a96345f8dfd6536')
# Restore the intended readonly mode without changing the immutable bytes.
(v1 / 'FREEZE.json').chmod(0o444)
assert digest((v1 / 'FREEZE.json').read_bytes()) == digest(v1freeze)

capability_bytes = authenticate(ROOT / 'source-capability/SOURCE-FREEZE.json', '4226ce15deff2712df3669f947fc454d2bf86e4ba8f87dfa0165d7c4832ba3bb')
capability = json.loads(capability_bytes)
assert capability['head'] == CAPABILITY
for source in capability['source_files']:
    data = authenticate(source['path'], source['sha256'], source['bytes'])
    assert data == git(PRODUCER, 'show', CAPABILITY + ':' + source['repo_path'])
put('source/CAPABILITY-FREEZE.json', capability_bytes)
put('source/capability.raw-commit', git(PRODUCER, 'cat-file', 'commit', CAPABILITY))
put('source/draft-base.raw-commit', git(PRODUCER, 'cat-file', 'commit', BASE))
put('source/accepted-consumer.raw-commit', git(CONSUMER, 'cat-file', 'commit', ACCEPTED))
assert git(CONSUMER, 'rev-parse', 'HEAD').decode().strip() == ACCEPTED
assert not git(CONSUMER, 'status', '--porcelain=v1')

draft = ROOT / 'ROOT-A3A6-LANDED-CAPTURE-DRAFT'
draft_bytes = authenticate(draft / 'SOURCE-ONLY-PACKET.json', 'b42f27361deab9c81e0abda00f6e51dff8d9e5262121592a15ca9f96d23c8d32')
decl = json.loads(draft_bytes)
assert decl['base_head'] == BASE
put('source/PRODUCER-DRAFT.json', draft_bytes)
for member in decl['files']:
    data = authenticate(member['copy'], member['sha256'], member['bytes'])
    put('source/draft/' + Path(member['copy']).name, data)
patch = decl['patch']
put('source/draft/SOURCE.patch', authenticate(patch['path'], patch['sha256'], patch['bytes']))

elf = decl['capture_executable']
seal_bytes = authenticate(elf['review_seal'], elf['review_seal_sha256'])
put('source/LANDED-CAPTURE-EXPORT-REVIEW-SEAL.json', seal_bytes)
elf_data = authenticate(elf['path'], elf['sha256'], elf['bytes'])
assert elf_data[:4] == b'\x7fELF'
del elf_data
review_path = '/tmp/plug-swarm/reviews/b27-public-interchange-reviewer5be-20261111/source-125b0866-review.md'
authenticate(review_path, '2bb9d90c10e9f133f10309a4043f8f595983c43bd5bfbd2232a08fba6f43b480')

schema_paths = [
    '0001_create_issues.up.sql', '0004_create_comments.up.sql',
    '0008_create_child_counters.up.sql', '0009_create_issue_snapshots.up.sql',
    '0012_create_routes.up.sql', '0014_create_interactions.up.sql',
    '0020_create_wisps.up.sql', '0021_create_wisp_auxiliary.up.sql',
    '0024_create_custom_status_type_tables.up.sql', '0034_add_spec_id_column.up.sql',
    '0037_uuid_primary_keys.up.sql', '0041_split_dependencies_target.up.sql',
    '0042_add_on_update_cascade.up.sql', '0043_drop_dependencies_generated_column.up.sql',
    '0049_longtext_large_content_columns.up.sql', '0050_dependencies_deterministic_id.up.sql',
    '0051_drop_aux_id_defaults.up.sql', '0061_content_derived_aux_ids.up.sql',
    '0063_create_provenance_events.up.sql',
]
schema_sources = [bound_source('internal/storage/schema/migrations/' + p) for p in schema_paths]
doc('SCHEMA-SOURCE-INDEX.json', {'format': 'b27-pinned-schema-sources/2', 'capability_head': CAPABILITY,
    'draft_base_head': BASE, 'sources': schema_sources,
    'physical_schema_status': 'WAIT actual independently read source schemas/PK ordinals; source DDL is a requirement, not observed capture evidence'})

def col(name, sql_type, nullable, pk=None):
    return {'name': name, 'sql_type': sql_type, 'nullable': nullable, 'primary_key_ordinal': pk}

schemas = {
 'routes': {'primary_key': ['prefix'], 'columns': [col('prefix','VARCHAR(32)',False,1), col('path','VARCHAR(512)',False), col('created_at','DATETIME',False), col('updated_at','DATETIME',False)]},
 'interactions': {'primary_key': ['id'], 'columns': [col('id','VARCHAR(32)',False,1), col('kind','VARCHAR(64)',False), col('created_at','DATETIME',False), col('actor','VARCHAR(255)',True), col('issue_id','VARCHAR(255)',True), col('model','VARCHAR(255)',True), col('prompt','TEXT',True), col('response','TEXT',True), col('error','TEXT',True), col('tool_name','VARCHAR(255)',True), col('exit_code','INT',True), col('parent_id','VARCHAR(32)',True), col('label','VARCHAR(64)',True), col('reason','TEXT',True), col('extra','JSON',True)]},
 'issue_snapshots': {'primary_key': ['id'], 'columns': [col('id','CHAR(36)',False,1), col('issue_id','VARCHAR(255)',False), col('snapshot_time','DATETIME',False), col('compaction_level','INT',False), col('original_size','INT',False), col('compressed_size','INT',False), col('original_content','TEXT',False), col('archived_events','TEXT',True)], 'id_default': None, 'foreign_key': {'issue_id': 'issues.id', 'on_delete': 'CASCADE', 'on_update': 'CASCADE'}},
}
doc('EXPECTED-SEED-SCHEMAS.json', {'format':'b27-independent-declared-sql-schema/2',
    'origin':'consumer-authored from pinned source DDL plus migrations 0037/0042/0051; no native or consumer output used',
    'tables': schemas,
    'column_order':'Listed order is the fresh CREATE declaration order. Actual source ordinal order, exact database type names, schema bytes, PK ordinals and digest MUST be separately frozen from the original physical reader; never reorder actual cells to fit a guess.',
    'dependency_correction': {'dependencies_primary_key':['id'], 'wisp_dependencies_primary_key':['id'], 'id_type':'CHAR(36)',
       'logical_unique_keys':[['issue_id','depends_on_issue_id'],['issue_id','depends_on_wisp_id'],['issue_id','depends_on_external']],
       'exactly_one_non_null_target':True,'type_is_not_part_of_physical_primary_key':True,
       'source_migrations':['0021','0041','0043','0050','0061'], 'minted_ids':'Bind actual independent original source cells; do not copy producer or receiver ID algorithms.'}})

def txt(value, typ='TEXT'):
    return {'kind':'text', 'sql_type':typ, 'value':value, 'utf8_base64':base64.b64encode(value.encode()).decode()}

def integer(value, typ='INT'):
    return {'kind':'integer', 'sql_type':typ, 'decimal_token':str(value)}

def null(typ):
    return {'kind':'sql-null','sql_type':typ}

def stamp():
    return {'kind':'datetime','sql_type':'DATETIME','sql_literal':'2026-11-12 12:00:05','fractional_precision':0,'timezone':None}

def symbol(name, typ, invariant):
    return {'kind':'source-bound-symbol','name':name,'sql_type':typ,'invariant':invariant,'binding_status':'WAIT original independent pre-capture source observation; consumer output forbidden as a binding source'}

def expected_row(project, family, cells, milestone='final', origin='synthetic-row-preservation-only', complete=True):
    return {'format':'b27-independent-typed-row-requirement/2','project':project,'source_store_id':{'symbol':project+'/store_id','status':'WAIT capture manifest'},
      'family':family,'milestone':milestone,'origin':origin,'qualification':'row preservation, not native CLI behavior' if origin.startswith('synthetic') else 'required genuine canonical native CLI emission; NOT_PRODUCED',
      'row_mode':'complete-column-map' if complete else 'exact-projection-plus-independent-complete-source-row', 'cells':cells}

seed_rows = []
cli_rows = []
history_rows = []
ops = []
metadata_request = '{"nullable":null,"integer":9007199254740993,"nested":{"literal.dot/~":"雪"},"boolean":false}'
provenance_request = '{"public":true,"literal":"雪","n":9007199254740993}'
extra_request = '{"synthetic_sql_seed":true,"integer":17,"literal":"雪","nullable":null}'
content = 'synthetic original content 雪\nexact source text'
assert len(content.encode()) == 48

for p in PROJECTS:
    closed = p + '-f5a'
    sha = digest((p + '/synthetic-issue-snapshot').encode())
    snap = sha[:8]+'-'+sha[8:12]+'-'+sha[12:16]+'-'+sha[16:20]+'-'+sha[20:32]
    seeds = [
      expected_row(p,'routes',{'prefix':txt(p+'-route','VARCHAR(32)'), 'path':txt('/public/disposable/'+p+'/雪','VARCHAR(512)'), 'created_at':stamp(),'updated_at':stamp()}),
      expected_row(p,'interactions',{'id':txt(p+'-sql-int','VARCHAR(32)'),'kind':txt('tool_call','VARCHAR(64)'),'created_at':stamp(),'actor':txt('public-sql-seed','VARCHAR(255)'), 'issue_id':txt(closed,'VARCHAR(255)'), 'model':null('VARCHAR(255)'), 'prompt':txt('synthetic prompt 雪\nexact'),'response':txt('synthetic response λ\nexact'),'error':null('TEXT'),'tool_name':txt('public-synthetic','VARCHAR(255)'),'exit_code':integer(-7),'parent_id':null('VARCHAR(32)'),'label':txt('row-preservation-only','VARCHAR(64)'),'reason':txt('SQL-synthetic; no native CLI emitter'),'extra':{'kind':'json','sql_type':'JSON','declared_insert_bytes_utf8':extra_request,'typed_value':{'synthetic_sql_seed':{'kind':'boolean','value':True},'integer':{'kind':'number','decimal_token':'17'},'literal':{'kind':'string','value':'雪'},'nullable':{'kind':'json-null'}},'raw_stored_cell':'WAIT original typed source observation; JSON formatting is not assumed equal to INSERT argument bytes'}}),
      expected_row(p,'issue_snapshots',{'id':txt(snap,'CHAR(36)'), 'issue_id':txt(closed,'VARCHAR(255)'),'snapshot_time':stamp(),'compaction_level':integer(1),'original_size':integer(48),'compressed_size':integer(0),'original_content':txt(content),'archived_events':null('TEXT')}),
    ]
    for row in seeds:
        schema = schemas[row['family']]
        assert set(row['cells']) == {c['name'] for c in schema['columns']}
        row['primary_key'] = {k:row['cells'][k] for k in schema['primary_key']}
        row['before_seed_row_count'] = 0
        row['after_seed_row_count'] = 1
        if row['family'] == 'issue_snapshots':
            row['id_derivation_declaration'] = 'first 32 SHA256 hex chars of UTF8(project + /synthetic-issue-snapshot), formatted 8-4-4-4-12; declared synthetic key, no claim of native ID emission or UUID version'
    seed_rows += seeds
    lines('expectations/'+p+'/synthetic-current.ndjson', seeds)
    genuine = [
      expected_row(p,'issues',{'id':txt(closed,'VARCHAR(255)'),'title':txt('B27 public stays closed','VARCHAR(500)'),'description':txt('public close content','LONGTEXT'),'notes':txt('public close note','LONGTEXT'),'status':txt('closed','VARCHAR(32)'),'close_reason':txt('B27 native current close 雪\nexact reason','LONGTEXT'),'closed_at':symbol(p+'/closed_at','DATETIME','non-NULL; value bound to explicit public source clock + independent native typed row'), 'closed_by_session':symbol(p+'/closed_by_session','VARCHAR(255)','preserve actual source value including empty/null distinction')},origin='genuine-native-cli',complete=False),
      expected_row(p,'issues',{'id':txt(p+'-a1b','VARCHAR(255)'),'title':txt('B27 public parent 雪','VARCHAR(500)'),'description':txt('description α\nsecond line','LONGTEXT'),'design':txt('design β','LONGTEXT'),'notes':txt('notes γ','LONGTEXT'),'acceptance_criteria':txt('acceptance δ','LONGTEXT'),'issue_type':txt('b27_kind','VARCHAR(32)'),'status':txt('b27_ready','VARCHAR(32)'),'metadata':{'kind':'source-bound-json','sql_type':'JSON','request_utf8':metadata_request,'request_integer_decimal_token':'9007199254740993','stored_typed_cell':'WAIT independently observed original stored native cell','rule':'Preserve stored token exactly. Report request-versus-native normalization separately; never replace a native stored number with the request token.'}},origin='genuine-native-cli',complete=False),
      expected_row(p,'comments',{'id':symbol(p+'/durable_comment_id','CHAR(36)','one exact source ID; no UUID algorithm duplicated'),'issue_id':txt(p+'-a1b','VARCHAR(255)'),'author':txt('b27-public','VARCHAR(255)'),'text':txt('durable comment 雪\nexact','LONGTEXT'),'created_at':symbol(p+'/durable_comment_at','DATETIME','actual native original clock value')},origin='genuine-native-cli',complete=False),
      expected_row(p,'wisp_comments',{'id':symbol(p+'/active_comment_id','CHAR(36)','one exact original native source ID'),'issue_id':txt(p+'-e4f','VARCHAR(255)'),'author':txt('b27-public','VARCHAR(255)'),'text':txt('active comment λ\nexact','LONGTEXT'),'created_at':symbol(p+'/active_comment_at','DATETIME','actual native original clock value')},origin='genuine-native-cli',complete=False),
      expected_row(p,'dependencies',{'id':symbol(p+'/peer_parent_edge_id','CHAR(36)','exact source PK; physical identity is id'),'issue_id':txt(p+'-c2d','VARCHAR(255)'),'depends_on_issue_id':txt(p+'-a1b','VARCHAR(255)'),'depends_on_wisp_id':null('VARCHAR(255)'),'depends_on_external':null('VARCHAR(255)'),'type':txt('related','VARCHAR(32)')},origin='genuine-native-cli',complete=False),
      expected_row(p,'wisp_dependencies',{'id':symbol(p+'/mixed_edge_id','CHAR(36)','exact source PK; no copied ID implementation'),'issue_id':txt(p+'-e4f.1','VARCHAR(255)'),'depends_on_issue_id':txt(p+'-c2d','VARCHAR(255)'),'depends_on_wisp_id':null('VARCHAR(255)'),'depends_on_external':null('VARCHAR(255)'),'type':txt('related','VARCHAR(32)')},origin='genuine-native-cli',complete=False),
      expected_row(p,'child_counters',{'parent_id':txt(p+'-a1b','VARCHAR(255)'),'last_child':integer(1)},milestone='relational',origin='genuine-native-cli',complete=False),
      expected_row(p,'wisp_child_counters',{'parent_id':txt(p+'-e4f','VARCHAR(255)'),'last_child':integer(1)},origin='genuine-native-cli',complete=False),
      expected_row(p,'provenance_events',{'id':symbol(p+'/provenance_id','CHAR(36)','response original + independent SQL same ID; duplicate inserted=false'),'issue_id':txt(closed,'VARCHAR(255)'),'kind':txt('commit','VARCHAR(32)'),'actor':txt('public-fixture','VARCHAR(255)'),'ref':txt('0123456789abcdef0123456789abcdef01234567','VARCHAR(255)'),'ref_kind':txt('git-sha','VARCHAR(32)'),'source':txt('b27-public-native','VARCHAR(64)'),'occurred_at':{'kind':'datetime','sql_type':'DATETIME','sql_literal':'2026-11-12 12:00:02','fractional_precision':0,'timezone':None},'created_at':symbol(p+'/provenance_created_at','DATETIME','ingest time from independent original native cells'),'payload':{'kind':'source-bound-json-text','sql_type':'TEXT','request_utf8':provenance_request,'stored_text_and_typed_tokens':'WAIT original native row; never infer request-number fidelity from consumer output'}},origin='genuine-native-cli',complete=False),
    ]
    for owner, labels, family in [(p+'-a1b',['alpha','shared'],'labels'),(p+'-a1b.1',['child'],'labels'),(p+'-c2d',['shared'],'labels'),(p+'-e4f',['active'],'wisp_labels')]:
        for label in labels:
            genuine.append(expected_row(p,family,{'issue_id':txt(owner,'VARCHAR(255)'),'label':txt(label,'VARCHAR(255)')},origin='genuine-native-cli',complete=True))
    cli_rows += genuine
    lines('expectations/'+p+'/cli-current-projections.ndjson', genuine)

    for milestone, predicate in [
      ('configured',{'custom_config_declared':True,'full_source_census_required':True}),
      ('relational',{'parent':p+'-a1b','first_child':p+'-a1b.1','counter_decimal_token':'1','active_parent':p+'-e4f','active_child':p+'-e4f.1','active_counter_decimal_token':'1','closed_control_status_before_close':'open'}),
      ('provenance',{'issue_id':closed,'same_provenance_event_count_after_identical_duplicate':1,'inserted_first':True,'inserted_duplicate':False}),
      ('closed-current',{'id':closed,'status':'closed','close_reason':'B27 native current close 雪\nexact reason','closed_at':'non-NULL'}),
      ('cli-only-before-synthetic',{'synthetic_families':{'routes':0,'interactions':0,'issue_snapshots':0},'audit_original_prefix_byte_exact':True,'explicit_audit_appends':2}),
      ('final',{'synthetic_families':{'routes':1,'interactions':1,'issue_snapshots':1},'current_close_still_closed':closed,'all_nonseed_business_rows_equal_before_seed':True}),
    ]:
        history_rows.append({'format':'b27-independent-source-milestone-requirement/2','project':p,'milestone':milestone,'expected_predicates':predicate,'native_commit_id':{'symbol':p+'/'+milestone+'/native_commit_id','status':'WAIT original source graph'},'sequence':'UNBOUND; never borrow seq121/122 or prior graph counts','complete_physical_image':'WAIT independent pre-producer source schema/PK/cells/root digest'})
    lines('expectations/'+p+'/history-milestones.ndjson',[r for r in history_rows if r['project']==p])

    # These requests are requirements, not transcripts or fabricated outcomes.
    common = [
      ('config-stored-types',['config','set','types.custom','b27_kind,unused_b27_kind','--json'],'declared_in_draft'),
      ('config-stored-statuses',['config','set','status.custom','b27_ready:active,b27_review:wip,b27_done:done,b27_frozen:frozen','--json'],'declared_in_draft'),
      ('config-literal',['config','set','custom.b27_public','literal 雪 /~ and spaces','--json'],'declared_in_draft'),
      ('yaml-no-push',['config','set','no-push','true','--json'],'declared_in_draft'),
      ('yaml-routing',['config','set','routing.mode','explicit','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('audit-enabled',['config','set','audit.enabled','true','--json'],'declared_in_draft'),
      ('append-source-child',['create','B27 public appended child','--parent',p+'-a1b','--no-inherit-labels','--labels','append','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('unresolved-target',['dep','add',p+'-c2d','external:'+p+':capability','--type','related','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('current-close',['close',closed,'--reason','B27 native current close 雪\nexact reason','--json'],'declared_in_draft'),
      ('current-close-readback',['show',closed,'--json'],'declared_in_draft'),
      ('current-close-history',['history',closed,'--events','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('historical-create',['create','B27 public historical close reopen','--description','historical close body','--spec-id','spec://'+p+'/history-control','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('historical-close',['close','${history_id}','--reason','B27 historical close 雪\nexact','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('historical-readback',['history','${history_id}','--events','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('historical-reopen',['reopen','${history_id}','--reason','B27 historical reopen λ\nexact','--json'],'REQUIRED_NOT_IN_DRAFT'),
      ('historical-current-readback',['show','${history_id}','--json'],'REQUIRED_NOT_IN_DRAFT'),
    ]
    for name,argv,status in common:
        ops.append({'project':p,'name':name,'argv_after_bd':argv,'declaration_status':status,'output_status':'NOT_PRODUCED','evidence':'exact original argv/cwd/selected public env/clock files/stdout/stderr/exit plus independent native current+history row'})

doc('CLI-REQUESTS.json', {'format':'b27-native-cli-positive-requests/2','operations':ops,
    'original_draft_reference':'source/draft/b27_real_native_positive_fixture_test.go; retain ALL existing operations, recording, clock and conservation assertions',
    'create_argument_additions':{'parent_'+p:['--external-ref','b27-ext-'+p+'-01','--spec-id','spec://'+p+'/native-positive'] for p in PROJECTS},
    'closed_create_argument_additions':{p:['--external-ref','b27-close-'+p,'--spec-id','spec://'+p+'/close-control'] for p in PROJECTS},
    'historical_id_rule':'Take actual canonical create response ID, bind independent original native row and source graph. Do not request v1 -g6h, assume suffix validity, or implement allocator math.',
    'appended_source_child_rule':'Source .1 must remain byte/value-identical; new child .2 and parent counter 2 are a source append control only. They do not prove a Plug append route.',
    'unresolved_rule':'One exactly non-NULL depends_on_external arm, both local target arms SQL NULL, literal external:<project>:capability retained; no endpoint row may be created. Source id PK preserved.',
    'history_rule':'Current close remains genuinely closed. Separate historical control has an authenticated closed milestone before reopening; freeze actual closed_at/close_reason after reopen from independent native rows rather than assuming a clear/rewrite. Retain original close event and all graph nodes.',
    'capability_difference_rule':'If a canonical CLI request cannot emit its requested value/family, return typed NAMED_DIFFERENCE with exact source, command, originals and one concrete decision question through S1; no invented values or parser relaxation.'})

doc('CONFIG-AND-METADATA.json', {'format':'b27-config-metadata-requirements/2',
    'stored_expected':{'types.custom':['b27_kind','unused_b27_kind'],'status.custom':{'b27_ready':'active','b27_review':'wip','b27_done':'done','b27_frozen':'frozen'},'custom.b27_public':'literal 雪 /~ and spaces'},
    'yaml_required':{'no-push':True,'routing.mode':'explicit'},
    'union_requirement':'Retain SQL config rows, custom_types/custom_statuses tables, YAML source bytes/parse trees/precedence and origin-specific names independently. Assert the exact union from source evidence, including unused declarations. Do not synthesize source table rows or rewrite YAML after capture.',
    'yaml_distinct_type_status_need':{'state':'WAIT supported canonical native config emission contract for distinct YAML-only type/status names','proposed_value_requirements':{'type':'yaml_only_b27_kind','status':'yaml_only_b27_review:wip'},'emission_rule':'Use only an existing supported public producer/configuration contract; if the CLI cannot persist these independently, name the difference. A union inferred from identical SQL/YAML names does not prove the missing distinct-source vector.'},
    'source_categories':{'b27_ready':'active','b27_review':'wip','b27_done':'done','b27_frozen':'frozen'},
    'live_type_status_disposition':'Freeze the ORIGINAL source manifest and supported explicit ontology directives before consumer execution. Do not guess live type from issue_type, install source-created labels, invent map_type, or modify captured Body/manifest.',
    'metadata_request_utf8':metadata_request,'metadata_rule':'Request tokens and actual native stored typed tokens are separate evidence. Capture original lexical numeric cells; consumer equals native stored cells exactly, including NULL, absent key, empty text, JSON null, integer/decimal spelling and UTF8 bytes. Never round-trip through float or repair a stored token from the request.',
    'excluded_machine_local':'local_metadata key names and counts only; no values, business comparison, dump, or cause analysis. Keep immutable opaque commitments and native payloads.',
    'projection_exclusions_only':['row_lock','is_blocked'],'physical_oracle_rule':'Keep every physical source column/schema/PK/cell and history image; live source_fields projection exclusions do not delete physical evidence.'})

doc('INPUT-PORT.json', {'format':'b27-native-positive-producer-input-port/2',
    'producer_agent':'2f2c3887-17b6-446f-abe8-5fb141345207','route':'S1 c49f24d2-8fef-4a8f-83d0-c52076ae9ad6 ONLY; do not directly prompt producer/reviewer',
    'actual_capture_state':'WAIT / NOT_PRODUCED',
    'source_contract':{'producer_capability':CAPABILITY,'producer_capability_tree':capability['tree'],'producer_capability_parent':capability['parents'],'draft_base':BASE,'draft_status':decl['state'],'draft_packet_sha256':digest(draft_bytes),'final_committed_source_head_tree_parents':'WAIT exact producer freeze; draft is NOT a committed candidate'},
    'capture_program':dict(elf, local_file_hash_verified_for_requirements=True, remote_staging_status='WAIT actual canonical remote staging and original runtime path/size/hash receipts', double_hash_requirement='Verify SHA256+117101352 bytes before fixture and immediately before capture; no source-built fallback', evidence_credit='landed export ELF provenance only'),
    'per_project_required_originals':[
      'Exact committed fixture Git raw head/tree/ordered parents, BUILD/data/env reachability, bd and companion binaries SHA/size, canonical run/root/subtest/raw/XML/exit originals.',
      'Every command request/argv/cwd/public env+clock selection/stdout/stderr/exit; original synthetic seed SQL+ordered arguments labelled synthetic for exactly routes/interactions/issue_snapshots.',
      'raw-current.json, typed-current.json, physical-current-schema.json, physical-current-identity.json, physical-history.json, source-commits.json, and every typed-history/<actual_commit>.json + .schema.json, all read independently before producer output.',
      'oracle/tables.ndjson, oracle/states.ndjson and all original normalized-table+physical-v2/schema/PK/cell payloads with complete hashes/lengths/row multiplicities and selected actual source milestones.',
      'Original native capture-set manifest/index/head/parts/EOF+root commitments, all member lengths/hashes, actual store_id/native source head, request bytes/SHA/argv and producer stdout/stderr/exit.',
      'Original .beads config/metadata/audit/routes/issues observations with existence/absence/size/hash/raw bytes/parse tree/precedence; explicit config+metadata classification.',
      'Source/copy quiescence fingerprints, pre/post-capture graph + business current/history/root conservation, and genuine post-capture continuation originals. local_metadata: key names/counts only.',
      'Per-project input readiness map to all consumer expected symbols; all store IDs, minted row IDs, source commits and source clocks bound ONLY from native originals, never invented or taken from consumer output.'
    ],
    'oracle_protocol':'Use the existing complete physical v2 detached source oracle; this packet defines independent constants/projections and never replaces the complete original source oracle with a consumer-derived table.',
    'source_identity_rule':'Bind actual store IDs separately for b27-review and b27-delivery; graph/native commits are not Git commits. Key histories by (source_store_id,project,table,source_primary_key,state_commit). Preserve repeating naked IDs and row multiplicities.',
    'history_envelope_rule':'Keep original current/commit/head-checkpoint ledger bytes and physical/schema/PK digests. Current consumer expected history class may map only from authenticated source family as receiver disposition C permits; commit/head-checkpoint stay retained-native-commit.',
    'format_boundary':'Existing capture-set directory receiver only for directory inputs. Portable TARs must independently pass plain Read before Merge; archive/0 on routes/interactions/federation_peers is a known pre-Merge refusal. Do not merge delta directories, relabel head.tar, rewrite originals/directives, borrow private exceptions, skip rows, or add an importer.',
    'two_project_full_status':'WAIT genuine independently admissible two-project Full inputs through an existing compatible route; directory lifecycle is not proof of Runtime.RestoreImport portable-TAR execution.',
    'forbidden':['external summarizer in any test','SQL fixture writes outside the three approved tables','private data or private reader','source-built capture fallback','synthetic/current positives claimed from historical seq121/122 or 58 cells']})

doc('THREE-ENGINE-ACCEPTANCE.json', {'format':'b27-independent-three-engine-acceptance/2','state':'AUTHORED_REQUIREMENTS_ONLY_NOT_EXECUTED',
    'engines':['memory','sqlite','postgres'],
    'minimum_named_vectors':[
      {'name':'genuine-current-close','inputs':'one nonempty CLI-created closed issue per project','assert':'strict imported document/source-field/public bead.get retains reason/status/spec/external fields and native typed closed_at; category follows ORIGINAL declared status mapping'},
      {'name':'synthetic-route-row-preservation','inputs':'expectations/<project>/synthetic-current.ndjson routes','assert':'all columns, PK, nullability, original schema/PK/physical/normalized digests read through the imported native family, export and reopened family'},
      {'name':'synthetic-interaction-row-preservation','inputs':'same interactions row','assert':'SQL NULL model/error/parent distinct from empty text or JSON null; -7 remains integer token; all UTF8+newlines+JSON typed values exact'},
      {'name':'synthetic-issue-snapshot-row-preservation','inputs':'same issue_snapshots row','assert':'exact synthetic key, issue FK, time, levels 1/0, UTF8 length 48, text and SQL NULL archived_events; no summarizer or CLI-emission credit'},
      {'name':'genuine-provenance-and-audit','inputs':'one native CLI provenance event + duplicate + exact native JSONL append','assert':'all typed provenance columns and source event ID, duplicate same ID/inserted=false, audit prefix unchanged+two explicit appends; SQL interactions seed remains a separate source'},
      {'name':'existing-rows-nondeletion-after-public-append','inputs':'actual imported records; later admitted public tx.apply OpCreate through the existing host','assert':'freeze complete Reader census/meta+heads+native groups+export before append; append independently declared title/fields through supported public transaction; new ID bound via existing allocator profile, never a new ID implementation. Every pre-existing record and native family remains exact; new record count and one committed head advance expected; physical SQL reopen repeats exact retained+new readback'},
      {'name':'nonempty-restore-refusal-conservation','inputs':'same imported nonempty store','assert':'typed restore_requires_empty; no new head/incarnation/record/native-row/blob or export changes, including SQL physical reopen'},
      {'name':'unresolved-external-target','inputs':'required exact original CLI external edge','assert':'one external target arm retained; no phantom endpoint, drop, resolve, or manufactured local record; all source IDs/history exact'},
      {'name':'stored-yaml-type-status-union','inputs':'distinct original SQL+YAML name/category declarations and original reader disposition','assert':'per-source exact names and complete union, unused names retained; no unrequested installed type or guessed directive'},
      {'name':'two-project-full-source-history','inputs':'actual two-store source graphs and an existing admissible Full route','assert':'every original node/ordered parents/table state/source ID+store mapping retained separately, selected genuine close and seed milestones exact; unresolved admission is WAIT, not filtered PASS'}
    ],
    'execution_order':['Authenticate originals and independent constant/schema expectations before importing.','Freeze actual current request bytes/SHA and admitted PLUG_PUBLIC_BUNDLE receipt once; source-built reference is not an admitted binary.','Use existing native capture-set plan + restore/import profile with one shared lifecycle per engine.','Assert complete imported current/head-checkpoint/history cells/schema/PK/multiplicities plus live fields/comments/deps/parent/labels/metadata/catalog.','Read every auxiliary row through driver.Reader NativeRowGroup/blob endpoints and compare to native originals + independently declared constants; a source census or unread blob is insufficient.','Export the populated Plug store through the supported existing public dump route; use a fresh target where the existing portable input route actually admits it, then assert exact mapped state + source family commitments. Record typed boundary instead of rewriting TAR.','Perform public append and nonempty refusal conservation as separate vectors.','Close all SQL handles, reopen the same SQLite file / PostgreSQL database, pin new Reader Meta/head and repeat complete strict readback. Memory uses same-process reader reopen and earns no physical SQL credit.'],
    'existing_ports':[
      {'repo_path':'internal/integration/converterroundtrip/b27_native_interchange_test.go','symbols':['runPublicNativeExternalCaptureWithPlan','b27NativeIntent','b27NativeCurrent','b27NativeDocuments','b27NativeFullHistory']},
      {'repo_path':'internal/integration/converterroundtrip/b27_native_acceptance_test.go','symbols':['b27NativeAuxiliaryReadback','b27NativeConfigSourceReadback','b27NativeCatalogReadback','b27NativeNonemptyRefusal']},
      {'repo_path':'internal/integration/converterroundtrip/b27_native_public_test.go','symbols':['TestB27RichNativePublicImportCensusCatalogAndHeadRoundtrip']},
      {'repo_path':'spec/s1-b25-b28/public_interchange_test.go','symbols':['TestB27PublicPlugRoundtripFieldsRelationsAndReopen'],'scope':'existing public tx.apply OpCreate and typed field/readback/refusal semantics; no native evidence borrowed'}],
    'public_append_control':{'declaration':'new Plug-side control, NOT native CLI emission','request_model':{'method':'tx.apply','changeSet':{'Ops':[{'Kind':'OpCreate','Create':{'Type':'issue','Fields':{'title':'B27 post-import public append 雪','description':'independent append preservation control','notes':'all prior imported rows must survive'}}}]}},'wire_encoding':'Use the existing model.ChangeSet/model.OpCreate public serializer and imported project namespace; these are model field names, not a fabricated wire transcript.','expected_existing_rows':'strict all-record subset identity including exact row bodies, metadata, relations, comments, labels and source-family rows; independently declare allowed new object/event rows before execution','readiness':'WAIT compatible imported namespace/catalog, existing public writer authority and actual allocator profile from existing port'},
    'qualification':'Source capability, synthetic-row preservation, refusal, skipped or non-running tests, emitted:true, file counts or collector success do not prove genuine CLI emission/import/reopen/history/full-card.'})

doc('B19-B26-COMPATIBILITY.json', {'format':'b27-adjacent-input-compatibility/2','state':'WAIT_NO_MATCHING_SUPPLIED_CAPTURE_OR_V2_ORACLE',
    'sole_producer':'2f2c3887-17b6-446f-abe8-5fb141345207','scope':'typed input compatibility only; no B26 claim-fence authoring/analysis or additional producer/run',
    'compatible_source_declarations':{'active_parent':'<project>-e4f','active_child':'<project>-e4f.1','durable_endpoint':'<project>-c2d','mixed_edge':'wisp_dependencies child -> durable endpoint, related','active_comment':'wisp_comments on active parent, b27-public, active comment λ\nexact','active_label':'wisp_labels active on parent'},
    'gaps':['No authenticated admitted-c8eb capture-set + independent full v2 schema/PK/typed row/status/category/selected-source-history oracle has been delivered.','Current draft activity is source declaration only; no active captured evidence. Mixed edge, comment and label are not yet co-located on one promotion endpoint.','No promotion request/output, prepromotion capture, or postpromotion independent typed row/auxiliary disposition is supplied.','Landed capture ELF8ce67aac is a capture-program identity; it does not substitute for the separate requested admitted-c8eb bundle/recording receipt.'],
    'minimum_requested_input_contract':{'before_promotion':'At least one genuinely active transient wisp and durable endpoint, with captured mixed-plane dependency/comment/label on the explicit tested endpoint; independent current physical schema/PK/cells/status/category, source graph and original native CLI commands.','promotion':'Existing canonical bd promote <actual-wisp-id> --reason <declared public reason> --json; original ID preserved per public command contract; capture exact actual plane/auxiliary transfer and added promotion comment without guessing IDs or event counts. Retain a separate still-active wisp if final current input is also required to prove transient activity.','history':'Freeze actual selected original source commits/states and explicit promotion disposition; no invented versioned history for ignored wisp tables.','delivery':'Exact admitted-c8eb receipt/source/capture/request + independent v2 oracle matching one tuple, through S1; any producer continuation remains sole-owner and separately authorized.'},
    'known_nonqualifying':{'0e4d':'inert/current-only/no dependency','c774_regression_2c307':'different source-built capture tuple','B27_draft':'NOT_COMMITTED_NOT_DISPATCHED_NOT_PRODUCED'},
    'credit':'No B19/B26 native positive, promotion, history or runtime result.'})

doc('READINESS.json', {'format':'b27-native-positive-input-readiness/2','at':AT,
    'authored_now':{'exact_synthetic_current_rows':len(seed_rows),'projects':PROJECTS,'schema_requirements':'3 complete seed table declarations with PK/type/null rules; final physical order/schema WAIT','genuine_current_projections':len(cli_rows),'history_milestone_predicates':len(history_rows),'canonical_cli_request_requirements':len(ops),'three_engine_assertion_contract':True},
    'actual_inputs':{'new_complete_captures':0,'new_store_ids':0,'new_typed_physical_v2_oracles':0,'new_source_graphs':0,'new_runtime_readbacks':0,'new_import_exports':0,'new_SQL_reopens':0},
    'dependencies':[
      {'name':'actual positive producer source/capture/oracle tuple','state':'WAIT','proof_needed':'final committed source identity plus canonical admitted ELF capture and complete independent typed original packet'},
      {'name':'remote landed ELF staging','state':'WAIT','proof_needed':'existing ELF actual remote path/size/SHA receipts checked twice by fixture; local path is not remote availability'},
      {'name':'append/unresolved/spec/external/YAML-distinct/history additions','state':'REQUIRED_NOT_PRESENT_IN_AUTHENTICATED_DRAFT','proof_needed':'producer-owned source coalescing + actual CLI originals, independent typed cells and graph milestones'},
      {'name':'two-project Full portable admission','state':'WAIT_KNOWN_PRE_MERGE_FORMAT_BOUNDARY','proof_needed':'an existing admissible full native route; no TAR rewrite/delta merge/private guard'},
      {'name':'compaction_snapshots positive','state':'NAMED_DIFFERENCE_NO_AUTHORIZED_EMITTER','proof_needed':'root decision if needed; no external summarizer and no fourth-table SQL seed permission'},
      {'name':'B19/B26 active/promotion tuple','state':'WAIT_NO_MATCHING_SUPPLIED_INPUT','proof_needed':'B19-B26-COMPATIBILITY.json exact common contract, separate actual receipt'}
    ],
    'preserved':{'accepted_head':ACCEPTED,'accepted_tree':'823abd819c04422fae37f60917708b300370568f','accepted_parent':'c5aba92563bd3b413b79909e2fefbc94755cf544','source_review':'CLOSED_SOURCE_PASS_2bb9d90c','admitted_payloads':986,'testdata_paths':999,'inherited_duplicates':28,'historical_close_patch_6d8f':'UNAPPLIED_UNREVIEWED_NOT_RUN','c5_focus_43101437036':'CLOSED_RED_LITERAL','whole_43101691311':'SOLE_PENDING_UNQUERIED'},
    'unit_operations':{'accepted_worktree_changed':False,'repo_commit_created':False,'product_executed':False,'native_or_SQL_executed':False,'build_test_compiler_executed':False,'CI_API_query':False,'collector_query_or_replacement':False,'gate_dispatch':False,'peer_or_reviewer_wake':False},
    'qualification':'AUTHORED_TYPED_REQUIREMENTS_ONLY; produced input/runtime/native/history/hosted/admission/full-card/FullS1 WAIT/unqualified'})

doc('V1-CORRECTIONS.json', {'format':'b27-requirements-correction-provenance/2',
    'v1_directory':str(v1),'v1_contract_sha256':'5c8de68d5387aa2fca3d46c09c9fb911235eaa095898f20c2e6c8b45dc0f6f44','v1_freeze_sha256':digest(v1freeze),'v1_queued_receipt':'f51dc0a5-7f44-4b31-810b-8d233c0688df',
    'v1_original_bytes':'PRESERVED; FREEZE.json mode restored to 0444 without byte edit',
    'superseded_requirements_only':['Concrete synthetic seeds now equal authenticated producer source declarations, not v1 suggested constants.','Dependencies/wisp_dependencies physical PK is id; natural typed endpoint unique keys are distinct.','Historical native control ID is actual CLI-minted/source-bound; no invented -g6h ID.','Metadata request lexical token is not assumed equal to stored native token.','SHA256SUMS has filenames and complete membership; v1 hash-only manifest is retained without editing.'],
    'no_evidence_replacement':'No original source, native, gate, packet, historical RED or accepted review is reopened or relabelled.'})

readme = f'''# B27 independent typed requirements and producer input port v2

Done = B27 preserves genuine CLI close rows and separately declared synthetic
route/interaction/issue-snapshot rows on memory, SQLite and PostgreSQL, proven
by a frozen exact source/schema/PK/row/value/capture/request tuple and actual
import, readback, export and physical SQL reopen assertions; source capability
or synthetic-row preservation does not prove CLI emission.

Scope = sole producer 2f, B27 consumer assertions and independent typed
expectations, existing public capture/receiver ports, two distinct public
projects. This finite handoff freezes requirements only and assigns no gate.

The packet contains six complete synthetic row expectations (three per
project), complete source-derived seed-schema requirements, genuine CLI row
projections, independently authored source milestone predicates, exact CLI
request requirements and strict three-engine acceptance. All were authored
from pinned source declarations, not producer or consumer outputs. Native
minted IDs, store IDs, clocks and complete physical images remain explicitly
unbound until independently observed original inputs arrive.

The root ruling is preserved exactly:

> {NATIVE_TEXT}

Only those three tables may be SQL seeded in disposable public native stores.
Their qualification is **row preservation, not native CLI behavior**.
No external summarization is permitted in any test. compaction_snapshots has
no SQL seed permission and remains a named missing-input difference.

The authenticated producer draft is NOT_COMMITTED / NOT_DISPATCHED.
Complete positive inputs remain WAIT / NOT_PRODUCED. The local landed
capture ELF pin is {elf['sha256']} ({elf['bytes']} bytes), from Beads85609b64d
and export43145983627. Its existing local path has been hash-checked; remote
availability and the actual capture tuple remain WAIT. There is no
source-built fallback and no equivalence with the separate admitted-c8eb
tuple requested for B19/B26.

Start with READINESS.json, INPUT-PORT.json and the two project expectation
directories. EXPECTED-SEED-SCHEMAS.json binds the three seeded tables to the
exact source capsule; final original physical column order/schema/digests
must still be supplied. CLI-REQUESTS.json identifies source additions absent
from the draft. A native second child is a source append control, while the
Plug public append preservation vector is separately required in
THREE-ENGINE-ACCEPTANCE.json. The portable pre-Merge refusal and two-project
Full route remain separate WAIT dependencies.

SCHEMA-SOURCE-INDEX.json records byte-identical schema blobs at capability
bf2ccefe and draft base8ab0efb9. SOURCE-BINDINGS.json records all exact inputs.
SHA256SUMS is filename-bearing; FREEZE.json seals its complete membership.
Receipt files for S1 delivery are kept alongside this directory, not added
to the sealed packet.

The accepted consumer125b0866 and its closed source review remain untouched;
986 admitted members, 999 testdata paths, 28 inherited duplicate registrations,
historical6d8f UNAPPLIED, c5 focusRED and sole whole43101691311 pending remain
literal. No product/native/SQL/build/test, CI query, collector, gate,
publication or direct peer/reviewer wake occurred. This packet does not
qualify focus, whole, native, history, hosted, admission, full-card or FullS1.
'''
put('README.md',readme.encode())

bindings = {'format':'b27-independent-requirements-source-bindings/2','at':AT,
    'capability_freeze_sha256':digest(capability_bytes),'draft_packet_sha256':digest(draft_bytes),
    'accepted_consumer':{'head':ACCEPTED,'tree':git(CONSUMER,'rev-parse',ACCEPTED+'^{tree}').decode().strip(),'parents':git(CONSUMER,'show','-s','--format=%P',ACCEPTED).decode().split(),'clean_before_packet':True,'review_path':review_path,'review_sha256':'2bb9d90c10e9f133f10309a4043f8f595983c43bd5bfbd2232a08fba6f43b480'},
    'producer_source':{'capability':CAPABILITY,'tree':capability['tree'],'parents':capability['parents'],'all_11_capability_source_payloads_match_exact_git':True,'draft_base':BASE,'draft_identity':'NOT_COMMITTED_NOT_DISPATCHED'},
    'elf_pin':dict(elf,local_sha_size_verified=True,executed=False),
    'build_reachability':{'producer_draft_label':'//cmd/plug-capture-sql-server:b27_real_native_positive_fixture_test','producer_src':'cmd/plug-capture-sql-server/b27_real_native_positive_fixture_test.go','producer_env_inherit':'B27_LANDED_CAPTURE_BINARY','capture_source_target_removed_from_draft_data':True,'state':'SOURCE_ONLY_DRAFT_NOT_EXECUTED','consumer_contract_repo_reachability':'This packet is an external requirements artifact, not committed executable test data. Future actual fixtures + typed ledgers must be committed, exact-path admitted, and reachable in the frozen consumer BUILD/data/source-manifest before any gate.'},
    'standing_main_for_future_composition':'793e40f86aca5274867d63b2a832a0e1824695d7; no rebase or main chase in this handoff',
    'root_authority':['2026-11-12 16:05Z ROOT2d9746af','ROOTa3a6d1d6 landed85609 capture program','S1 b72e3537-a342-43f8-885a-610f33b9f2ea actual input absence'],
    'source_capsule_rule':'Pinned schema source and declared draft bytes only; no native captured rows, logs or consumer outputs used as independent expected constants.'}
doc('SOURCE-BINDINGS.json',bindings)
put('PREPARE.py',Path(__file__).read_bytes())

# Metadata consistency checks do not execute assertions against any product.
assert len(seed_rows)==6
assert len({(r['project'],r['family']) for r in seed_rows})==6
assert len(history_rows)==12
for row in seed_rows:
    assert set(row['primary_key'])==set(schemas[row['family']]['primary_key'])
assert git(CONSUMER,'rev-parse','HEAD').decode().strip()==ACCEPTED
assert not git(CONSUMER,'status','--porcelain=v1')
members=[]
for p in sorted(OUT.rglob('*')):
    # Packet directory only, never OUT/collector traversal. Exclude protected
    # operational names BEFORE any stat, read, hash or copy.
    if p.name=='poll.log' or '.artifact' in p.relative_to(OUT).parts:
        raise AssertionError('excluded name in authored packet')
    if p.is_dir():
        continue
    assert not p.is_symlink()
    data=p.read_bytes()
    p.chmod(0o444)
    members.append({'path':p.relative_to(OUT).as_posix(),'bytes':len(data),'sha256':digest(data),'mode':'0444'})
sums=''.join(m['sha256']+'  '+m['path']+'\n' for m in members).encode()
sum_member=put('SHA256SUMS',sums)
(OUT/'SHA256SUMS').chmod(0o444)
freeze={'format':'b27-independent-typed-requirements-freeze/2','at':AT,'status':'AUTHORED_TYPED_REQUIREMENTS_ONLY_NATIVE_INPUT_WAIT',
 'members':members+[dict(sum_member,mode='0444')],
 'membership_rule':'Exactly these regular members plus FREEZE.json. FREEZE is the root seal; its hash is delivered separately. Receipt files live outside this directory.',
 'qualification':'No capture, runtime, test, CI query, gate, product execution or accepted-worktree edit.',
 'done_for_this_finite_unit':'Independent declared typed row/schema/PK/constants + source-bound dynamic requirements + actual input readiness frozen and routed through S1.'}
doc('FREEZE.json',freeze)
(OUT/'FREEZE.json').chmod(0o444)
expected={m['path'] for m in freeze['members']}|{'FREEZE.json'}
actual={p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.name!='poll.log' and '.artifact' not in p.relative_to(OUT).parts and p.is_file()}
assert actual==expected,(actual-expected,expected-actual)
for m in freeze['members']:
    p=OUT/m['path'];data=p.read_bytes()
    assert digest(data)==m['sha256'] and len(data)==m['bytes']
    assert stat.S_IMODE(p.stat().st_mode)==0o444
print(json.dumps({'packet':str(OUT),'freeze_sha256':digest((OUT/'FREEZE.json').read_bytes()),'members_including_freeze':len(expected),'synthetic_rows':6,'cli_projections':len(cli_rows),'history_milestones':12,'schema_sources':len(schema_sources),'status':freeze['status'],'accepted_worktree_unchanged':True},sort_keys=True))
