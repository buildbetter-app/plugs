# R4 finite independent fixture handoff

**SOURCE_PASS_BOUNDED; FOCUS_PASS_REACHED; NATIVE_CAPTURE_ARTIFACTS_PASS_BOUNDED; WHOLE_RED_NOT_REACHED.** The current finite source/original review is complete. The two genuine native sources, both supported capture formats, and independently checked source expectations are usable as immutable inputs to their existing consumer owners. Consumer import/modes/history/reopen, nonempty-comment capture, admission, landing and FullS1 are not qualified here.

Reviewer `8234fa9e-c8a3-461e-898a-79f6ef128ece`; sole author `325ddc14-3367-471c-9457-ddd8b6612f64`. Candidate head `99021f543e57d57b27d7a8d0d6263eafa4d2b4cf`, tree `6f3cb7e7fde39a8351c3071531ed69e7a7759cc0`, parent `0da51942d67d192a9a7a4db888b297d5d69ba94a`. The reviewer checkout remains clean at assigned b1c base/tree. No reviewer product/test edit, product/SQL execution, gate, CI/API query, collector, worker, importer or capture occurred.

## Exact evidence and reachability

[Source review](SOURCE-REVIEW-99021f54.md) and [source fingerprint](R4-SOURCE-FINGERPRINT-99021f54.json) already bind the exact committed fixture correction and mechanically authorized donor composition. Their source-only scope remains. The source report's former WAIT for the repeat-close difference is superseded only by the binding classification below; historical reports are unchanged.

Focus run `43080162197` is genuinely terminal exit 0. Immutable original manifest: `/tmp/plug-swarm/reports/native-rich-relations-325dd-20261111/r4-originals/focus/MANIFEST.json`. All 14 delivered files and all 1,788 original tar members were fingerprinted before semantic parsing. The author's disclosure remains literal: sealed before semantic parsing, after reading only terminal existence/exit0. Raw log reaches root `TestPublicNativeRichRelationsFixture` and both review-project/delivery-project subtests, with actual PASS and no SKIP. XML has 3 testcases, 0 failures, 0 errors, 0 skips. Undeclared census is complete, with no errors. [Focus channels](R4-FOCUS-CHANNELS.json) preserves original command, logs, XML and provenance independently.

Focus uses the unchanged common seven controls and 900/9000 timeouts plus the existing invocation-wide `gms_pure_go`, `test_env` run-under, public environment and `-test.short=false` route. Whole run `43080162937` is separately terminal exit1, from zero-extra canonical whole. Its release-v1.0.0 fetch returned HTTP500 and analysis aborted; dolt_version_test separately reports unset BEADS_TEST_DOLT_BINARY. Raw: 8 PASSED, 1 FAILED, 2 NO STATUS; XML: 9 testcases, 0 failures, 1 error, 0 skips. The new rich fixture is NOT_REACHED in whole. [Whole review](R4-WHOLE-REVIEW-99021f54.md) remains literal and unchanged. No focus result repairs or replaces whole RED.

The author's byte-exact extraction is `/tmp/plug-swarm/reports/native-rich-relations-325dd-20261111/r4-native-originals/MANIFEST.json`. Independently streamed all 1,783 extracted files: SHA256, length and original member mapping equal the previously fingerprinted tar; exact directory inventory matches; every file is 0444. [Extraction verification](R4-NATIVE-ORIGINALS-VERIFIED.json) records this without another extraction or producer. Original binary bytes were fingerprinted, never executed.

## Native source and physical-oracle findings

[Independent artifact checks](R4-INDEPENDENT-ARTIFACT-CHECKS.json) binds all current and immutable images. The source-derived oracle existed before both producer invocations; no Plug consumer output supplies any expectation. This review independently decoded original detached typed cells and actual PK-ordinal schemas, preserved number tokens and SQL NULL distinctions, rebuilt compact Go-compatible normalized envelopes, and independently recomputed the schema/PK-or-bag/row/table/root framing. Physical normalized rows include LF; envelope bytes do not. Every supplied table envelope, schema ID, physical table hash and physical root matches. Empty tables and absent tables remain distinct.

| Source | Native source head | Immutable images | Checked states | Checked table images | Checked rows |
| --- | --- | ---: | ---: | ---: | ---: |
| review-project | i6vsgrmkbj53nknbu8no9n4hg3a4v0t7 | 122 | 124 | 2,401 | 10,289 |
| delivery-project | 9v6shilpul2u4ce34uom0rg7ssl5vitu | 123 | 125 | 2,424 | 10,358 |

Exact StoreIDs are in the independent tuple ledger and artifact checks. Both working identities are complete/read-only and bind the actual head and working root. All source commit IDs are reachable, with no physical-history boundary. Each source has 33 captured raw SQL families; the physical oracle separately retains dolt_ignore, dolt_nonlocal_tables and dolt_schemas, for 36 current physical tables.

Per source, `legacy/capture.tar` is an actual validated `plug-dump/1` archive, with complete `beads-native-tables/1` attachment: correct StoreID/project/head, all 122/123 independently matching original native images, complete=true and no native gaps. Every member matches its internal manifest hash and length. Its native current tables exactly match original pre-producer SQL. The separate `history/source.json` portable-image range remains explicitly unverified/incomplete, reason `portable-image-not-supported; native history is separately retained`; manifest history stays `available-unverified`. Complete native attachments do not turn that separate portable A6 route into a verified range.

`capture/capture-set/` is the distinct actual `beads-native-capture-set/2` / `beads-native-delta/2` input, with head.tar and original part. All part chain/payload/head/set hashes and lengths match. Every stream state/table expected root/schema/count/hash equals the independently derived physical oracle. No delta receiver was run or reconstructed by this reviewer. Full two-project portable merge remains the existing original-archive route; no two-delta merger is implied.

## Independent native tuple packet

[R4-INDEPENDENT-NATIVE-TUPLES.json](R4-INDEPENDENT-NATIVE-TUPLES.json) is the independently authored actual expected-value ledger. It binds literal roles, IDs, prefixes/namespaces/counters, fixed rich fields, full raw business tuples, selected source commits and timestamp cells, original public command paths/exits, catalogs/YAML provenance, exact metadata tokens, label/filter/refusal expectations, gate tuples and native continuation. Every milestone's selected versioned business tables independently matches its named immutable typed source image.

Per source, fixed parent/peer/active roots remain exact; the delivery roots retain namespace abc. Durable child counter is 2, active child counter is 1; actual post-capture continuation is durable child `.3`, counter3. Original issue_counter has zero rows. Final legacy manifest binds parent counter2; intermediate inventory child-counter defaults do not replace the actual table/manifest/continuation observations.

B16 rename is independently 4 renamed / 2 merged per source; missing rename0/0 and exact-case RenameCase rename1/0. Mixed durable/active carriers, full all/any/exclude sets, remove-wins labels `[added,duplicate,replace]`, Unicode255 acceptance, Unicode256 refusals and atomic refusal conservation match the prior independent expectations. CLI-trimmed inputs remain separate from raw stored ` stored value `: raw exact membership is the parent, while both native CLI spaced/unspaced filters return no item. CaseTag/casetag/CASETAG and utf8mb4_0900_bin are retained literally. Every supplied refusal conserves its complete raw SQL snapshot.

The parent preserves title/type/status/priority, multiline Unicode description/design/acceptance/notes, assignee, estimate37, due date, spec/external references and exact metadata shape. Native stored number tokens are integer42, large/wide9007199254740992, decimal1.25, spelling1. Requested large/wide9007199254740993, decimal1.2500 and spelling1.0 are separate input facts; no producer/consumer oracle repairs the native stored values. Nullable/explicit_null are present null; comparison_absent is absent; sibling is unchanged. Public peer title/notes update has exact independently checked before/after source images.

Catalogs retain literal awaiting_review:active, qa_testing:wip, archived:done, on_hold:frozen; project_local is active in review and done in delivery, with delivery's real prior-active catalog image. Current review SQL has sql_only; delivery's actual later config replacement removes sql_only, whose initial history remains. Types include rich_kind, unused_stored_kind, sql_only_kind; physical YAML independently declares rich_kind/yaml_only_kind and awaiting_review:active/yaml_only:frozen. Raw/config/YAML origins remain distinct. Conflict precedence beyond this compatible overlap is not claimed. Public ready returns category700/704/705 in review and700/705 in delivery. Ordinary sequential open/awaiting_review claims succeed; qa_testing/archived/on_hold refuse with full raw conservation. No protected claim vector is involved.

Directed dependency tuples, all ten native columns, both parent directions, dependency metadata, close reason and source identity are preserved. Missing-target/cross-prefix skipped_dependencies cases were not exercised. SQL routes/interactions, snapshots and provenance are source-observed zero; routes.jsonl/interactions.jsonl/issues.jsonl are source-observed absent, not SQL aliases. Current comments and wisp_comments are actually zero. Native carry/archive/manifest-rebuild census is retained; no final receiver mapped/opaque/refused credit is supplied here. Portable nonempty routes/interactions refusal is not exercised. Adjacent nonempty-comment packet is still interim, with no finished store-bound physical capture delivered to this reviewer; it is not grafted or promoted.

## Actual modern gate history for B14

Actual gate IDs are review-project-afr and delivery-project-dkf. Each is native type gate, await_type human, await_id `opaque/public/<project>`, timeout_ns0. Whole-list mutation uses guarded `issueops.ExecuteUpdate` with public UpdateRequest and actual SQL transaction, followed by native commit and public CLI readback. This is not an HTTP execution claim. SQL waiters is typed text; decoded ordered lists preserve duplicate and blank entries.

| Source / gate | Original list and commit | Replaced whole list and commit |
| --- | --- | --- |
| review-project / review-project-afr | `["a","a",""]` at 9alu1fr3mr8irieb7pftste3jeij56no | `["","a","a","z",""]` at d0tchqfn46saeb02vp1g1o8dcru7sebs |
| delivery-project / delivery-project-dkf | `["a","a",""]` at pmmj9n5glb0j9p8rama7rpnp37ahtng9 | `["","a","a","z",""]` at 57olc5jbg6fb20k4p7e1e978jtfofrvc |

Both actual archive records emit Body[type]=gate and source_type=gate, with no gate map_type directive. Exact raw source fields, original request/result, emitted record and both source images are in the tuple ledger and the sole original packet. This is native source/capture evidence for B14's existing consumer; it supplies no imported public current/history/reopen result.

## Repeat-close classification and final bounds

Independently compared both complete repeat-close snapshots and graphs. Every family except local_metadata is identical; the complete clean source graph and native commit identity are identical. First close reason `public close 雪` + LF + `exact reason` and actual closed_at survive. Reopen later clears closed_at/reason under its separate actual commit. Close/reclose/reopen timestamps remain actual native observations, not invented controlled-clock times.

Binding `/tmp/plug-swarm/escalations.md:2607-2613`, 18:51Z second ruling, excludes the local_metadata machine-local bookkeeping from native/Plug no-business-state-change comparisons. This supersedes only the prior UNCLASSIFIED caveat in the delivery/source-review boundary. It authorizes positive conservation on the actually unchanged business rows, graph and versioned history. Immutable originals and earlier literal reports remain unchanged.

Counts by changed key name only; no values or cause/repair/workaround analysis:

- review-project: dependency-coordination/v1/dependencies/d2e =1; dependency-coordination/v1/wisp_dependencies/d2e =1.
- delivery-project: dependency-coordination/v1/dependencies/dbf =1; dependency-coordination/v1/wisp_dependencies/dbf =1.

The native-source capture/artifact handoff is independently bounded PASS. Whole remains literal RED/NOT_REACHED. Nonempty final comment capture and all consumer Full/Partial/Snapshot/import/history/reopen proofs stay with their existing owners. No native admission, full-card acceptance, landing, official spend, private access or FullS1 transfer is granted. Historical R1/R2/R3 REDs remain. FullS1 1/28, nights0/3, fresh0/12 are unchanged.

Per the cap16 scheduling instruction, the remaining review/expected-tuple packet is delivered only to S1 for routing to admitted existing consumer pairs. No idle consumer is prompted. This reviewer stops at this finite handoff and remains idle for a genuinely new immutable input.
